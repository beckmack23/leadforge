"""Email extraction, classification and the anti-fabrication guarantee."""
import re

import pytest

from app.core import email_extract as ee


# ---------------------------------------------------------------- extraction
def test_extracts_mailto_and_text_emails():
    html = """
    <html><body>
      <a href="mailto:john@abchvac.com">Email John</a>
      <p>Or reach us at info@abchvac.com any time.</p>
    </body></html>"""
    page = ee.parse_page(html, "https://abchvac.com/contact", "contact")
    found = {e.address: e.method for e in page.emails}
    assert found["john@abchvac.com"] == "mailto_link"
    assert found["info@abchvac.com"] == "page_text"


def test_deobfuscates_human_readable_addresses():
    for text, expected in [
        ("<p>service (at) acmeroofing (dot) com</p>", "service@acmeroofing.com"),
        ("<p>owner [at] acmeroofing [dot] com</p>", "owner@acmeroofing.com"),
        ("<p>sales AT acmeroofing DOT com</p>", "sales@acmeroofing.com"),
    ]:
        page = ee.parse_page(f"<html><body>{text}</body></html>",
                             "https://acmeroofing.com/", "home")
        assert expected in {e.address for e in page.emails}, text


def test_extracts_structured_data_email():
    html = """<html><head><script type="application/ld+json">
      {"@type":"LocalBusiness","name":"ABC","email":"contact@abchvac.com"}
    </script></head><body>x</body></html>"""
    page = ee.parse_page(html, "https://abchvac.com/", "home")
    addrs = {e.address: e.method for e in page.emails}
    assert addrs["contact@abchvac.com"] == "structured_data"


@pytest.mark.parametrize("junk", [
    "logo@2x.png", "sprite@3x.jpg", "test@example.com", "you@yourdomain.com",
    "a1b2c3d4e5f6a7b8c9d0@sentry.io", "name@domain.com", "hello@wixpress.com",
])
def test_rejects_junk_addresses(junk):
    page = ee.parse_page(f"<html><body><p>{junk}</p></body></html>",
                         "https://x.com/", "home")
    assert junk not in {e.address for e in page.emails}


def test_challenge_and_scripts_do_not_leak_addresses():
    html = """<html><body>
      <script>var cfg={"key":"abcdef0123456789abcdef@analytics.example.com"}</script>
      <p>Real: office@realbiz.com</p></body></html>"""
    page = ee.parse_page(html, "https://realbiz.com/", "home")
    addrs = {e.address for e in page.emails}
    assert "office@realbiz.com" in addrs
    assert not any("analytics.example.com" in a for a in addrs)


# ---------------------------------------------------- classification / tiers
def test_role_account_detection():
    for lp in ["info", "contact", "sales", "office", "hello", "accounts.payable"]:
        assert ee.is_role_account(lp), lp
    for lp in ["john", "jsmith", "mary.jones", "dprice"]:
        assert not ee.is_role_account(lp), lp


def test_local_part_person_matching():
    assert ee.local_part_matches_person("jsmith", "John Smith")
    assert ee.local_part_matches_person("john.smith", "John Smith")
    assert ee.local_part_matches_person("johnsmith", "John Smith")
    assert ee.local_part_matches_person("john", "John Smith")
    assert ee.local_part_matches_person("smithj", "John Smith")
    assert not ee.local_part_matches_person("info", "John Smith")
    assert not ee.local_part_matches_person("billing", "John Smith")
    assert not ee.local_part_matches_person("mary", "John Smith")


def test_email_tier_classification():
    assert ee.classify_email_type("john", True, True) == "decision_maker"
    assert ee.classify_email_type("mary", False, True) == "employee"
    assert ee.classify_email_type("info", None, False) == "general_business"
    assert ee.classify_email_type("someone", None, False) == "general_business"


def test_disposable_and_free_provider_flags():
    assert ee.is_disposable_domain("mailinator.com")
    assert ee.is_disposable_domain("sub.guerrillamail.com")
    assert not ee.is_disposable_domain("abchvac.com")
    assert ee.is_free_provider("gmail.com")
    assert not ee.is_free_provider("abchvac.com")


# ---------------------------------------------------- ANTI-FABRICATION GUARD
def test_no_module_generates_email_addresses():
    """Static guard: no source file may build an address from name + domain.

    Any f-string or concatenation producing '<something>@<domain>' outside the
    two audited call sites would be pattern generation, which this system
    must never do.
    """
    import pathlib

    root = pathlib.Path(__file__).resolve().parent.parent / "app"
    # A line may join a local-part and a domain ONLY if it carries an explicit
    # audit marker saying it is reassembling an address already parsed out of a
    # page or provider response. Any unmarked occurrence fails this test.
    allowed_context = re.compile(r"reassembly-of-parsed-address|lf-probe")
    offenders = []
    for path in root.rglob("*.py"):
        for lineno, line in enumerate(path.read_text().splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("#") or '"""' in stripped:
                continue
            # f-string or concat that yields  something@something
            if re.search(r'f["\'][^"\']*\{[^}]+\}@\{[^}]+\}', line) or \
               re.search(r'\+\s*["\']@["\']\s*\+', line):
                if not allowed_context.search(line):
                    offenders.append(f"{path.relative_to(root)}:{lineno}: {stripped}")
    assert not offenders, "possible email pattern generation:\n" + "\n".join(offenders)


def test_provider_adapters_reject_unsourced_emails():
    """Hunter/Apollo adapters must drop guessed results."""
    src = (
        __import__("pathlib").Path(__file__).resolve().parent.parent
        / "app" / "providers" / "email_finder" / "commercial.py"
    ).read_text()
    assert "if not sources and verification != \"valid\":" in src
    assert 'email_status != "verified"' in src
    assert "email-finder" not in src.split('"""')[2]  # guessing endpoint unused


# ------------------------------------------- obfuscation precision (regression)
@pytest.mark.parametrize("text,expected", [
    # Real obfuscation the site wrote for a human to retype.
    ("Email us at office.bayside (at) mailhost.tld (dot) com", "office.bayside@mailhost.tld.com"),
    ("Contact john [at] acmeroofing [dot] net", "john@acmeroofing.net"),
    ("sales AT acmeroofing DOT com", "sales@acmeroofing.com"),
    ("write to info {at} foo {dot} co {dot} uk", "info@foo.co.uk"),
    ("owner-at-bigco-dot-net", "owner@bigco.net"),
])
def test_obfuscated_forms_are_decoded(text, expected):
    assert expected in {e.address for e in ee.extract_obfuscated_emails(text, "u")}


@pytest.mark.parametrize("prose", [
    # A bare lowercase "at" in ordinary prose must never be read as an address.
    "Email us at office.bayside for a quote",
    "Please meet us at the office on Main Street",
    "We open at 9 and close at 5. See you at reception.",
    "Reach out to our team at our new location.",
    "Come visit us at 123 Main St, Dover DE",
    "Best rates at BigBank.com. Call today.",
    "Serving customers at home and at work since 2004.",
])
def test_prose_does_not_produce_fake_addresses(prose):
    assert ee.extract_obfuscated_emails(prose, "u") == []


# ------------------------------------- person matching precision (regression)
@pytest.mark.parametrize("local_part,name,expected", [
    ("rachel.kim.acme", "Rachel Kim", True),    # company suffix
    ("acme.rachel.kim", "Rachel Kim", True),    # company prefix
    ("jsmith.acme", "John Smith", True),
    ("kim.rachel", "Rachel Kim", True),
    ("r.kim", "Rachel Kim", True),
    ("john.smith2", "John Smith", True),
    ("rachelkimball", "Rachel Kim", False),     # different person, shared prefix
    ("kimberly", "Rachel Kim", False),
    ("tom.alvarez", "Rachel Kim", False),
    ("sales.team", "Rachel Kim", False),
    ("acme.info", "Rachel Kim", False),
])
def test_person_matching_is_segment_precise(local_part, name, expected):
    assert ee.local_part_matches_person(local_part, name) is expected

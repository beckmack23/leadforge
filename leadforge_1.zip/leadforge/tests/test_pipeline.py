"""Qualification, scoring, verification status logic, dedupe and people extraction."""
import pytest

from app.core import people_extract as pe
from app.core.normalize import (
    address_fingerprint,
    employee_range,
    extract_domain,
    normalize_company_name,
    normalize_phone,
    parse_money,
    revenue_range,
)
from app.core.titles import classify_title
from app.models import Company, Contact, EmailRecord, EmailStatus, EmailType, Signal
from app.pipeline.scoring import enrichment_percent, is_qualified, score_company
from app.pipeline.signals import detect_signals


def mk_company(**kw):
    defaults = dict(id=1, name="ABC HVAC LLC", name_normalized="abc hvac",
                    domain="abchvac.com", website="https://abchvac.com/",
                    website_status="live", lead_score=0, enrichment_pct=0.0,
                    is_qualified=False, pipeline_stage="discovered",
                    external_ids={}, scrape_notes={}, country="US")
    defaults.update(kw)
    c = Company(**defaults)
    c.emails = kw.pop("emails", [])
    c.contacts = kw.pop("contacts", [])
    c.signals = kw.pop("signals", [])
    c.sources = []
    return c


def mk_email(address="info@abchvac.com", etype=EmailType.GENERAL_BUSINESS.value,
             status=EmailStatus.VALID.value, **kw):
    local, dom = address.split("@")
    return EmailRecord(id=kw.pop("id", 1), company_id=1, address=address,
                       local_part=local, email_domain=dom, email_type=etype,
                       status=status, discovery_method="mailto_link",
                       source_type="website_contact_page", confidence=0.8,
                       is_role_account=kw.pop("is_role", False),
                       is_disposable=False,
                       is_free_provider=kw.pop("is_free", False), **kw)


# ------------------------------------------------------- QUALIFICATION RULE
@pytest.mark.parametrize("website,status,has_email,expected", [
    ("https://x.com/", "live", True, True),
    ("https://x.com/", "redirected", True, True),
    ("https://x.com/", "live", False, False),     # website, no email
    (None, "not_found", True, False),             # email, no website
    ("https://x.com/", "parked", True, False),    # parked isn't a real site
    ("https://x.com/", "unreachable", True, False),
    (None, "not_found", False, False),
])
def test_qualification_rule(website, status, has_email, expected):
    emails = [mk_email()] if has_email else []
    c = mk_company(website=website, website_status=status)
    c.emails = emails
    assert is_qualified(c) is expected


def test_invalid_email_does_not_qualify():
    c = mk_company()
    c.emails = [mk_email(status=EmailStatus.INVALID.value)]
    assert is_qualified(c) is False


def test_catch_all_and_risky_still_qualify():
    """Requirement: do not discard risky/catch-all — let the user filter."""
    for status in (EmailStatus.CATCH_ALL.value, EmailStatus.RISKY.value,
                   EmailStatus.UNKNOWN.value):
        c = mk_company()
        c.emails = [mk_email(status=status)]
        assert is_qualified(c) is True, status


def test_matrix_from_spec():
    """The exact table in the specification."""
    def build(website, email, owner, phone, revenue):
        c = mk_company(website="https://x.com/" if website else None,
                       website_status="live" if website else "not_found",
                       phone="+12155551234" if phone else None,
                       estimated_revenue=5_000_000 if revenue else None)
        c.emails = [mk_email()] if email else []
        c.contacts = [Contact(id=1, company_id=1, full_name="John Smith",
                              job_title="Owner", seniority="owner",
                              is_decision_maker=True, source_type="website_about_page",
                              confidence=0.8)] if owner else []
        return c

    assert score_company(build(1, 1, 1, 1, 1)).qualified is True
    assert score_company(build(1, 1, 0, 1, 0)).qualified is True
    assert score_company(build(1, 1, 0, 0, 0)).qualified is True
    assert score_company(build(1, 0, 1, 1, 1)).qualified is False
    assert score_company(build(0, 1, 1, 1, 1)).qualified is False


# ------------------------------------------------------------------ SCORING
def test_decision_maker_email_scores_above_general():
    general = mk_company()
    general.emails = [mk_email(etype=EmailType.GENERAL_BUSINESS.value)]
    dm = mk_company()
    dm.emails = [mk_email(address="john@abchvac.com",
                          etype=EmailType.DECISION_MAKER.value)]
    assert score_company(dm).total > score_company(general).total


def test_verified_scores_above_valid():
    a = mk_company(); a.emails = [mk_email(status=EmailStatus.VERIFIED.value)]
    b = mk_company(); b.emails = [mk_email(status=EmailStatus.VALID.value)]
    assert score_company(a).total > score_company(b).total


def test_unqualified_capped_below_qualified():
    rich_but_unqualified = mk_company(
        website="https://x.com/", website_status="live", phone="+12155551234",
        employee_count=42, estimated_revenue=9e6, founded_year=1999,
        industry="HVAC", naics="238220", sic="1711", num_locations=3,
        linkedin_url="https://linkedin.com/company/x",
        business_description="desc")
    rich_but_unqualified.contacts = [
        Contact(id=1, company_id=1, full_name="Jane Doe", job_title="CEO",
                seniority="c_level", is_decision_maker=True,
                source_type="website_team_page", confidence=0.9)]
    bare_qualified = mk_company()
    bare_qualified.emails = [mk_email()]

    assert score_company(rich_but_unqualified).total <= 25
    assert score_company(bare_qualified).total > 25


def test_score_bounds_and_components():
    c = mk_company(phone="+12155551234", address="1 Main St", city="Philadelphia",
                   state="PA", employee_count=40, estimated_revenue=8e6,
                   founded_year=2001, industry="HVAC", naics="238220", sic="1711",
                   num_locations=2, business_description="d",
                   linkedin_url="https://linkedin.com/company/x",
                   facebook_url="https://facebook.com/x")
    c.emails = [mk_email(address="john@abchvac.com",
                         etype=EmailType.DECISION_MAKER.value,
                         status=EmailStatus.VERIFIED.value)]
    c.contacts = [Contact(id=1, company_id=1, full_name="John Smith",
                          job_title="Owner", seniority="owner",
                          is_decision_maker=True, linkedin_url="https://l/in/j",
                          source_type="website_about_page", confidence=0.9)]
    c.signals = [Signal(id=1, company_id=1, signal_type="expansion", title="Expansion",
                        source_url="https://abchvac.com/news", source_type="website_news_page",
                        confidence=0.7)]
    b = score_company(c)
    assert 0 <= b.total <= 100
    assert b.email <= 40 and b.contact <= 20 and b.firmographic <= 20
    assert b.reachability <= 10 and b.signals <= 10
    assert b.total >= 80
    assert 0 <= b.enrichment_pct <= 100


def test_enrichment_percent_increases_with_data():
    bare = mk_company()
    bare.emails = [mk_email()]
    rich = mk_company(phone="+1", address="a", city="b", state="PA",
                      postal_code="19103", industry="HVAC", naics="1", sic="2",
                      employee_count=5, estimated_revenue=1e6, founded_year=2000,
                      num_locations=1, business_description="d",
                      linkedin_url="l", facebook_url="f", instagram_url="i")
    rich.emails = [mk_email()]
    assert enrichment_percent(rich) > enrichment_percent(bare)


# ------------------------------------------------------------ NORMALISATION
def test_company_name_normalisation():
    assert normalize_company_name("ABC Heating & Cooling, LLC") == "abc heating cooling"
    assert normalize_company_name("The Smith Company Inc.") == "smith"
    assert normalize_company_name("ABC Heating and Cooling LLC") == \
           normalize_company_name("ABC Heating & Cooling, L.L.C.")


def test_domain_extraction():
    assert extract_domain("https://WWW.ABC-HVAC.com/x?y=1") == "abc-hvac.com"
    assert extract_domain("http://shop.example.co.uk/") == "shop.example.co.uk"
    assert extract_domain("not a url") is None


def test_phone_normalisation():
    assert normalize_phone("(215) 555-1234") == "+12155551234"
    assert normalize_phone("1-215-555-1234") == "+12155551234"
    assert normalize_phone("+44 20 7946 0958") == "+442079460958"
    assert normalize_phone("555") is None


def test_address_fingerprint_matches_variants():
    a = address_fingerprint("123 Main Street", "Philadelphia", "19103")
    b = address_fingerprint("123 Main St.", "philadelphia", "19103-1234")
    assert a == b and a is not None
    assert address_fingerprint("Suite B", "X", "1") is None  # no street number


def test_range_bucketing():
    assert employee_range(1) == "1"
    assert employee_range(42) == "11-50"
    assert employee_range(300) == "201-500"
    assert revenue_range(2_000_000) == "$1M-$5M"
    assert revenue_range(750_000) == "$500K-$1M"
    assert parse_money("$1.5M") == 1_500_000
    assert parse_money("250k") == 250_000


# ------------------------------------------------------------------ TITLES
@pytest.mark.parametrize("title,is_dm", [
    ("Owner", True), ("Co-Owner", True), ("Founder & CEO", True),
    ("President", True), ("Managing Partner", True), ("Managing Member", True),
    ("CFO", True), ("Chief Financial Officer", True), ("General Manager", True),
    ("Vice President of Sales", True),
    ("Service Technician", False), ("Office Manager", False),
    ("Marketing Coordinator", False), ("Read more", False), ("", False),
])
def test_decision_maker_titles(title, is_dm):
    assert classify_title(title)[2] is is_dm


# ------------------------------------------------------------------ PEOPLE
def test_person_name_validation():
    assert pe.looks_like_person_name("John Smith")
    assert pe.looks_like_person_name("Mary-Anne O'Brien")
    assert not pe.looks_like_person_name("ABC Heating Inc")
    assert not pe.looks_like_person_name("Contact Us")
    assert not pe.looks_like_person_name("Philadelphia PA")
    assert not pe.looks_like_person_name("John")


def test_people_extracted_from_text():
    text = "Our Team\nJohn Smith, Owner\nMary Jones - Service Manager"
    people = pe.people_from_text(text, "https://x.com/team", "website_team_page")
    names = {p.full_name: p for p in people}
    assert "John Smith" in names and names["John Smith"].is_decision_maker
    assert "Mary Jones" in names and not names["Mary Jones"].is_decision_maker


def test_people_from_jsonld():
    ld = [{"@type": "Organization", "founder": {"@type": "Person", "name": "Dana Reed",
           "jobTitle": "Founder", "sameAs": ["https://www.linkedin.com/in/danareed"]}}]
    people = pe.people_from_jsonld(ld, "https://x.com/", "website_structured_data")
    assert people and people[0].full_name == "Dana Reed"
    assert people[0].is_decision_maker
    assert "linkedin.com/in/danareed" in people[0].linkedin_url


# ----------------------------------------------------------------- SIGNALS
def test_signal_detection_with_sources():
    from app.core.email_extract import PageExtract
    pages = [
        PageExtract(url="https://x.com/careers", page_kind="careers",
                    text="We are hiring! Apply today. Full-time positions with benefits "
                         "package. View job openings. Salary competitive."),
        PageExtract(url="https://x.com/news", page_kind="news",
                    text="ABC acquires Delta Mechanical, expanding into Ohio with a new "
                         "location opening this spring."),
    ]
    sigs = detect_signals(pages)
    kinds = {s.signal_type for s in sigs}
    assert "hiring" in kinds
    assert kinds & {"acquisition", "expansion", "new_location"}
    for s in sigs:
        assert s.source_url.startswith("https://x.com/")
        assert s.snippet


def test_no_signals_from_empty_pages():
    assert detect_signals([]) == []


# ------------------------------------- job-title cleanliness (regression)
@pytest.mark.parametrize("html,name,title,is_dm", [
    ('<div class="team-member"><h3>Rachel Kim</h3><p>Owner &amp; President</p>'
     '<a href="https://linkedin.com/in/rk">LinkedIn</a></div>',
     "Rachel Kim", "Owner & President", True),
    ('<div class="staff"><h4>Tom Alvarez</h4><span>Operations Manager</span>'
     '<a href="#">Read Bio</a><a href="mailto:t@x.com">Email</a></div>',
     "Tom Alvarez", "Operations Manager", False),
    ('<div class="person"><strong>Priya Nair</strong>'
     '<div>Chief Financial Officer</div></div>',
     "Priya Nair", "Chief Financial Officer", True),
    ('<div class="bio"><p>Dana Reed, Managing Partner</p></div>',
     "Dana Reed", "Managing Partner", True),
])
def test_titles_exclude_link_labels(html, name, title, is_dm):
    """A team card's link text ("LinkedIn", "Read Bio") must not leak into the title."""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "lxml")
    people = {p.full_name: p for p in pe.people_from_dom(soup, "u", "website_team_page")}
    assert name in people, f"{name} not extracted from {html}"
    person = people[name]
    assert person.job_title == title
    assert person.is_decision_maker is is_dm
    for junk in ("LinkedIn", "Email", "Read Bio", "Profile"):
        assert junk not in (person.job_title or "")


# ------------------------------- contact-extraction precision (regression)
def test_flattened_team_page_does_not_invent_contacts():
    """Cards run together in extracted text; naive parsing pairs a person with
    the NEXT card's name and title. None of that may become a contact."""
    flattened = ("Our Team Rachel Kim Owner & President LinkedIn "
                 "Tom Alvarez Operations Manager Priya Nair Chief Financial Officer")
    people = pe.people_from_text(flattened, "u", "website_team_page")
    names = {p.full_name for p in people}
    assert "Our Team" not in names
    for p in people:
        assert "LinkedIn" not in (p.job_title or "")
        # A title must never contain another person's name.
        assert "Priya Nair" not in (p.job_title or "")
        assert "Rachel Kim" not in (p.job_title or "")


@pytest.mark.parametrize("label", [
    "Our Team", "Meet The Team", "Our Staff", "Leadership Team",
    "Our People", "Management Team", "Our Mission", "Company History",
])
def test_section_headings_are_not_people(label):
    assert pe.looks_like_person_name(label) is False


def test_well_formed_text_still_extracts_people():
    people = {p.full_name: p for p in pe.people_from_text(
        "John Smith, Owner\nMary Jones - Service Manager", "u", "website_team_page")}
    assert people["John Smith"].is_decision_maker is True
    assert people["John Smith"].job_title == "Owner"
    assert people["Mary Jones"].is_decision_maker is False


def test_dom_extraction_suppresses_noisy_text_pass():
    """When markup yields structured cards, the free-text fallback must not run."""
    from app.core.email_extract import parse_page
    from app.pipeline.crawler import SiteCrawler, SiteProfile

    html = """<html><body>
      <h1>Our Team</h1>
      <div class="team-member"><h3>Rachel Kim</h3><p>Owner &amp; President</p>
        <a href="https://linkedin.com/in/rk">LinkedIn</a></div>
      <div class="team-member"><h3>Tom Alvarez</h3><p>Operations Manager</p></div>
      <div class="team-member"><h3>Priya Nair</h3><p>Chief Financial Officer</p></div>
    </body></html>"""
    page = parse_page(html, "https://x.test/team", "team")
    profile = SiteProfile(base_url="https://x.test/", domain="x.test")
    SiteCrawler()._absorb(profile, page)

    found = {p.full_name: p for p in profile.people}
    assert set(found) == {"Rachel Kim", "Tom Alvarez", "Priya Nair"}
    assert found["Rachel Kim"].job_title == "Owner & President"
    assert found["Tom Alvarez"].job_title == "Operations Manager"
    assert found["Priya Nair"].job_title == "Chief Financial Officer"
    assert found["Rachel Kim"].is_decision_maker is True
    assert found["Tom Alvarez"].is_decision_maker is False


@pytest.mark.parametrize("bad", [
    "Tom Alvarez Operations Manager",
    "Priya Nair Chief Financial Officer",
    "Rachel Kim Owner",
    "Sales Department Manager",
])
def test_name_run_into_title_is_rejected(bad):
    assert pe.looks_like_person_name(bad) is False


@pytest.mark.parametrize("good", [
    "Rachel Kim", "John Smith", "Ana de la Cruz", "Mary-Anne O'Brien",
])
def test_real_names_still_accepted(good):
    assert pe.looks_like_person_name(good) is True


# ---------------------------- port-distinguished hosts (regression)
def test_ip_hosts_keep_their_port():
    """Two local sites on the same IP but different ports are different sites.

    Dropping the port made them share a 'domain', so the dedupe step merged
    unrelated companies into one. Only affects IP-literal hosts; a real
    hostname still ignores the port.
    """
    assert extract_domain("http://127.0.0.1:8451/") == "127.0.0.1:8451"
    assert extract_domain("http://127.0.0.1:8452/") != extract_domain("http://127.0.0.1:8451/")
    assert extract_domain("http://127.0.0.2:8451/") == "127.0.0.2:8451"
    # Named hosts are unaffected: the port is not part of the identity.
    assert extract_domain("https://foo.com:8080/") == "foo.com"
    assert extract_domain("https://ABC-HVAC.com:443/") == "abc-hvac.com"

"""End-to-end: crawl a real HTTP site, run the full pipeline, export.

Spins up a throwaway HTTP server serving a realistic small-business site, then
drives the actual pipeline against it. No mocking of the crawler.
"""
import asyncio
import socket
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest
import pytest_asyncio

PAGES = {
    "/robots.txt": ("text/plain", "User-agent: *\nDisallow: /private/\nCrawl-delay: 0\n"),
    "/": ("text/html", """<!doctype html><html><head>
        <title>ABC Heating &amp; Cooling</title>
        <meta name="description" content="Family-owned HVAC contractor serving Bucks County since 1998.">
        <script type="application/ld+json">
        {"@context":"https://schema.org","@type":"HVACBusiness","name":"ABC Heating & Cooling LLC",
         "foundingDate":"1998","numberOfEmployees":{"@type":"QuantitativeValue","value":42},
         "address":{"@type":"PostalAddress","streetAddress":"123 Main Street",
                    "addressLocality":"Doylestown","addressRegion":"PA","postalCode":"18901"},
         "sameAs":["https://www.linkedin.com/company/abc-heating","https://www.facebook.com/abcheating"]}
        </script></head><body>
        <nav><a href="/about-us">About Us</a><a href="/contact">Contact</a>
             <a href="/our-team">Our Team</a><a href="/careers">Careers</a>
             <a href="/news">News</a><a href="/private/secret">Private</a></nav>
        <h1>ABC Heating &amp; Cooling</h1>
        <p>Call us at (215) 555-0148 or email <a href="mailto:info@abcheating.example">info@abcheating.example</a>.</p>
        </body></html>"""),
    "/contact": ("text/html", """<!doctype html><html><head><title>Contact</title></head><body>
        <h1>Contact Us</h1>
        <p>Phone: (215) 555-0148</p>
        <p>General enquiries: <a href="mailto:info@abcheating.example">info@abcheating.example</a></p>
        <p>Owner direct: <a href="mailto:jsmith@abcheating.example">jsmith@abcheating.example</a></p>
        <p>Service dept: service (at) abcheating (dot) example</p>
        </body></html>"""),
    "/about-us": ("text/html", """<!doctype html><html><head><title>About</title></head><body>
        <h1>About ABC Heating</h1>
        <p>Established 1998, ABC Heating has grown to a team of 42 employees across
           3 locations in southeastern Pennsylvania.</p>
        <p>John Smith, Owner</p>
        </body></html>"""),
    "/our-team": ("text/html", """<!doctype html><html><head><title>Team</title></head><body>
        <div class="team-member"><h3>John Smith</h3><p>Owner &amp; President</p>
          <a href="https://www.linkedin.com/in/johnsmithhvac">LinkedIn</a></div>
        <div class="team-member"><h3>Maria Lopez</h3><p>Service Manager</p></div>
        <div class="team-member"><h3>Dan Price</h3><p>Chief Financial Officer</p></div>
        </body></html>"""),
    "/careers": ("text/html", """<!doctype html><html><head><title>Careers</title></head><body>
        <h1>Now Hiring</h1>
        <p>We are hiring! Join our growing team. Apply today.</p>
        <ul><li>HVAC Technician — Full-time — Salary + benefits package</li>
            <li>Install Helper — Full-time — Apply now</li></ul>
        </body></html>"""),
    "/news": ("text/html", """<!doctype html><html><head><title>News</title></head><body>
        <h1>News</h1>
        <p>ABC Heating acquires Delta Mechanical, expanding into Lehigh Valley.
           Our new location opens this spring, and we have invested in a new fleet
           of 12 service trucks.</p>
        </body></html>"""),
    "/private/secret": ("text/html", "<html><body>ceo@abcheating.example should never be crawled</body></html>"),
}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        path = self.path.split("?")[0]
        if path not in PAGES:
            self.send_error(404)
            return
        ctype, body = PAGES[path]
        data = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", f"{ctype}; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):  # silence
        pass


@pytest.fixture(scope="module")
def site():
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    server = HTTPServer(("127.0.0.1", port), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest_asyncio.fixture
async def client():
    from app.config import settings
    from app.core.http import get_client, shutdown_client
    settings.per_host_delay_seconds = 0.0
    c = get_client()
    await c.start()
    yield c
    await shutdown_client()


@pytest.fixture
def resolvable_mx(monkeypatch):
    """Pretend abcheating.example has MX records.

    The fixture site uses the reserved .example TLD, which by design has no MX,
    so the verifier correctly marks its addresses INVALID. That behaviour is
    asserted separately in test_undeliverable_domain_is_invalid; here we stub
    DNS so the rest of the pipeline can be exercised.
    """
    from app.providers.email_verify.local_verifier import LocalVerifier

    async def fake_mx(self, domain):
        return (True, f"mx.{domain}") if domain.endswith("abcheating.example") else (False, None)

    monkeypatch.setattr(LocalVerifier, "_mx_lookup", fake_mx)
    yield


# ------------------------------------------------------------------ crawler
@pytest.mark.asyncio
async def test_crawler_extracts_everything(site, client):
    from app.pipeline.crawler import SiteCrawler

    crawler = SiteCrawler(max_pages=10)
    status, _ = await crawler.validate(site)
    assert status == "live"

    profile = await crawler.crawl(site)
    assert profile.reachable

    addrs = {e.address for e in profile.emails}
    assert "info@abcheating.example" in addrs
    assert "jsmith@abcheating.example" in addrs
    assert "service@abcheating.example" in addrs          # deobfuscated
    assert "ceo@abcheating.example" not in addrs          # robots.txt respected

    names = {p.full_name for p in profile.people}
    assert "John Smith" in names and "Dan Price" in names
    john = next(p for p in profile.people if p.full_name == "John Smith")
    assert john.is_decision_maker and "linkedin.com/in/" in (john.linkedin_url or "")

    assert profile.founded_year == 1998
    assert profile.employee_hint == 42
    assert profile.locations_hint == 3 or profile.locations_hint is None
    assert "linkedin" in profile.social and "facebook" in profile.social
    assert profile.phones
    assert profile.addresses and profile.addresses[0]["postal_code"] == "18901"

    from app.pipeline.signals import detect_signals
    kinds = {s.signal_type for s in detect_signals(profile.pages)}
    assert "hiring" in kinds
    assert kinds & {"acquisition", "expansion", "new_location", "equipment_purchase"}


@pytest.mark.asyncio
async def test_robots_disallow_is_enforced(site, client):
    res = await client.fetch(f"{site}/private/secret")
    assert res.ok is False
    assert res.reason == "robots_disallowed"


# ----------------------------------------------------------- full pipeline
@pytest.mark.asyncio
async def test_full_pipeline_and_export(site, tmp_path, client, monkeypatch, resolvable_mx):
    from app.config import settings
    from app.db import init_db, make_engine, session_scope
    from app.models import Company, Job, JobStatus
    from app.pipeline.orchestrator import JobRunner
    from app.providers.base import DiscoveredBusiness
    from app.schemas import SearchCriteria

    monkeypatch.setattr(settings, "database_url",
                        f"sqlite+aiosqlite:///{tmp_path/'t.db'}")
    import app.db as dbmod
    from sqlalchemy.ext.asyncio import async_sessionmaker
    dbmod.engine = make_engine(settings.database_url)
    dbmod.SessionLocal = async_sessionmaker(dbmod.engine, expire_on_commit=False)
    await init_db()

    criteria = SearchCriteria(industry="hvac", state="PA")
    async with session_scope() as s:
        job = Job(name="test", query=criteria.model_dump(mode="json"),
                  target_count=5, status=JobStatus.QUEUED.value, stats={})
        s.add(job)
        await s.flush()
        job_id = job.id

    runner = JobRunner(job_id)
    biz = DiscoveredBusiness(name="ABC Heating & Cooling LLC", website=site,
                             city="Doylestown", state="PA", industry="HVAC",
                             provider="test_fixture")
    ids = await runner._persist_discovered([biz], criteria)
    assert len(ids) == 1
    await runner._enrich_all(ids)

    async with session_scope() as s:
        c = await s.get(Company, ids[0])
        assert c is not None

        # --- the only rule that matters ---
        assert c.is_qualified is True
        assert c.website and c.website_status in ("live", "redirected")
        assert any(e.is_usable for e in c.emails)

        # --- email tiering: the owner's address must outrank info@ ---
        best = c.best_email
        assert best.address == "jsmith@abcheating.example"
        assert best.email_type == "decision_maker"
        assert best.status in ("valid", "verified", "unknown", "risky", "invalid")
        assert best.discovery_method in ("mailto_link", "page_text", "structured_data")
        assert best.source_url and best.source_url.startswith(site)

        addrs = {e.address for e in c.emails}
        assert "info@abcheating.example" in addrs
        assert "ceo@abcheating.example" not in addrs

        # --- nothing invented ---
        for e in c.emails:
            assert e.discovery_method != "generated"
            assert e.source_url or e.provider

        # --- contacts ---
        dm = [x for x in c.contacts if x.is_decision_maker]
        assert any(x.full_name == "John Smith" for x in dm)

        # --- firmographics from the site ---
        assert c.founded_year == 1998
        assert c.employee_count == 42
        assert c.employee_range == "11-50"
        assert c.linkedin_url and "linkedin.com/company" in c.linkedin_url
        assert c.naics == "238220"

        # --- signals with sources ---
        assert c.signals
        assert all(s.source_url.startswith(site) for s in c.signals)

        # --- source tracking ---
        fields = {s.field for s in c.sources}
        assert {"website", "email"} <= fields
        email_src = next(s for s in c.sources if s.field == "email")
        assert email_src.source_url.startswith(site)

        # --- score ---
        assert c.lead_score >= 30
        assert 0 < c.enrichment_pct <= 100

        # --- exports ---
        from app.export.exporters import to_csv, to_json, to_xlsx
        csv_bytes = to_csv([c], "outbound_leads")
        header = csv_bytes.decode("utf-8-sig").splitlines()[0]
        assert header.split(",") == [
            "First Name", "Last Name", "Company", "Website", "Email", "Email Status",
            "Phone", "Industry", "Employees", "Revenue", "City", "State",
            "LinkedIn", "Lead Score"]
        assert "jsmith@abcheating.example" in csv_bytes.decode("utf-8-sig")

        xlsx = to_xlsx([c], "full")
        assert xlsx[:2] == b"PK" and len(xlsx) > 5000

        import json
        payload = json.loads(to_json([c], "full"))
        assert payload["count"] == 1
        lead = payload["leads"][0]
        assert lead["sources"] and lead["emails"] and lead["contacts"]
        assert lead["signals"]


@pytest.mark.asyncio
async def test_website_without_email_is_not_qualified(site, tmp_path, client, monkeypatch):
    """A site with a website but no discoverable email must NOT count as a lead."""
    from app.models import Company, EmailStatus
    from app.pipeline.scoring import is_qualified

    c = Company(id=99, name="No Email Co", website="https://x.example/",
                website_status="live", external_ids={}, scrape_notes={})
    c.emails = []
    c.contacts = []
    c.signals = []
    c.sources = []
    assert is_qualified(c) is False
    _ = EmailStatus, site, tmp_path, client, monkeypatch


@pytest.mark.asyncio
async def test_undeliverable_domain_is_invalid(client):
    """A domain with no MX must be marked INVALID, not quietly accepted."""
    from app.providers.email_verify.local_verifier import LocalVerifier

    res = await LocalVerifier().verify("owner@abcheating.example")
    assert res.status == "invalid"
    assert res.mx_found is False
    assert res.detail["reason"] == "no_mx_records"


@pytest.mark.asyncio
async def test_verifier_never_claims_verified_without_proof(client, monkeypatch):
    """With no SMTP probe and no commercial verifier, the ceiling is 'valid'."""
    from app.config import settings
    from app.providers.email_verify.local_verifier import LocalVerifier

    monkeypatch.setattr(settings, "smtp_probe_enabled", False)

    async def fake_mx(self, domain):
        return True, "mx.test"

    monkeypatch.setattr(LocalVerifier, "_mx_lookup", fake_mx)
    res = await LocalVerifier().verify("owner@somerealbusiness.test")
    assert res.status == "valid"
    assert res.status != "verified"
    assert "not individually proven" in res.detail["note"]


@pytest.mark.asyncio
async def test_syntax_failure_is_invalid(client):
    from app.providers.email_verify.local_verifier import LocalVerifier
    for bad in ["notanemail", "a@@b.com", "@nope.com", "spaces in@x.com"]:
        res = await LocalVerifier().verify(bad)
        assert res.status == "invalid", bad
        assert res.syntax_ok is False

"""Deployment safety: authentication, fail-closed startup, DB URL handling.

These guard the properties that matter once the app has a public URL, where a
mistake means handing the lead database to anyone who finds it.
"""
import base64

import httpx
import pytest
import pytest_asyncio

from app.config import Settings


def auth_header(user: str, password: str) -> dict:
    token = base64.b64encode(f"{user}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


# ---------------------------------------------------------------- fail closed
def test_public_bind_without_password_is_refused():
    s = Settings(host="0.0.0.0", auth_password=None)
    problem = s.startup_error()
    assert problem is not None
    assert "AUTH_PASSWORD" in problem
    assert s.require_auth is True


def test_localhost_without_password_is_allowed():
    s = Settings(host="127.0.0.1", auth_password=None)
    assert s.startup_error() is None
    assert s.require_auth is False


def test_public_bind_with_password_is_allowed():
    s = Settings(host="0.0.0.0", auth_password="a-long-enough-password")
    assert s.startup_error() is None
    assert s.require_auth is True


def test_short_password_is_refused():
    s = Settings(host="0.0.0.0", auth_password="short")
    assert "at least 8" in (s.startup_error() or "")


def test_password_on_localhost_still_enforces_auth():
    """Opting into a password locally must actually turn auth on."""
    s = Settings(host="127.0.0.1", auth_password="a-long-enough-password")
    assert s.require_auth is True


# ------------------------------------------------------------ database URLs
@pytest.mark.parametrize("given,expected", [
    # What Railway/Heroku actually inject:
    ("postgres://u:p@host:5432/db", "postgresql+asyncpg://u:p@host:5432/db"),
    ("postgresql://u:p@host:5432/db", "postgresql+asyncpg://u:p@host:5432/db"),
    # Already correct, left alone:
    ("postgresql+asyncpg://u:p@h/db", "postgresql+asyncpg://u:p@h/db"),
    # sslmode is libpq syntax; asyncpg rejects it.
    ("postgresql://u:p@h/db?sslmode=require", "postgresql+asyncpg://u:p@h/db"),
    ("postgresql://u:p@h/db?sslmode=require&application_name=lf",
     "postgresql+asyncpg://u:p@h/db?application_name=lf"),
    # SQLite gets the async driver too.
    ("sqlite:///./leadforge.db", "sqlite+aiosqlite:///./leadforge.db"),
    ("sqlite+aiosqlite:////data/leadforge.db", "sqlite+aiosqlite:////data/leadforge.db"),
])
def test_database_url_normalisation(given, expected):
    assert Settings(database_url=given).effective_database_url == expected


def test_is_postgres_detection():
    assert Settings(database_url="postgres://u:p@h/db").is_postgres is True
    assert Settings(database_url="sqlite:///x.db").is_postgres is False


def test_connection_password_is_redacted_in_logs():
    from app.db import _safe_url
    safe = _safe_url("postgresql+asyncpg://user:sup3rsecret@host:5432/db")
    assert "sup3rsecret" not in safe
    assert "user" in safe and "host:5432/db" in safe


# ------------------------------------------------------------------- CORS
def test_cors_origins_include_localhost_and_extras():
    s = Settings(port=8000, allowed_origins="https://leads.example.com/, https://x.dev")
    origins = s.cors_origins()
    assert "http://127.0.0.1:8000" in origins
    assert "https://leads.example.com" in origins   # trailing slash stripped
    assert "https://x.dev" in origins


# ------------------------------------------------- live middleware behaviour
@pytest_asyncio.fixture
async def secured_app(tmp_path, monkeypatch):
    """The real app with auth switched on, driven in-process."""
    from app.config import settings as live

    monkeypatch.setattr(live, "database_url",
                        f"sqlite+aiosqlite:///{tmp_path/'auth.db'}")
    monkeypatch.setattr(live, "host", "0.0.0.0")
    monkeypatch.setattr(live, "auth_username", "admin")
    monkeypatch.setattr(live, "auth_password", "correct-horse-battery")

    import app.db as dbmod
    from sqlalchemy.ext.asyncio import async_sessionmaker
    dbmod.engine = dbmod.make_engine(live.effective_database_url)
    dbmod.SessionLocal = async_sessionmaker(dbmod.engine, expire_on_commit=False)

    from app.core import http as httpmod
    await httpmod.shutdown_client()
    await dbmod.engine.dispose()

    from app.main import app as fastapi_app
    transport = httpx.ASGITransport(app=fastapi_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        async with fastapi_app.router.lifespan_context(fastapi_app):
            yield client
    await httpmod.shutdown_client()


PROTECTED = [
    "/api/leads", "/api/jobs", "/api/stats", "/api/meta",
    "/api/export/columns", "/api/diagnostics", "/",
]


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PROTECTED)
async def test_anonymous_requests_are_rejected(secured_app, path):
    r = await secured_app.get(path)
    assert r.status_code == 401, f"{path} was reachable without credentials"
    assert "basic" in r.headers.get("www-authenticate", "").lower()


@pytest.mark.asyncio
async def test_export_endpoint_is_protected(secured_app):
    """The export endpoints hand over the whole database - they must be gated."""
    r = await secured_app.post("/api/export", json={"format": "csv",
                                                    "preset": "outbound_leads",
                                                    "filters": {}})
    assert r.status_code == 401


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PROTECTED)
async def test_valid_credentials_are_accepted(secured_app, path):
    r = await secured_app.get(path, headers=auth_header("admin", "correct-horse-battery"))
    assert r.status_code == 200, f"{path} rejected valid credentials: {r.text[:200]}"


@pytest.mark.asyncio
@pytest.mark.parametrize("user,password", [
    ("admin", "wrong-password-here"),
    ("wronguser", "correct-horse-battery"),
    ("admin", ""),
    ("", ""),
    ("admin", "correct-horse-batter"),    # one character short
    ("ADMIN", "correct-horse-battery"),   # case must match
])
async def test_bad_credentials_are_rejected(secured_app, user, password):
    r = await secured_app.get("/api/leads", headers=auth_header(user, password))
    assert r.status_code == 401


@pytest.mark.asyncio
@pytest.mark.parametrize("header", [
    "Basic !!!not-base64!!!",
    "Basic " + base64.b64encode(b"no-colon-here").decode(),
    "Bearer some-token",
    "",
])
async def test_malformed_authorization_headers_are_rejected(secured_app, header):
    r = await secured_app.get("/api/leads", headers={"Authorization": header})
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_health_is_public_but_reveals_nothing(secured_app):
    """The host needs an unauthenticated probe; it must not leak configuration."""
    r = await secured_app.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert set(body) == {"ok", "database"}
    text = r.text.lower()
    for leak in ("capabilit", "provider", "api_key", "password", "running_jobs"):
        assert leak not in text

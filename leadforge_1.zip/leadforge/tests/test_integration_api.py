"""Full-stack integration test: real FastAPI app, real crawler, real fixture sites.

Four small-business sites are served on four distinct loopback addresses so the
pipeline sees genuinely different hosts. The test then drives the actual HTTP
API end to end: import -> job -> progress metrics -> lead listing -> filters ->
lead detail with sources -> exports.
"""
import asyncio
import io
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import httpx
import pytest
import pytest_asyncio

# ---------------------------------------------------------------- fixture sites

def _build(name, contact_body, extra_head="", extra_body=""):
    slug = name.lower().replace(" ", "-")
    return {
        "/robots.txt": ("text/plain", "User-agent: *\nDisallow: /admin/\n"),
        "/": ("text/html", f"""<html><head><title>{name}</title>
<meta name="description" content="{name} - commercial contractor serving Delaware since 2004.">
<script type="application/ld+json">{{"@context":"https://schema.org","@type":"LocalBusiness",
"name":"{name}","foundingDate":"2004",
"address":{{"@type":"PostalAddress","streetAddress":"88 Industrial Way",
"addressLocality":"Wilmington","addressRegion":"DE","postalCode":"19801"}},
"sameAs":["https://www.linkedin.com/company/{slug}","https://www.facebook.com/{slug}"]}}</script>
{extra_head}</head><body>
<nav><a href="/contact">Contact</a><a href="/about">About Us</a>
     <a href="/team">Our Team</a><a href="/careers">Careers</a><a href="/admin/x">Admin</a></nav>
<h1>{name}</h1><p>Call (302) 555-0142 for service.</p>{extra_body}</body></html>"""),
        "/contact": ("text/html",
                     f"<html><head><title>Contact</title></head><body><h1>Contact Us</h1>"
                     f"<p>Phone: (302) 555-0142</p>{contact_body}</body></html>"),
        "/about": ("text/html",
                   "<html><head><title>About</title></head><body><p>Established 2004. "
                   "Today we are a team of 28 employees working across 2 locations.</p>"
                   "</body></html>"),
        "/team": ("text/html", """<html><head><title>Team</title></head><body>
<div class="team-member"><h3>Rachel Kim</h3><p>Owner &amp; President</p>
  <a href="https://www.linkedin.com/in/rachelkim">LinkedIn</a></div>
<div class="team-member"><h3>Tom Alvarez</h3><p>Operations Manager</p></div>
</body></html>"""),
        "/careers": ("text/html", """<html><head><title>Careers</title></head><body>
<h1>Now Hiring</h1><p>We are hiring! Join our growing team. Apply today.</p>
<ul><li>Lead Technician - Full-time - Salary and benefits package</li>
    <li>Apprentice - Full-time - Apply now</li></ul></body></html>"""),
        # robots.txt disallows /admin/ - this address must never be collected.
        "/admin/x": ("text/html", "<html><body>hidden@nowhere.test</body></html>"),
    }


SITES = {
    # QUALIFIED - decision-maker address that ties to a named owner
    "127.0.0.2": _build("Acme Mechanical",
        '<p>Owner direct: <a href="mailto:rkim@acme-mechanical.test">rkim@acme-mechanical.test</a></p>'
        '<p>General: <a href="mailto:info@acme-mechanical.test">info@acme-mechanical.test</a></p>'),
    # QUALIFIED - general business address, written obfuscated for human readers
    "127.0.0.3": _build("Bayside Plumbing",
        '<p>Email us at office (at) bayside-plumbing (dot) test</p>'),
    # NOT QUALIFIED - live website, but no address published anywhere
    "127.0.0.4": _build("Cobalt Roofing",
        '<p>Please use the contact form below. We do not publish an email address.</p>'),
    # QUALIFIED - address only in JSON-LD structured data
    "127.0.0.5": _build("Delmar Electric",
        '<p>Reach the office by phone during business hours.</p>',
        extra_head='<script type="application/ld+json">{"@type":"Electrician",'
                   '"name":"Delmar Electric","email":"contact@delmar-electric.test"}</script>'),
}

PORT = 8451


def _handler(pages):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            path = self.path.split("?")[0]
            if path not in pages:
                self.send_error(404)
                return
            ctype, body = pages[path]
            data = body.encode()
            self.send_response(200)
            self.send_header("Content-Type", f"{ctype}; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *a):
            pass
    return H


@pytest.fixture(scope="module")
def sites():
    servers = []
    for ip, pages in SITES.items():
        try:
            srv = HTTPServer((ip, PORT), _handler(pages))
        except OSError as exc:  # pragma: no cover - platform without 127.0.0.0/8 aliases
            pytest.skip(f"cannot bind {ip}: {exc}")
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        servers.append(srv)
    yield {ip: f"http://{ip}:{PORT}/" for ip in SITES}
    for srv in servers:
        srv.shutdown()


CSV = """company,website,city,state,industry
Acme Mechanical,http://127.0.0.2:{p}/,Wilmington,DE,HVAC
Bayside Plumbing,http://127.0.0.3:{p}/,Wilmington,DE,Plumbing
Cobalt Roofing,http://127.0.0.4:{p}/,Wilmington,DE,Roofing
Delmar Electric,http://127.0.0.5:{p}/,Wilmington,DE,Electrical
Acme Mechanical LLC,http://127.0.0.2:{p}/,Wilmington,DE,HVAC
Ghost Industries,http://127.0.0.9:{p}/,Dover,DE,Manufacturing
Nowebsite Co,,Dover,DE,Consulting
""".format(p=PORT)


@pytest_asyncio.fixture
async def api(tmp_path, monkeypatch):
    """The real FastAPI app, driven in-process over ASGI."""
    from app.config import settings

    monkeypatch.setattr(settings, "database_url",
                        f"sqlite+aiosqlite:///{tmp_path/'it.db'}")
    monkeypatch.setattr(settings, "per_host_delay_seconds", 0.0)
    monkeypatch.setattr(settings, "worker_concurrency", 4)
    monkeypatch.setattr(settings, "http_timeout_seconds", 8.0)

    import app.db as dbmod
    from sqlalchemy.ext.asyncio import async_sessionmaker
    dbmod.engine = dbmod.make_engine(settings.database_url)
    dbmod.SessionLocal = async_sessionmaker(dbmod.engine, expire_on_commit=False)

    # Loopback must not go through any ambient HTTP proxy.
    from app.core import http as httpmod
    await httpmod.shutdown_client()
    await dbmod.engine.dispose()

    from app.main import app as fastapi_app
    transport = httpx.ASGITransport(app=fastapi_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test",
                                 timeout=60.0) as client:
        # Trigger startup (init_db, client start, orphan recovery).
        async with fastapi_app.router.lifespan_context(fastapi_app):
            httpmod.get_client()._client = httpx.AsyncClient(
                follow_redirects=True, trust_env=False,
                timeout=httpx.Timeout(settings.http_timeout_seconds),
                headers={"User-Agent": settings.effective_user_agent},
            )
            yield client
    await httpmod.shutdown_client()


@pytest.fixture
def resolvable_mx(monkeypatch):
    """The fixture sites use reserved .test addresses; stub MX so verification runs."""
    from app.providers.email_verify.local_verifier import LocalVerifier

    async def fake_mx(self, domain):
        return (True, f"mx.{domain}") if domain.endswith(".test") else (False, None)

    monkeypatch.setattr(LocalVerifier, "_mx_lookup", fake_mx)
    yield


async def _wait_for_job(api, job_id, timeout=90):
    for _ in range(int(timeout / 0.5)):
        r = await api.get(f"/api/jobs/{job_id}/progress")
        data = r.json()
        if data["status"] in ("completed", "failed", "cancelled"):
            return data
        await asyncio.sleep(0.5)
    raise AssertionError(f"job {job_id} did not finish: {data}")


@pytest.mark.asyncio
async def test_full_stack(sites, api, resolvable_mx):
    # ---------------- meta ----------------
    meta = (await api.get("/api/meta")).json()
    assert meta["qualification_rule"] == "QUALIFIED LEAD = valid website + business email"
    assert "openstreetmap" in meta["capabilities"]["discovery"]
    assert meta["capabilities"]["can_reach_verified_status"] is False  # honest

    # ---------------- NL parsing ----------------
    parsed = (await api.post("/api/parse", json={
        "text": "Roofing companies with 10-100 employees in Pennsylvania"})).json()
    assert parsed["criteria"]["industry"] == "roofing"
    assert parsed["criteria"]["state"] == "PA"
    assert parsed["criteria"]["employee_min"] == 10
    assert parsed["criteria"]["employee_max"] == 100

    # ---------------- import + run pipeline ----------------
    files = {"file": ("companies.csv", io.BytesIO(CSV.encode()), "text/csv")}
    r = await api.post("/api/import", files=files)
    assert r.status_code == 201, r.text
    job_id = r.json()["id"]

    progress = await _wait_for_job(api, job_id)
    assert progress["status"] == "completed", progress
    m = progress["metrics"]

    # 7 CSV rows; the duplicate website collapses to 6 distinct companies.
    assert m["businesses_found"] == 6
    # 4 fixture sites are live; the dead host and the blank website are not.
    assert m["websites_found"] == 4
    # 3 of the 4 live sites publish an address.
    assert m["emails_found"] == 3
    assert m["verified_or_valid_emails"] == 3
    assert m["qualified_leads"] == 3
    assert m["decision_makers_found"] >= 1
    assert progress["progress"]["pct"] == 100.0

    # ---------------- lead listing ----------------
    leads = (await api.get("/api/leads", params={"job_id": job_id,
                                                 "qualified_only": True})).json()
    assert leads["total"] == 3
    names = {L["name"] for L in leads["items"]}
    assert names == {"Acme Mechanical", "Bayside Plumbing", "Delmar Electric"}
    assert "Cobalt Roofing" not in names        # website but no email
    assert "Ghost Industries" not in names      # dead website
    assert "Nowebsite Co" not in names          # no website

    for L in leads["items"]:
        assert L["is_qualified"] is True
        assert L["primary_email"] and L["website"]
        assert L["lead_score"] >= 30

    # Unqualified records are retained and visible, just not counted as leads.
    everything = (await api.get("/api/leads", params={"job_id": job_id,
                                                      "qualified_only": False})).json()
    assert everything["total"] == 6
    cobalt = next(L for L in everything["items"] if L["name"] == "Cobalt Roofing")
    assert cobalt["is_qualified"] is False
    assert cobalt["website_status"] == "live"
    assert cobalt["primary_email"] is None
    assert cobalt["lead_score"] <= 25          # capped below every qualified lead

    # ---------------- tiering ----------------
    acme = next(L for L in leads["items"] if L["name"] == "Acme Mechanical")
    assert acme["primary_email"] == "rkim@acme-mechanical.test"
    assert acme["primary_email_type"] == "decision_maker"
    assert acme["contact_name"] == "Rachel Kim"
    assert acme["contact_title"] and "Owner" in acme["contact_title"]

    bayside = next(L for L in leads["items"] if L["name"] == "Bayside Plumbing")
    assert bayside["primary_email"] == "office@bayside-plumbing.test"

    delmar = next(L for L in leads["items"] if L["name"] == "Delmar Electric")
    assert delmar["primary_email"] == "contact@delmar-electric.test"

    # ---------------- filters ----------------
    async def count(**params):
        params.setdefault("job_id", job_id)
        return (await api.get("/api/leads", params=params)).json()["total"]

    assert await count(has_decision_maker=True) >= 1
    assert await count(email_type=["decision_maker"]) == 1
    # All three publish at least one general address (Acme has info@ alongside
    # the owner's), so the type filter matches "has an email of this type".
    assert await count(email_type=["general_business"]) == 3
    assert await count(email_status=["valid"]) == 3
    assert await count(email_status=["invalid"]) == 0
    assert await count(state="DE") == 3
    assert await count(state="CA") == 0
    assert await count(q="bayside") == 1
    assert await count(score_min=99) <= 3
    assert await count(employee_min=20, employee_max=40) == 3   # "28 employees"

    # ---------------- detail + source tracking ----------------
    detail = (await api.get(f"/api/leads/{acme['id']}")).json()
    assert len(detail["emails"]) >= 2
    top = detail["emails"][0]
    assert top["address"] == "rkim@acme-mechanical.test"
    assert top["discovery_method"] == "mailto_link"
    assert top["source_url"].startswith("http://127.0.0.2")
    assert top["verification_provider"] == "local_mx"
    assert top["status"] == "valid"          # never "verified" without proof
    assert "not individually proven" in top["validation_detail"]["note"]

    # robots.txt was honoured throughout
    all_addrs = {e["address"] for e in detail["emails"]}
    assert "hidden@nowhere.test" not in all_addrs

    src = {s["field"]: s for s in detail["sources"]}
    assert src["website"]["source_url"].startswith("http://127.0.0.2")
    assert src["email"]["source_url"].startswith("http://127.0.0.2")
    assert src["founded_year"]["value"] == "2004"
    assert src["employee_count"]["is_estimate"] is True     # scraped, not confirmed
    assert detail["founded_year"] == 2004
    assert detail["employee_count"] == 28
    assert detail["naics"] == "238220"
    assert "linkedin.com/company" in (detail["linkedin_url"] or "")

    assert detail["signals"], "expected hiring signal from the careers page"
    assert all(s["source_url"].startswith("http://127.0.0.2") for s in detail["signals"])
    assert "hiring" in {s["signal_type"] for s in detail["signals"]}

    score = (await api.get(f"/api/leads/{acme['id']}/score")).json()
    assert score["qualified"] is True
    assert sum(c["points"] for c in score["components"].values()) > 0
    assert score["rule"] == "QUALIFIED LEAD = valid website + business email"

    # ---------------- exports ----------------
    body = {"format": "csv", "preset": "outbound_leads",
            "filters": {"job_id": job_id, "qualified_only": True, "limit": 1000}}
    r = await api.post("/api/export", json=body)
    assert r.status_code == 200
    assert r.headers["X-Row-Count"] == "3"
    text = r.content.decode("utf-8-sig")
    assert text.splitlines()[0] == (
        "First Name,Last Name,Company,Website,Email,Email Status,Phone,Industry,"
        "Employees,Revenue,City,State,LinkedIn,Lead Score")
    assert "rkim@acme-mechanical.test" in text
    assert "Rachel,Kim" in text
    assert "Cobalt Roofing" not in text

    body["format"] = "xlsx"
    body["preset"] = "full"
    r = await api.post("/api/export", json=body)
    assert r.status_code == 200 and r.content[:2] == b"PK"

    body["format"] = "json"
    r = await api.post("/api/export", json=body)
    payload = r.json()
    assert payload["count"] == 3
    for lead in payload["leads"]:
        assert lead["email"], "every exported lead must carry an email"
        assert lead["website"]
        assert lead["sources"]
        for e in lead["emails"]:
            assert e["source_url"] or e["discovery_method"].startswith("provider:")

    # ---------------- global stats ----------------
    stats = (await api.get("/api/stats")).json()
    assert stats["qualified_leads"] == 3
    assert stats["companies"] == 6
    assert stats["emails_by_type"]["decision_maker"] == 1


@pytest.mark.asyncio
async def test_rerun_uses_cache_and_is_idempotent(sites, api, resolvable_mx):
    """Re-running must not duplicate companies, and should hit the crawl cache."""
    files = {"file": ("companies.csv", io.BytesIO(CSV.encode()), "text/csv")}
    first = (await api.post("/api/import", files=files)).json()
    await _wait_for_job(api, first["id"])
    before = (await api.get("/api/stats")).json()

    files = {"file": ("companies.csv", io.BytesIO(CSV.encode()), "text/csv")}
    second = (await api.post("/api/import", files=files)).json()
    progress = await _wait_for_job(api, second["id"])

    after = (await api.get("/api/stats")).json()
    assert after["companies"] == before["companies"], "re-import created duplicates"
    assert after["qualified_leads"] == before["qualified_leads"]
    assert progress["internal"]["cache_hits"] > 0, "expected crawl cache hits on re-run"


@pytest.mark.asyncio
async def test_search_requires_industry_and_location(api):
    r = await api.post("/api/jobs", json={"criteria": {"state": "PA"}, "target_count": 10})
    assert r.status_code == 400
    assert "industry" in r.json()["detail"].lower()

    r = await api.post("/api/jobs", json={"criteria": {"industry": "hvac"},
                                          "target_count": 10})
    assert r.status_code == 400
    assert "location" in r.json()["detail"].lower()

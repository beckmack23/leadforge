"""LeadForge - B2B lead discovery and enrichment platform."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .api import exports, jobs, leads
from .auth import BasicAuthMiddleware
from .config import settings
from .core.http import get_client, shutdown_client
from .db import healthcheck, init_db
from .pipeline.manager import manager
from .providers.registry import capability_summary

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
)
log = logging.getLogger("leadforge")

STATIC_DIR = Path(__file__).parent / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Fail closed: never come up in a configuration that would expose the lead
    # database to anyone who finds the URL.
    problem = settings.startup_error()
    if problem:
        log.error("%s", problem)
        raise RuntimeError(problem)

    await init_db()
    orphans = await manager.recover_orphans()
    if orphans:
        log.warning("marked %s interrupted job(s) as failed", orphans)
    await get_client().start()
    caps = capability_summary()
    log.info("discovery: %s | email finders: %s | verifiers: %s",
             ", ".join(caps["discovery"]), ", ".join(caps["email_finders"]),
             ", ".join(caps["email_verifiers"]))
    for note in caps["notes"]:
        log.info("note: %s", note)
    log.info("database: %s", "postgres" if settings.is_postgres else "sqlite")
    log.info("authentication: %s",
             "enabled" if settings.require_auth else "disabled (localhost only)")
    log.info("LeadForge ready at http://%s:%s", settings.host, settings.port)
    try:
        yield
    finally:
        await manager.shutdown()
        await shutdown_client()


app = FastAPI(
    title="LeadForge",
    description=(
        "B2B lead discovery and enrichment. A lead is QUALIFIED only when it has "
        "both a live website and a real, discovered business email. Emails are "
        "never pattern-generated."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Added last so it runs first: nothing below it sees an unauthenticated request.
app.add_middleware(BasicAuthMiddleware)

app.include_router(jobs.router)
app.include_router(leads.router)
app.include_router(exports.router)


@app.get("/api/health")
async def health() -> JSONResponse:
    """Unauthenticated liveness probe for the hosting platform.

    Deliberately minimal: it must reveal nothing about the deployment's
    configuration or data, because it is the one endpoint reachable without
    credentials. Provider/capability detail lives on the authenticated
    /api/meta instead.
    """
    db_ok = await healthcheck()
    return JSONResponse(
        {"ok": db_ok, "database": "ok" if db_ok else "error"},
        status_code=200 if db_ok else 503,
    )


@app.get("/api/diagnostics")
async def diagnostics() -> JSONResponse:
    """Authenticated: crawler stats, running jobs and provider capabilities."""
    db_ok = await healthcheck()
    return JSONResponse({
        "ok": db_ok,
        "database": {"ok": db_ok,
                     "backend": "postgres" if settings.is_postgres else "sqlite"},
        "crawler": get_client().stats,
        "running_jobs": manager.running_ids,
        "auth": "enabled" if settings.require_auth else "disabled",
        "capabilities": capability_summary(),
    })


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(str(STATIC_DIR / "index.html"))


def run() -> None:  # pragma: no cover
    import uvicorn
    uvicorn.run("app.main:app", host=settings.host, port=settings.port,
                reload=False, proxy_headers=True, forwarded_allow_ips="*")


if __name__ == "__main__":  # pragma: no cover
    run()

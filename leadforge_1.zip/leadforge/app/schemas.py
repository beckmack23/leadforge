"""Pydantic request/response models."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .core.taxonomy import normalize_country, normalize_state


# --------------------------------------------------------------------------
# Search
# --------------------------------------------------------------------------

class SearchCriteria(BaseModel):
    """Everything the user can search on."""
    model_config = ConfigDict(extra="ignore")

    # what
    industry: Optional[str] = None
    sub_industry: Optional[str] = None
    keywords: list[str] = Field(default_factory=list)
    naics: Optional[str] = None
    sic: Optional[str] = None

    # where
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: str = "US"
    radius_miles: Optional[float] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    # firmographic filters
    employee_min: Optional[int] = None
    employee_max: Optional[int] = None
    revenue_min: Optional[float] = None
    revenue_max: Optional[float] = None
    founded_year_min: Optional[int] = None
    founded_year_max: Optional[int] = None
    locations_min: Optional[int] = None
    locations_max: Optional[int] = None
    franchise_status: Optional[Literal["franchise", "independent", "any"]] = "any"

    # behaviour
    require_website: bool = True
    require_email: bool = True

    @field_validator("state")
    @classmethod
    def _state(cls, v):
        return normalize_state(v) if v else None

    @field_validator("country")
    @classmethod
    def _country(cls, v):
        return normalize_country(v)

    @field_validator("keywords", mode="before")
    @classmethod
    def _kw(cls, v):
        if v is None:
            return []
        if isinstance(v, str):
            return [k.strip() for k in v.split(",") if k.strip()]
        return v

    def location_label(self) -> str:
        bits = [b for b in (self.city, self.state, self.postal_code) if b]
        return ", ".join(bits) or self.country

    def describe(self) -> str:
        what = self.industry or (", ".join(self.keywords) if self.keywords else "businesses")
        return f"{what} in {self.location_label()}"


class NLQueryRequest(BaseModel):
    text: str
    target_count: int = 500


class NLQueryResponse(BaseModel):
    criteria: SearchCriteria
    interpretation: str
    unparsed_terms: list[str] = Field(default_factory=list)


class JobCreateRequest(BaseModel):
    name: Optional[str] = None
    criteria: Optional[SearchCriteria] = None
    query_text: Optional[str] = None
    target_count: int = Field(default=500, ge=1, le=200_000)


class JobStats(BaseModel):
    businesses_found: int = 0
    websites_found: int = 0
    websites_validated: int = 0
    duplicates_merged: int = 0
    sites_scraped: int = 0
    emails_found: int = 0
    emails_verified_or_valid: int = 0
    qualified_leads: int = 0
    decision_makers_found: int = 0
    contacts_found: int = 0
    signals_found: int = 0
    companies_processed: int = 0
    errors: int = 0
    paid_credits_spent: float = 0.0
    cache_hits: int = 0


class JobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    status: str
    stage: Optional[str] = None
    target_count: int
    query: dict[str, Any] = Field(default_factory=dict)
    raw_query_text: Optional[str] = None
    stats: dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    created_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None


# --------------------------------------------------------------------------
# Leads
# --------------------------------------------------------------------------

class EmailOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    address: str
    email_type: str
    status: str
    verification_provider: Optional[str] = None
    verified_at: Optional[datetime] = None
    discovery_method: str
    source_type: str
    source_url: Optional[str] = None
    confidence: float
    is_role_account: bool = False
    is_disposable: bool = False
    is_free_provider: bool = False
    is_catch_all: Optional[bool] = None
    mx_found: Optional[bool] = None
    validation_detail: dict[str, Any] = Field(default_factory=dict)


class ContactOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    full_name: str
    job_title: Optional[str] = None
    seniority: Optional[str] = None
    is_decision_maker: bool
    linkedin_url: Optional[str] = None
    source_type: str
    source_url: Optional[str] = None
    confidence: float


class SignalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    signal_type: str
    title: str
    snippet: Optional[str] = None
    source_url: str
    source_type: str
    confidence: float
    observed_at: Optional[datetime] = None


class FieldSourceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    field: str
    value: Optional[str] = None
    source_type: str
    source_url: Optional[str] = None
    provider: Optional[str] = None
    confidence: float
    is_estimate: bool


class LeadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    domain: Optional[str] = None
    website: Optional[str] = None
    website_status: str
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    industry: Optional[str] = None
    sub_industry: Optional[str] = None
    naics: Optional[str] = None
    sic: Optional[str] = None
    employee_count: Optional[int] = None
    employee_range: Optional[str] = None
    estimated_revenue: Optional[float] = None
    revenue_range: Optional[str] = None
    founded_year: Optional[int] = None
    num_locations: Optional[int] = None
    franchise_status: Optional[str] = None
    business_description: Optional[str] = None
    linkedin_url: Optional[str] = None
    facebook_url: Optional[str] = None
    instagram_url: Optional[str] = None
    twitter_url: Optional[str] = None
    lead_score: int
    enrichment_pct: float
    is_qualified: bool
    pipeline_stage: str
    discovery_provider: Optional[str] = None
    first_seen_at: Optional[datetime] = None
    last_enriched_at: Optional[datetime] = None

    # flattened "best" values for the table view
    primary_email: Optional[str] = None
    primary_email_type: Optional[str] = None
    primary_email_status: Optional[str] = None
    contact_name: Optional[str] = None
    contact_title: Optional[str] = None
    contact_linkedin: Optional[str] = None


class LeadDetail(LeadOut):
    emails: list[EmailOut] = Field(default_factory=list)
    contacts: list[ContactOut] = Field(default_factory=list)
    signals: list[SignalOut] = Field(default_factory=list)
    sources: list[FieldSourceOut] = Field(default_factory=list)


class LeadFilters(BaseModel):
    model_config = ConfigDict(extra="ignore")
    job_id: Optional[int] = None
    q: Optional[str] = None
    industry: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    employee_min: Optional[int] = None
    employee_max: Optional[int] = None
    revenue_min: Optional[float] = None
    revenue_max: Optional[float] = None
    email_status: list[str] = Field(default_factory=list)
    email_type: list[str] = Field(default_factory=list)
    has_contact: Optional[bool] = None
    has_decision_maker: Optional[bool] = None
    qualified_only: bool = True
    score_min: Optional[int] = None
    score_max: Optional[int] = None
    enrichment_min: Optional[float] = None
    sort: str = "lead_score"
    direction: Literal["asc", "desc"] = "desc"
    limit: int = Field(default=50, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)


class LeadPage(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[LeadOut]


class ExportRequest(BaseModel):
    format: Literal["csv", "xlsx", "json"] = "csv"
    preset: Literal["outbound_leads", "full", "custom"] = "outbound_leads"
    columns: Optional[list[str]] = None
    filters: LeadFilters = Field(default_factory=LeadFilters)

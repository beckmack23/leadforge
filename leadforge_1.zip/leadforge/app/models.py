"""SQLAlchemy ORM models.

Design notes
------------
* ``Company`` holds firmographics. Only ``website`` + at least one usable
  ``EmailRecord`` make it a QUALIFIED lead; everything else is enrichment.
* ``FieldSource`` is the provenance ledger. Every non-obvious field value
  written by the pipeline gets a row here so the UI can answer
  "where did this come from?" for any cell.
* ``EmailRecord`` never stores a pattern-generated address. The
  ``discovery_method`` column records exactly how it was obtained.
"""
from __future__ import annotations

import enum
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def ensure_utc(value: datetime | None) -> datetime | None:
    """Attach UTC to a datetime read back from the database.

    SQLite has no timezone type: SQLAlchemy writes an aware UTC value as a naive
    UTC string and returns it naive. Comparing that against an aware ``utcnow()``
    raises TypeError, so every read-side comparison must go through here.
    """
    if value is None or value.tzinfo is not None:
        return value
    return value.replace(tzinfo=timezone.utc)


class Base(DeclarativeBase):
    pass


# --------------------------------------------------------------------------
# Enumerations (stored as plain strings for easy SQL filtering / export)
# --------------------------------------------------------------------------

class EmailType(str, enum.Enum):
    DECISION_MAKER = "decision_maker"      # Tier 1: owner/founder/CEO/president/...
    EMPLOYEE = "employee"                  # Tier 2: a named employee
    GENERAL_BUSINESS = "general_business"   # Tier 3: info@, contact@, sales@ ...


class EmailStatus(str, enum.Enum):
    VERIFIED = "verified"     # provider (or SMTP probe) confirmed the mailbox
    VALID = "valid"           # syntax + MX good, mailbox not individually proven
    RISKY = "risky"           # role/disposable/low-reputation/greylisted
    CATCH_ALL = "catch_all"   # domain accepts everything; mailbox unprovable
    INVALID = "invalid"       # syntax bad, no MX, or mailbox rejected
    UNKNOWN = "unknown"       # could not be determined


class WebsiteStatus(str, enum.Enum):
    LIVE = "live"
    REDIRECTED = "redirected"
    PARKED = "parked"
    UNREACHABLE = "unreachable"
    NOT_FOUND = "not_found"
    UNCHECKED = "unchecked"


class JobStatus(str, enum.Enum):
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SourceType(str, enum.Enum):
    WEBSITE_HOMEPAGE = "website_homepage"
    WEBSITE_CONTACT_PAGE = "website_contact_page"
    WEBSITE_ABOUT_PAGE = "website_about_page"
    WEBSITE_TEAM_PAGE = "website_team_page"
    WEBSITE_LEADERSHIP_PAGE = "website_leadership_page"
    WEBSITE_CAREERS_PAGE = "website_careers_page"
    WEBSITE_NEWS_PAGE = "website_news_page"
    WEBSITE_LOCATIONS_PAGE = "website_locations_page"
    WEBSITE_STRUCTURED_DATA = "website_structured_data"
    DIRECTORY = "directory"
    ENRICHMENT_PROVIDER = "enrichment_provider"
    EMAIL_PROVIDER = "email_provider"
    VERIFICATION_PROVIDER = "verification_provider"
    USER_IMPORT = "user_import"
    DERIVED = "derived"          # computed from other stored fields (e.g. ranges)


# --------------------------------------------------------------------------
# Core tables
# --------------------------------------------------------------------------

class Company(Base):
    __tablename__ = "companies"

    id: Mapped[int] = mapped_column(primary_key=True)

    # --- identity / dedupe keys ---
    name: Mapped[str] = mapped_column(String(512), index=True)
    name_normalized: Mapped[str] = mapped_column(String(512), index=True, default="")
    domain: Mapped[str | None] = mapped_column(String(255), index=True)
    website: Mapped[str | None] = mapped_column(String(1024))
    phone: Mapped[str | None] = mapped_column(String(64))
    phone_normalized: Mapped[str | None] = mapped_column(String(32), index=True)
    address_hash: Mapped[str | None] = mapped_column(String(64), index=True)

    # --- website validation ---
    website_status: Mapped[str] = mapped_column(String(32), default=WebsiteStatus.UNCHECKED.value)
    website_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    website_final_url: Mapped[str | None] = mapped_column(String(1024))

    # --- location ---
    address: Mapped[str | None] = mapped_column(String(512))
    city: Mapped[str | None] = mapped_column(String(128), index=True)
    state: Mapped[str | None] = mapped_column(String(64), index=True)
    postal_code: Mapped[str | None] = mapped_column(String(32), index=True)
    country: Mapped[str | None] = mapped_column(String(64), default="US")
    latitude: Mapped[float | None] = mapped_column(Float)
    longitude: Mapped[float | None] = mapped_column(Float)

    # --- firmographics ---
    industry: Mapped[str | None] = mapped_column(String(128), index=True)
    sub_industry: Mapped[str | None] = mapped_column(String(128))
    naics: Mapped[str | None] = mapped_column(String(16), index=True)
    sic: Mapped[str | None] = mapped_column(String(16), index=True)
    employee_count: Mapped[int | None] = mapped_column(Integer, index=True)
    employee_range: Mapped[str | None] = mapped_column(String(32))
    estimated_revenue: Mapped[float | None] = mapped_column(Float, index=True)
    revenue_range: Mapped[str | None] = mapped_column(String(32))
    founded_year: Mapped[int | None] = mapped_column(Integer)
    num_locations: Mapped[int | None] = mapped_column(Integer)
    franchise_status: Mapped[str | None] = mapped_column(String(32))  # franchise|independent|unknown
    business_description: Mapped[str | None] = mapped_column(Text)

    # --- social ---
    linkedin_url: Mapped[str | None] = mapped_column(String(512))
    facebook_url: Mapped[str | None] = mapped_column(String(512))
    instagram_url: Mapped[str | None] = mapped_column(String(512))
    twitter_url: Mapped[str | None] = mapped_column(String(512))
    youtube_url: Mapped[str | None] = mapped_column(String(512))

    # --- scoring / status ---
    lead_score: Mapped[int] = mapped_column(Integer, default=0, index=True)
    enrichment_pct: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    is_qualified: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    pipeline_stage: Mapped[str] = mapped_column(String(32), default="discovered", index=True)

    # --- bookkeeping ---
    discovery_provider: Mapped[str | None] = mapped_column(String(64))
    discovery_query: Mapped[str | None] = mapped_column(String(512))
    external_ids: Mapped[dict] = mapped_column(JSON, default=dict)
    scrape_notes: Mapped[dict] = mapped_column(JSON, default=dict)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_enriched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    emails: Mapped[list["EmailRecord"]] = relationship(
        back_populates="company", cascade="all, delete-orphan", lazy="selectin"
    )
    contacts: Mapped[list["Contact"]] = relationship(
        back_populates="company", cascade="all, delete-orphan", lazy="selectin"
    )
    signals: Mapped[list["Signal"]] = relationship(
        back_populates="company", cascade="all, delete-orphan", lazy="selectin"
    )
    sources: Mapped[list["FieldSource"]] = relationship(
        back_populates="company", cascade="all, delete-orphan", lazy="selectin"
    )

    __table_args__ = (
        Index("ix_company_dedupe_domain", "domain"),
        Index("ix_company_state_industry", "state", "industry"),
    )

    # -- convenience --------------------------------------------------
    @property
    def best_email(self) -> "EmailRecord | None":
        """Highest-priority email: decision-maker > employee > general, then status."""
        if not self.emails:
            return None
        return sorted(self.emails, key=lambda e: e.priority_key)[0]

    @property
    def primary_contact(self) -> "Contact | None":
        if not self.contacts:
            return None
        return sorted(self.contacts, key=lambda c: (0 if c.is_decision_maker else 1,
                                                    c.seniority_rank))[0]


class Contact(Base):
    __tablename__ = "contacts"

    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)

    first_name: Mapped[str | None] = mapped_column(String(128))
    last_name: Mapped[str | None] = mapped_column(String(128))
    full_name: Mapped[str] = mapped_column(String(256))
    job_title: Mapped[str | None] = mapped_column(String(256))
    seniority: Mapped[str | None] = mapped_column(String(32))  # owner|c_level|vp|director|manager|staff
    is_decision_maker: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    linkedin_url: Mapped[str | None] = mapped_column(String(512))
    phone: Mapped[str | None] = mapped_column(String(64))

    source_type: Mapped[str] = mapped_column(String(48))
    source_url: Mapped[str | None] = mapped_column(String(1024))
    provider: Mapped[str | None] = mapped_column(String(64))
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    company: Mapped[Company] = relationship(back_populates="contacts")
    emails: Mapped[list["EmailRecord"]] = relationship(back_populates="contact", lazy="selectin")

    __table_args__ = (UniqueConstraint("company_id", "full_name", name="uq_contact_company_name"),)

    _SENIORITY_ORDER = {"owner": 0, "c_level": 1, "vp": 2, "director": 3, "manager": 4, "staff": 5}

    @property
    def seniority_rank(self) -> int:
        return self._SENIORITY_ORDER.get(self.seniority or "staff", 9)


class EmailRecord(Base):
    """A discovered email address. NEVER pattern-generated.

    ``discovery_method`` is the audit trail:
      - ``mailto_link``      -> href="mailto:..." on a public page
      - ``page_text``        -> plain text on a public page
      - ``deobfuscated_text``-> "name (at) domain (dot) com" written for humans
      - ``structured_data``  -> JSON-LD / microdata ``email`` property
      - ``provider:<name>``  -> returned by a commercial email-finding provider
      - ``user_import``      -> supplied by the operator in a CSV import
    """
    __tablename__ = "emails"

    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    contact_id: Mapped[int | None] = mapped_column(ForeignKey("contacts.id", ondelete="SET NULL"))

    address: Mapped[str] = mapped_column(String(320), index=True)
    local_part: Mapped[str] = mapped_column(String(128))
    email_domain: Mapped[str] = mapped_column(String(255), index=True)

    email_type: Mapped[str] = mapped_column(String(32), index=True)
    status: Mapped[str] = mapped_column(String(32), default=EmailStatus.UNKNOWN.value, index=True)

    # validation detail
    verification_provider: Mapped[str | None] = mapped_column(String(64))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    syntax_ok: Mapped[bool | None] = mapped_column(Boolean)
    mx_found: Mapped[bool | None] = mapped_column(Boolean)
    mx_host: Mapped[str | None] = mapped_column(String(255))
    smtp_accepted: Mapped[bool | None] = mapped_column(Boolean)
    is_catch_all: Mapped[bool | None] = mapped_column(Boolean)
    is_role_account: Mapped[bool] = mapped_column(Boolean, default=False)
    is_disposable: Mapped[bool] = mapped_column(Boolean, default=False)
    is_free_provider: Mapped[bool] = mapped_column(Boolean, default=False)
    validation_detail: Mapped[dict] = mapped_column(JSON, default=dict)

    # provenance
    discovery_method: Mapped[str] = mapped_column(String(48))
    source_type: Mapped[str] = mapped_column(String(48))
    source_url: Mapped[str | None] = mapped_column(String(1024))
    provider: Mapped[str | None] = mapped_column(String(64))
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    company: Mapped[Company] = relationship(back_populates="emails")
    contact: Mapped[Contact | None] = relationship(back_populates="emails")

    __table_args__ = (UniqueConstraint("company_id", "address", name="uq_email_company_address"),)

    _TYPE_ORDER = {"decision_maker": 0, "employee": 1, "general_business": 2}
    _STATUS_ORDER = {"verified": 0, "valid": 1, "catch_all": 2, "risky": 3, "unknown": 4, "invalid": 5}

    @property
    def priority_key(self) -> tuple:
        return (
            self._TYPE_ORDER.get(self.email_type, 9),
            self._STATUS_ORDER.get(self.status, 9),
            -self.confidence,
        )

    @property
    def is_usable(self) -> bool:
        """Counts toward qualification. Invalid addresses do not."""
        return self.status != EmailStatus.INVALID.value


class Signal(Base):
    """A publicly observable business signal, always with a source URL."""
    __tablename__ = "signals"

    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)

    signal_type: Mapped[str] = mapped_column(String(48), index=True)
    title: Mapped[str] = mapped_column(String(512))
    snippet: Mapped[str | None] = mapped_column(Text)
    source_url: Mapped[str] = mapped_column(String(1024))
    source_type: Mapped[str] = mapped_column(String(48))
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    company: Mapped[Company] = relationship(back_populates="signals")

    __table_args__ = (
        UniqueConstraint("company_id", "signal_type", "source_url", name="uq_signal"),
    )


class FieldSource(Base):
    """Provenance for one field value on one company. 'Where did this come from?'"""
    __tablename__ = "field_sources"

    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)

    field: Mapped[str] = mapped_column(String(64), index=True)
    value: Mapped[str | None] = mapped_column(Text)
    source_type: Mapped[str] = mapped_column(String(48))
    source_url: Mapped[str | None] = mapped_column(String(1024))
    provider: Mapped[str | None] = mapped_column(String(64))
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=False)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    company: Mapped[Company] = relationship(back_populates="sources")

    __table_args__ = (UniqueConstraint("company_id", "field", name="uq_field_source"),)


# --------------------------------------------------------------------------
# Jobs & operational tables
# --------------------------------------------------------------------------

class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(256))
    query: Mapped[dict] = mapped_column(JSON, default=dict)
    raw_query_text: Mapped[str | None] = mapped_column(String(1024))
    target_count: Mapped[int] = mapped_column(Integer, default=1000)

    status: Mapped[str] = mapped_column(String(32), default=JobStatus.QUEUED.value, index=True)
    stage: Mapped[str | None] = mapped_column(String(64))
    stats: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)


class JobCompany(Base):
    """Join table so a company can belong to many jobs without duplication."""
    __tablename__ = "job_companies"

    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    stage: Mapped[str] = mapped_column(String(32), default="discovered")
    error: Mapped[str | None] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (UniqueConstraint("job_id", "company_id", name="uq_job_company"),)


class ProviderCache(Base):
    """Response cache so the same company is never enriched twice."""
    __tablename__ = "provider_cache"

    id: Mapped[int] = mapped_column(primary_key=True)
    provider: Mapped[str] = mapped_column(String(64), index=True)
    operation: Mapped[str] = mapped_column(String(64), index=True)
    key_hash: Mapped[str] = mapped_column(String(64), index=True)
    payload: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)

    __table_args__ = (
        UniqueConstraint("provider", "operation", "key_hash", name="uq_provider_cache"),
    )


class ProviderCall(Base):
    """Ledger of every provider call, for cost accounting."""
    __tablename__ = "provider_calls"

    id: Mapped[int] = mapped_column(primary_key=True)
    provider: Mapped[str] = mapped_column(String(64), index=True)
    operation: Mapped[str] = mapped_column(String(64))
    job_id: Mapped[int | None] = mapped_column(Integer, index=True)
    company_id: Mapped[int | None] = mapped_column(Integer)
    cache_hit: Mapped[bool] = mapped_column(Boolean, default=False)
    cost_units: Mapped[float] = mapped_column(Float, default=0.0)
    success: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

"""Search/job endpoints: create, monitor, cancel, import."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.nlq import parse_query
from ..core.taxonomy import industry_choices
from ..db import get_session, session_scope
from ..models import Company, Contact, EmailRecord, EmailStatus, Job, JobCompany, JobStatus
from ..pipeline.manager import manager
from ..providers.discovery.csv_import import CsvImportDiscovery
from ..providers.registry import capability_summary, registry_report
from ..schemas import (
    JobCreateRequest,
    JobOut,
    NLQueryRequest,
    NLQueryResponse,
    SearchCriteria,
)

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["search"])


@router.get("/meta")
async def meta() -> dict:
    return {
        "industries": industry_choices(),
        "providers": registry_report(),
        "capabilities": capability_summary(),
        "email_statuses": [s.value for s in EmailStatus],
        "email_types": ["decision_maker", "employee", "general_business"],
        "qualification_rule": "QUALIFIED LEAD = valid website + business email",
    }


@router.post("/parse", response_model=NLQueryResponse)
async def parse(req: NLQueryRequest) -> NLQueryResponse:
    criteria, interpretation, unparsed, _target = parse_query(req.text, req.target_count)
    return NLQueryResponse(criteria=criteria, interpretation=interpretation,
                           unparsed_terms=unparsed)


@router.post("/jobs", response_model=JobOut, status_code=201)
async def create_job(req: JobCreateRequest,
                     session: AsyncSession = Depends(get_session)) -> JobOut:
    criteria = req.criteria
    target = req.target_count
    raw_text = req.query_text

    if criteria is None:
        if not raw_text:
            raise HTTPException(400, "provide either `criteria` or `query_text`")
        criteria, _interpretation, _unparsed, parsed_target = parse_query(raw_text, target)
        target = parsed_target if req.target_count == 500 else target

    if not any([criteria.industry, criteria.keywords, criteria.naics, criteria.sic]):
        raise HTTPException(400, "specify an industry, keywords, NAICS or SIC code")
    if not any([criteria.city, criteria.state, criteria.postal_code,
                criteria.latitude is not None]):
        raise HTTPException(400, "specify a location (city, state, ZIP or coordinates)")

    job = Job(
        name=req.name or criteria.describe()[:200],
        query=criteria.model_dump(mode="json"),
        raw_query_text=raw_text,
        target_count=target,
        status=JobStatus.QUEUED.value,
        stats={},
    )
    session.add(job)
    await session.commit()
    await session.refresh(job)
    await manager.start(job.id)
    return JobOut.model_validate(job)


@router.get("/jobs", response_model=list[JobOut])
async def list_jobs(limit: int = 25,
                    session: AsyncSession = Depends(get_session)) -> list[JobOut]:
    rows = (await session.execute(
        select(Job).order_by(desc(Job.created_at)).limit(min(limit, 200))
    )).scalars().all()
    return [JobOut.model_validate(j) for j in rows]


@router.get("/jobs/{job_id}", response_model=JobOut)
async def get_job(job_id: int, session: AsyncSession = Depends(get_session)) -> JobOut:
    job = await session.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "job not found")
    return JobOut.model_validate(job)


@router.get("/jobs/{job_id}/progress")
async def job_progress(job_id: int, session: AsyncSession = Depends(get_session)) -> dict:
    """Live counters, computed from the data rather than from a running tally."""
    job = await session.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "job not found")

    ids_stmt = select(JobCompany.company_id).where(JobCompany.job_id == job_id)
    total = (await session.execute(
        select(func.count()).select_from(ids_stmt.subquery())
    )).scalar_one()

    def scoped(stmt):
        return stmt.where(Company.id.in_(ids_stmt))

    websites = (await session.execute(scoped(
        select(func.count()).select_from(Company).where(
            Company.website.is_not(None),
            Company.website_status.in_(["live", "redirected"]))
    ))).scalar_one()

    emails = (await session.execute(
        select(func.count(func.distinct(EmailRecord.company_id))).where(
            EmailRecord.company_id.in_(ids_stmt))
    )).scalar_one()

    good = (await session.execute(
        select(func.count(func.distinct(EmailRecord.company_id))).where(
            EmailRecord.company_id.in_(ids_stmt),
            EmailRecord.status.in_([EmailStatus.VERIFIED.value, EmailStatus.VALID.value]))
    )).scalar_one()

    qualified = (await session.execute(scoped(
        select(func.count()).select_from(Company).where(Company.is_qualified.is_(True))
    ))).scalar_one()

    dms = (await session.execute(
        select(func.count(func.distinct(Contact.company_id))).where(
            Contact.company_id.in_(ids_stmt), Contact.is_decision_maker.is_(True))
    )).scalar_one()

    processed = (await session.execute(
        select(func.count()).select_from(JobCompany).where(
            JobCompany.job_id == job_id,
            JobCompany.stage.in_(["enriched", "no_website", "error",
                                  "website_unreachable", "website_parked",
                                  "website_not_found"]))
    )).scalar_one()

    stats = dict(job.stats or {})
    return {
        "job_id": job_id,
        "status": job.status,
        "stage": job.stage,
        "target": job.target_count,
        "error": job.error,
        "metrics": {
            "businesses_found": int(total),
            "websites_found": int(websites),
            "emails_found": int(emails),
            "verified_or_valid_emails": int(good),
            "qualified_leads": int(qualified),
            "decision_makers_found": int(dms),
        },
        "progress": {
            "processed": int(processed),
            "total": int(total),
            "pct": round(100.0 * processed / total, 1) if total else 0.0,
        },
        "internal": {
            "duplicates_merged": stats.get("duplicates_merged", 0),
            "sites_scraped": stats.get("sites_scraped", 0),
            "signals_found": stats.get("signals_found", 0),
            "contacts_found": stats.get("contacts_found", 0),
            "cache_hits": stats.get("cache_hits", 0),
            "errors": stats.get("errors", 0),
        },
    }


@router.post("/jobs/{job_id}/cancel", response_model=JobOut)
async def cancel_job(job_id: int, session: AsyncSession = Depends(get_session)) -> JobOut:
    job = await session.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "job not found")
    await manager.cancel(job_id)
    await session.refresh(job)
    return JobOut.model_validate(job)


@router.post("/jobs/{job_id}/rerun", response_model=JobOut)
async def rerun_job(job_id: int, session: AsyncSession = Depends(get_session)) -> JobOut:
    job = await session.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "job not found")
    if manager.is_running(job_id):
        raise HTTPException(409, "job is already running")
    job.status = JobStatus.QUEUED.value
    job.error = None
    job.cancel_requested = False
    job.finished_at = None
    await session.commit()
    await manager.start(job_id)
    await session.refresh(job)
    return JobOut.model_validate(job)


@router.post("/import", response_model=JobOut, status_code=201)
async def import_companies(file: UploadFile = File(...),
                           session: AsyncSession = Depends(get_session)) -> JobOut:
    """Bring your own company list (CSV/JSON) and run it through enrichment."""
    raw = (await file.read()).decode("utf-8", errors="replace")
    parser = CsvImportDiscovery()
    businesses = parser.parse(raw, file.filename or "")
    if not businesses:
        raise HTTPException(400, "no usable rows found; expected a 'company' column "
                                 "and ideally a 'website' column")

    criteria = SearchCriteria(keywords=["imported"], country="US")
    job = Job(name=f"Import: {file.filename or 'upload'} ({len(businesses)} rows)",
              query=criteria.model_dump(mode="json"),
              raw_query_text=f"import:{file.filename}",
              target_count=len(businesses), status=JobStatus.QUEUED.value, stats={})
    session.add(job)
    await session.commit()
    await session.refresh(job)

    from ..pipeline.orchestrator import JobRunner
    runner = JobRunner(job.id)
    company_ids = await runner._persist_discovered(businesses, criteria)

    async def run_import() -> None:
        await runner._set_status(JobStatus.RUNNING, stage="enrichment")
        await runner._bump(businesses_found=len(company_ids))
        try:
            await runner._enrich_all(company_ids)
            await runner._finish(JobStatus.COMPLETED)
        except Exception as exc:  # noqa: BLE001
            await runner._finish(JobStatus.FAILED, error=str(exc)[:2000])

    import asyncio
    asyncio.create_task(run_import())
    await session.refresh(job)
    return JobOut.model_validate(job)


@router.get("/stats")
async def global_stats(session: AsyncSession = Depends(get_session)) -> dict:
    total = (await session.execute(select(func.count()).select_from(Company))).scalar_one()
    qualified = (await session.execute(
        select(func.count()).select_from(Company).where(Company.is_qualified.is_(True))
    )).scalar_one()
    with_site = (await session.execute(
        select(func.count()).select_from(Company).where(
            Company.website_status.in_(["live", "redirected"]))
    )).scalar_one()
    with_email = (await session.execute(
        select(func.count(func.distinct(EmailRecord.company_id)))
    )).scalar_one()
    dms = (await session.execute(
        select(func.count(func.distinct(Contact.company_id))).where(
            Contact.is_decision_maker.is_(True))
    )).scalar_one()
    by_status = dict((await session.execute(
        select(EmailRecord.status, func.count()).group_by(EmailRecord.status)
    )).all())
    by_type = dict((await session.execute(
        select(EmailRecord.email_type, func.count()).group_by(EmailRecord.email_type)
    )).all())
    return {
        "companies": int(total), "qualified_leads": int(qualified),
        "with_website": int(with_site), "with_email": int(with_email),
        "with_decision_maker": int(dms),
        "emails_by_status": by_status, "emails_by_type": by_type,
        "running_jobs": manager.running_ids,
    }

"""Lead query, filtering and detail endpoints."""
from __future__ import annotations

from typing import Sequence

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import Select, and_, exists, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_session
from ..models import Company, Contact, EmailRecord, JobCompany
from ..schemas import LeadDetail, LeadFilters, LeadOut, LeadPage

router = APIRouter(prefix="/api/leads", tags=["leads"])

SORTABLE = {
    "lead_score": Company.lead_score,
    "enrichment_pct": Company.enrichment_pct,
    "name": Company.name,
    "employee_count": Company.employee_count,
    "estimated_revenue": Company.estimated_revenue,
    "founded_year": Company.founded_year,
    "city": Company.city,
    "state": Company.state,
    "industry": Company.industry,
    "last_enriched_at": Company.last_enriched_at,
    "first_seen_at": Company.first_seen_at,
}


def build_query(f: LeadFilters) -> Select:
    stmt = select(Company)
    conds = []

    if f.job_id is not None:
        stmt = stmt.join(JobCompany, JobCompany.company_id == Company.id)
        conds.append(JobCompany.job_id == f.job_id)

    if f.qualified_only:
        conds.append(Company.is_qualified.is_(True))
    if f.q:
        like = f"%{f.q.strip()}%"
        conds.append(or_(Company.name.ilike(like), Company.domain.ilike(like),
                         Company.website.ilike(like),
                         Company.business_description.ilike(like)))
    if f.industry:
        conds.append(Company.industry == f.industry)
    if f.state:
        conds.append(Company.state == f.state.upper())
    if f.city:
        conds.append(Company.city.ilike(f"%{f.city}%"))
    if f.employee_min is not None:
        conds.append(and_(Company.employee_count.is_not(None),
                          Company.employee_count >= f.employee_min))
    if f.employee_max is not None:
        conds.append(and_(Company.employee_count.is_not(None),
                          Company.employee_count <= f.employee_max))
    if f.revenue_min is not None:
        conds.append(and_(Company.estimated_revenue.is_not(None),
                          Company.estimated_revenue >= f.revenue_min))
    if f.revenue_max is not None:
        conds.append(and_(Company.estimated_revenue.is_not(None),
                          Company.estimated_revenue <= f.revenue_max))
    if f.score_min is not None:
        conds.append(Company.lead_score >= f.score_min)
    if f.score_max is not None:
        conds.append(Company.lead_score <= f.score_max)
    if f.enrichment_min is not None:
        conds.append(Company.enrichment_pct >= f.enrichment_min)

    if f.email_status:
        conds.append(exists().where(and_(EmailRecord.company_id == Company.id,
                                         EmailRecord.status.in_(f.email_status))))
    if f.email_type:
        conds.append(exists().where(and_(EmailRecord.company_id == Company.id,
                                         EmailRecord.email_type.in_(f.email_type))))
    if f.has_contact is True:
        conds.append(exists().where(Contact.company_id == Company.id))
    elif f.has_contact is False:
        conds.append(~exists().where(Contact.company_id == Company.id))
    if f.has_decision_maker is True:
        conds.append(exists().where(and_(Contact.company_id == Company.id,
                                         Contact.is_decision_maker.is_(True))))
    elif f.has_decision_maker is False:
        conds.append(~exists().where(and_(Contact.company_id == Company.id,
                                          Contact.is_decision_maker.is_(True))))

    if conds:
        stmt = stmt.where(*conds)
    return stmt


def apply_sort(stmt: Select, f: LeadFilters) -> Select:
    col = SORTABLE.get(f.sort, Company.lead_score)
    order = col.desc() if f.direction == "desc" else col.asc()
    return stmt.order_by(order, Company.id.desc())


def flatten(company: Company) -> LeadOut:
    best = company.best_email
    contact = company.primary_contact
    dm = next((c for c in company.contacts if c.is_decision_maker), None)
    chosen = dm or contact
    data = LeadOut.model_validate(company)
    data.primary_email = best.address if best else None
    data.primary_email_type = best.email_type if best else None
    data.primary_email_status = best.status if best else None
    data.contact_name = chosen.full_name if chosen else None
    data.contact_title = chosen.job_title if chosen else None
    data.contact_linkedin = chosen.linkedin_url if chosen else None
    return data


async def fetch_companies(session: AsyncSession, f: LeadFilters) -> Sequence[Company]:
    stmt = apply_sort(build_query(f), f).limit(f.limit).offset(f.offset)
    return (await session.execute(stmt)).scalars().unique().all()


@router.get("", response_model=LeadPage)
async def list_leads(
    session: AsyncSession = Depends(get_session),
    job_id: int | None = None,
    q: str | None = None,
    industry: str | None = None,
    state: str | None = None,
    city: str | None = None,
    employee_min: int | None = None,
    employee_max: int | None = None,
    revenue_min: float | None = None,
    revenue_max: float | None = None,
    email_status: list[str] = Query(default=[]),
    email_type: list[str] = Query(default=[]),
    has_contact: bool | None = None,
    has_decision_maker: bool | None = None,
    qualified_only: bool = True,
    score_min: int | None = None,
    score_max: int | None = None,
    enrichment_min: float | None = None,
    sort: str = "lead_score",
    direction: str = "desc",
    limit: int = 50,
    offset: int = 0,
) -> LeadPage:
    f = LeadFilters(
        job_id=job_id, q=q, industry=industry, state=state, city=city,
        employee_min=employee_min, employee_max=employee_max,
        revenue_min=revenue_min, revenue_max=revenue_max,
        email_status=email_status, email_type=email_type,
        has_contact=has_contact, has_decision_maker=has_decision_maker,
        qualified_only=qualified_only, score_min=score_min, score_max=score_max,
        enrichment_min=enrichment_min, sort=sort,
        direction="desc" if direction not in ("asc", "desc") else direction,
        limit=limit, offset=offset,
    )
    count_stmt = select(func.count()).select_from(build_query(f).subquery())
    total = (await session.execute(count_stmt)).scalar_one()
    rows = await fetch_companies(session, f)
    return LeadPage(total=int(total), limit=f.limit, offset=f.offset,
                    items=[flatten(c) for c in rows])


@router.get("/{lead_id}", response_model=LeadDetail)
async def get_lead(lead_id: int, session: AsyncSession = Depends(get_session)) -> LeadDetail:
    company = await session.get(Company, lead_id)
    if company is None:
        raise HTTPException(404, "lead not found")
    from ..schemas import ContactOut, EmailOut, FieldSourceOut, SignalOut
    base = flatten(company)
    detail = LeadDetail(**base.model_dump())
    detail.emails = [EmailOut.model_validate(e) for e in
                     sorted(company.emails, key=lambda e: e.priority_key)]
    detail.contacts = [ContactOut.model_validate(c) for c in
                       sorted(company.contacts,
                              key=lambda c: (0 if c.is_decision_maker else 1, c.full_name))]
    detail.signals = [SignalOut.model_validate(s) for s in
                      sorted(company.signals, key=lambda s: -s.confidence)]
    detail.sources = [FieldSourceOut.model_validate(s) for s in
                      sorted(company.sources, key=lambda s: s.field)]
    return detail


@router.get("/{lead_id}/score", response_model=dict)
async def get_score_breakdown(lead_id: int,
                              session: AsyncSession = Depends(get_session)) -> dict:
    from ..pipeline.scoring import score_company
    company = await session.get(Company, lead_id)
    if company is None:
        raise HTTPException(404, "lead not found")
    b = score_company(company)
    return {
        "lead_id": lead_id, "total": b.total, "qualified": b.qualified,
        "enrichment_pct": b.enrichment_pct,
        "components": {
            "email": {"points": b.email, "max": 40},
            "contact": {"points": b.contact, "max": 20},
            "firmographic": {"points": b.firmographic, "max": 20},
            "reachability": {"points": b.reachability, "max": 10},
            "signals": {"points": b.signals, "max": 10},
        },
        "reasons": b.reasons,
        "rule": "QUALIFIED LEAD = valid website + business email",
    }

"""Export endpoints."""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_session
from ..export.exporters import ALL_COLUMNS, CONTENT_TYPES, EXPORTERS, PRESETS
from ..schemas import ExportRequest
from .leads import apply_sort, build_query

router = APIRouter(prefix="/api/export", tags=["export"])

MAX_EXPORT_ROWS = 100_000


@router.get("/columns")
async def columns() -> dict:
    return {
        "columns": [{"key": k, "label": label} for k, label in ALL_COLUMNS],
        "presets": {
            "outbound_leads": {
                "label": "Outbound Leads",
                "description": "Ready-to-send columns for a cold outreach sequence.",
                "columns": PRESETS["outbound_leads"],
            },
            "full": {
                "label": "Full record",
                "description": "Every field, plus a Sources sheet in XLSX exports.",
                "columns": PRESETS["full"],
            },
        },
        "formats": list(EXPORTERS.keys()),
    }


@router.post("")
async def export(req: ExportRequest,
                 session: AsyncSession = Depends(get_session)) -> Response:
    filters = req.filters.model_copy(update={"limit": MAX_EXPORT_ROWS, "offset": 0})
    stmt = apply_sort(build_query(filters), filters).limit(MAX_EXPORT_ROWS)
    companies = (await session.execute(stmt)).scalars().unique().all()

    exporter = EXPORTERS[req.format]
    payload = exporter(list(companies), req.preset, req.columns)

    stamp = datetime.utcnow().strftime("%Y%m%d-%H%M")
    name = f"leadforge-{req.preset}-{stamp}.{req.format}"
    return Response(
        content=payload,
        media_type=CONTENT_TYPES[req.format],
        headers={
            "Content-Disposition": f'attachment; filename="{name}"',
            "X-Row-Count": str(len(companies)),
        },
    )

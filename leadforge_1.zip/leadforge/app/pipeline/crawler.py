"""Website crawler: fetches a company's own public pages and extracts everything.

This is the workhorse of the free pipeline. It visits only pages the site
publishes and links to, obeys robots.txt, rate-limits per host, and stops at
any authentication wall or challenge page rather than trying to get around it.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from ..config import settings
from ..core.email_extract import (
    PAGE_PRIORITY,
    FoundEmail,
    PageExtract,
    classify_page,
    parse_page,
    should_skip_url,
)
from ..core.http import FetchResult, get_client
from ..core.normalize import extract_domain, normalize_url, registrable_domain
from ..core.people_extract import (
    FoundPerson,
    merge_people,
    people_from_dom,
    people_from_jsonld,
    people_from_text,
)

log = logging.getLogger(__name__)

SOURCE_TYPE_FOR_PAGE = {
    "home": "website_homepage",
    "contact": "website_contact_page",
    "about": "website_about_page",
    "team": "website_team_page",
    "leadership": "website_leadership_page",
    "locations": "website_locations_page",
    "careers": "website_careers_page",
    "news": "website_news_page",
    "services": "website_homepage",
    "other": "website_homepage",
}

PARKED_MARKERS = (
    "this domain is for sale", "buy this domain", "domain is parked",
    "parked free, courtesy of", "godaddy.com/domainsearch", "hugedomains",
    "sedoparking", "future home of something quite cool", "afternic",
    "the domain name you requested", "website coming soon", "under construction",
    "default web site page", "apache2 ubuntu default page", "index of /",
    "welcome to nginx", "iis windows server", "site not found",
)


@dataclass
class SiteProfile:
    """Everything learned from one company website."""
    base_url: str
    domain: str
    reachable: bool = False
    status: str = "unchecked"          # models.WebsiteStatus value
    final_url: str | None = None
    pages: list[PageExtract] = field(default_factory=list)
    emails: list[FoundEmail] = field(default_factory=list)
    people: list[FoundPerson] = field(default_factory=list)
    phones: list[str] = field(default_factory=list)
    social: dict[str, str] = field(default_factory=dict)
    description: str | None = None
    description_source: str | None = None
    jsonld_org: dict = field(default_factory=dict)
    addresses: list[dict] = field(default_factory=list)
    founded_year: int | None = None
    founded_source: str | None = None
    employee_hint: int | None = None
    employee_hint_source: str | None = None
    locations_hint: int | None = None
    locations_hint_source: str | None = None
    franchise_hint: str | None = None
    pages_by_kind: dict[str, str] = field(default_factory=dict)
    notes: dict = field(default_factory=dict)
    fetch_errors: list[str] = field(default_factory=list)


class SiteCrawler:
    def __init__(self, max_pages: int | None = None):
        self.max_pages = max_pages or settings.max_pages_per_site
        self.client = get_client()

    # ------------------------------------------------------------------
    async def validate(self, website: str) -> tuple[str, FetchResult | None]:
        """STEP 2 - is there an actual, live website here?

        Tries https then http, and the bare domain then www.
        """
        candidates = self._candidate_urls(website)
        last: FetchResult | None = None
        for url in candidates:
            # Probing several scheme/host variants, so don't retry each one and
            # cap the wait: a refused or hung connection here just means
            # "try the next variant".
            res = await self.client.fetch(url, max_bytes=400_000, max_retries=0,
                                          timeout=min(settings.http_timeout_seconds, 10.0))
            last = res
            if res.ok and res.text is not None:
                if self._is_parked(res.text):
                    return "parked", res
                final_domain = extract_domain(res.final_url)
                start_domain = extract_domain(url)
                if final_domain and start_domain and \
                        registrable_domain(final_domain) != registrable_domain(start_domain):
                    return "redirected", res
                return "live", res
            if res.reason in {"robots_disallowed", "access_denied", "challenge_page"}:
                # The site exists but tells us not to crawl. Respect it.
                return "live", res
        if last is not None and last.status and last.status in (404, 410):
            return "not_found", last
        return "unreachable", last

    def _candidate_urls(self, website: str) -> list[str]:
        normalized = normalize_url(website)
        if not normalized:
            return []
        p = urlparse(normalized)
        host = p.netloc
        path = p.path if p.path not in ("", "/") else "/"

        hostname = host.split(":")[0]
        # "www.192.168.0.1" is meaningless, and so is a www variant of localhost.
        is_ip_or_local = bool(re.fullmatch(r"[\d.]+|\[[0-9a-fA-F:]+\]", hostname)) \
            or hostname in ("localhost",)

        if is_ip_or_local:
            hosts = [host]
        else:
            bare = host[4:] if host.startswith("www.") else host
            www = host if host.startswith("www.") else "www." + host
            hosts = [host, bare, www]

        seen, out = set(), []
        for scheme in ("https", "http"):
            for h in hosts:
                u = f"{scheme}://{h}{path}"
                if u not in seen:
                    seen.add(u)
                    out.append(u)
        return out[:4]

    @staticmethod
    def _is_parked(html_text: str) -> bool:
        soup_text = re.sub(r"<[^>]+>", " ", html_text[:20000]).lower()
        if len(soup_text.strip()) < 120:
            return True
        return any(m in soup_text for m in PARKED_MARKERS)

    # ------------------------------------------------------------------
    async def crawl(self, website: str, *, first_page: FetchResult | None = None
                    ) -> SiteProfile:
        """STEP 4 - crawl the public pages of one site."""
        normalized = normalize_url(website) or website
        domain = extract_domain(normalized) or ""
        profile = SiteProfile(base_url=normalized, domain=domain)

        home = first_page
        if home is None or not home.ok or home.text is None:
            status, home = await self.validate(normalized)
            profile.status = status
        if home is None or not home.ok or home.text is None:
            profile.reachable = False
            if home is not None and home.reason:
                profile.fetch_errors.append(f"{home.url}: {home.reason}")
                if home.reason in {"robots_disallowed", "access_denied", "challenge_page"}:
                    profile.notes["crawl_blocked"] = home.reason
            return profile

        profile.reachable = True
        profile.final_url = home.final_url
        if profile.status in ("unchecked", ""):
            profile.status = "live"
        base = home.final_url or normalized
        home_page = parse_page(home.text, base, "home")
        self._absorb(profile, home_page)
        profile.pages_by_kind["home"] = base

        # ---- pick which further pages to visit ----
        targets = self._select_targets(home_page, base)
        budget = self.max_pages - 1
        visited = {self._canon(base)}

        for kind, url in targets:
            if budget <= 0:
                break
            canon = self._canon(url)
            if canon in visited:
                continue
            visited.add(canon)
            res = await self.client.fetch(url)
            budget -= 1
            if not res.ok or res.text is None:
                if res.reason:
                    profile.fetch_errors.append(f"{url}: {res.reason}")
                continue
            if not res.is_html:
                continue
            page = parse_page(res.text, res.final_url or url, kind)
            self._absorb(profile, page)
            profile.pages_by_kind.setdefault(kind, res.final_url or url)

            # Contact/team pages often link to per-person bio pages.
            if kind in ("team", "leadership") and budget > 0:
                for sub_url, sub_text in page.links[:80]:
                    if budget <= 0:
                        break
                    if not self._same_site(sub_url, domain) or should_skip_url(sub_url):
                        continue
                    if self._canon(sub_url) in visited:
                        continue
                    if not re.search(r"/(team|staff|our-people|people|bio|profile|attorney|"
                                     r"agent|doctor|provider)s?/[^/]{3,}", sub_url, re.I):
                        continue
                    visited.add(self._canon(sub_url))
                    sub = await self.client.fetch(sub_url)
                    budget -= 1
                    if sub.ok and sub.text and sub.is_html:
                        self._absorb(profile, parse_page(sub.text, sub.final_url or sub_url, kind))

        self._finalize(profile)
        return profile

    # ------------------------------------------------------------------
    def _select_targets(self, home: PageExtract, base: str) -> list[tuple[str, str]]:
        domain = extract_domain(base) or ""
        by_kind: dict[str, list[str]] = {}
        for url, text in home.links:
            if not self._same_site(url, domain) or should_skip_url(url):
                continue
            kind = classify_page(url, text)
            if not kind:
                continue
            bucket = by_kind.setdefault(kind, [])
            if url not in bucket and len(bucket) < 3:
                bucket.append(url)

        # Guess conventional paths the homepage may not link to.
        for kind, guesses in (("contact", ("/contact", "/contact-us", "/contact.html")),
                              ("about", ("/about", "/about-us")),
                              ("team", ("/team", "/our-team"))):
            bucket = by_kind.setdefault(kind, [])
            if not bucket:
                for g in guesses[:2]:
                    bucket.append(urljoin(base, g))

        ordered: list[tuple[str, str]] = []
        for kind in PAGE_PRIORITY:
            for url in by_kind.get(kind, []):
                ordered.append((kind, url))
        return ordered

    def _same_site(self, url: str, domain: str) -> bool:
        d = extract_domain(url)
        if not d or not domain:
            return False
        return registrable_domain(d) == registrable_domain(domain)

    @staticmethod
    def _canon(url: str) -> str:
        p = urlparse(url)
        path = (p.path or "/").rstrip("/") or "/"
        host = p.netloc.lower()
        if host.startswith("www."):
            host = host[4:]
        return f"{host}{path}"

    # ------------------------------------------------------------------
    def _absorb(self, profile: SiteProfile, page: PageExtract) -> None:
        profile.pages.append(page)

        known = {e.address for e in profile.emails}
        for e in page.emails:
            if e.address in known:
                continue
            known.add(e.address)
            profile.emails.append(e)

        for ph in page.phones:
            if ph not in profile.phones:
                profile.phones.append(ph)

        for k, v in page.social.items():
            profile.social.setdefault(k, v)

        source_type = SOURCE_TYPE_FOR_PAGE.get(page.page_kind, "website_homepage")

        # People: only look on pages that plausibly list them.
        if page.page_kind in ("about", "team", "leadership", "contact", "home"):
            groups = [people_from_jsonld(page.jsonld, page.url, "website_structured_data")]
            dom_people: list = []
            if isinstance(page.soup, BeautifulSoup):
                dom_people = people_from_dom(page.soup, page.url, source_type)
                groups.append(dom_people)
            # Free-text parsing runs only as a FALLBACK. On a page whose markup
            # already yielded structured cards, re-reading the flattened text
            # pairs each person with the next card's name and title.
            if not dom_people and page.page_kind in ("team", "leadership", "about"):
                groups.append(people_from_text(page.text, page.url, source_type))
            profile.people = merge_people([profile.people] + groups)

        # Organization-level structured data
        for item in page.jsonld:
            types = item.get("@type")
            types = [types] if isinstance(types, str) else (types or [])
            tl = [str(t).lower() for t in types]
            if any(t in tl for t in ("organization", "localbusiness", "corporation",
                                     "professionalservice", "homeandconstructionbusiness",
                                     "generalcontractor", "hvacbusiness", "plumber",
                                     "roofingcontractor", "electrician", "store",
                                     "medicalorganization", "dentist", "legalservice",
                                     "restaurant", "autorepair")):
                if not profile.jsonld_org:
                    profile.jsonld_org = item
                addr = item.get("address")
                addrs = addr if isinstance(addr, list) else ([addr] if addr else [])
                for a in addrs:
                    if isinstance(a, dict):
                        profile.addresses.append({
                            "street": a.get("streetAddress"),
                            "city": a.get("addressLocality"),
                            "state": a.get("addressRegion"),
                            "postal_code": a.get("postalCode"),
                            "country": a.get("addressCountry") if isinstance(
                                a.get("addressCountry"), str) else None,
                            "source_url": page.url,
                        })
                for k, tgt in (("sameAs", None),):
                    v = item.get(k)
                    vals = v if isinstance(v, list) else ([v] if isinstance(v, str) else [])
                    for s in vals:
                        d = (extract_domain(s) or "")
                        for key, host in (("linkedin", "linkedin.com"),
                                          ("facebook", "facebook.com"),
                                          ("instagram", "instagram.com"),
                                          ("twitter", "twitter.com")):
                            if host in d:
                                profile.social.setdefault(key, s)
                if item.get("foundingDate") and profile.founded_year is None:
                    m = re.search(r"(1[6-9]\d{2}|20[0-2]\d)", str(item["foundingDate"]))
                    if m:
                        profile.founded_year = int(m.group(1))
                        profile.founded_source = page.url
                if item.get("numberOfEmployees") and profile.employee_hint is None:
                    n = item["numberOfEmployees"]
                    val = n.get("value") if isinstance(n, dict) else n
                    try:
                        profile.employee_hint = int(float(str(val)))
                        profile.employee_hint_source = page.url
                    except (TypeError, ValueError):
                        pass
                if item.get("description") and not profile.description:
                    profile.description = str(item["description"])[:2000]
                    profile.description_source = page.url

        page.soup = None  # release the parsed DOM; we only keep extracted data

    def _finalize(self, profile: SiteProfile) -> None:
        if not profile.description:
            for page in profile.pages:
                if page.page_kind in ("about", "home") and page.meta_description:
                    profile.description = page.meta_description[:2000]
                    profile.description_source = page.url
                    break
        if not profile.description:
            for page in profile.pages:
                if page.meta_description:
                    profile.description = page.meta_description[:2000]
                    profile.description_source = page.url
                    break

        blob = "\n".join(p.text for p in profile.pages)[:200_000]

        if profile.founded_year is None:
            m = re.search(
                r"\b(?:est(?:ablished|\.)?|since|serving[^.]{0,40}since|founded(?:\s+in)?|"
                r"family[- ]owned since|in business since)\s*[:\-]?\s*(1[89]\d{2}|20[0-2]\d)\b",
                blob, re.I)
            if m:
                year = int(m.group(1))
                if 1700 <= year <= 2026:
                    profile.founded_year = year
                    profile.founded_source = self._page_url_containing(profile, m.group(0))

        if profile.employee_hint is None:
            m = re.search(
                r"\b(?:over|more than|nearly|team of|staff of|employs|employing)\s+"
                r"([0-9]{1,3}(?:,[0-9]{3})*|[0-9]{1,5})\+?\s+"
                r"(?:employees|team members|technicians|professionals|people|staff)\b",
                blob, re.I)
            if m:
                try:
                    n = int(m.group(1).replace(",", ""))
                    if 1 <= n <= 500_000:
                        profile.employee_hint = n
                        profile.employee_hint_source = self._page_url_containing(profile, m.group(0))
                except ValueError:
                    pass

        loc_url = profile.pages_by_kind.get("locations")
        if loc_url:
            for page in profile.pages:
                if page.url == loc_url:
                    n = self._count_locations(page)
                    if n and n > 1:
                        profile.locations_hint = n
                        profile.locations_hint_source = page.url
                    break
        if profile.locations_hint is None:
            m = re.search(r"\b(\d{1,3})\s+(?:convenient\s+)?locations\b", blob, re.I)
            if m:
                try:
                    n = int(m.group(1))
                    if 1 < n <= 5000:
                        profile.locations_hint = n
                        profile.locations_hint_source = self._page_url_containing(profile, m.group(0))
                except ValueError:
                    pass

        if re.search(r"\b(franchise|franchising|franchisee|independently owned and operated)\b",
                     blob, re.I):
            profile.franchise_hint = "franchise"

    @staticmethod
    def _count_locations(page: PageExtract) -> int | None:
        zips = set(re.findall(r"\b\d{5}(?:-\d{4})?\b", page.text))
        cities = set(re.findall(r"\b([A-Z][a-z]+(?: [A-Z][a-z]+)?),\s*([A-Z]{2})\b", page.text))
        n = max(len(zips), len(cities))
        return n if 1 < n <= 5000 else None

    @staticmethod
    def _page_url_containing(profile: SiteProfile, snippet: str) -> str | None:
        needle = snippet.strip()[:40].lower()
        for page in profile.pages:
            if needle and needle in page.text.lower():
                return page.url
        return profile.base_url

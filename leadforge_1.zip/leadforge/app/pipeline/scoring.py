"""STEP 10 - lead scoring and enrichment completeness.

Score design (0-100). Qualification is binary and separate: a lead is QUALIFIED
iff it has a valid website AND a usable business email. The score then ranks
qualified leads by how actionable they are.

  Email quality        0-40   type tier + verification status
  Contact quality      0-20   named decision maker, title, LinkedIn
  Firmographics        0-20   employees, revenue, industry codes, founded, locations
  Reachability         0-10   phone, address, social presence
  Signals              0-10   observed growth/hiring/expansion signals

An unqualified lead is capped at 25 so it can never outrank a qualified one.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..models import Company, EmailStatus, EmailType

# A qualified lead never scores below this; an unqualified one never above
# UNQUALIFIED_CEILING. The gap keeps the two populations cleanly separated.
QUALIFIED_FLOOR = 30
UNQUALIFIED_CEILING = 25

EMAIL_TYPE_POINTS = {
    EmailType.DECISION_MAKER.value: 24,
    EmailType.EMPLOYEE.value: 17,
    EmailType.GENERAL_BUSINESS.value: 12,
}

EMAIL_STATUS_POINTS = {
    EmailStatus.VERIFIED.value: 16,
    EmailStatus.VALID.value: 12,
    EmailStatus.CATCH_ALL.value: 7,
    EmailStatus.RISKY.value: 4,
    EmailStatus.UNKNOWN.value: 3,
    EmailStatus.INVALID.value: 0,
}

# Fields counted for the "Enrichment %" column shown in the lead table.
ENRICHMENT_FIELDS = [
    "website", "primary_email", "phone", "address", "city", "state", "postal_code",
    "country", "industry", "sub_industry", "naics", "sic", "employee_count",
    "estimated_revenue", "founded_year", "num_locations", "franchise_status",
    "business_description", "linkedin_url", "facebook_url", "instagram_url",
    "contact_name", "contact_title", "contact_email", "decision_maker",
]


@dataclass
class ScoreBreakdown:
    total: int
    email: int
    contact: int
    firmographic: int
    reachability: int
    signals: int
    enrichment_pct: float
    qualified: bool
    reasons: list[str]


def is_qualified(company: Company) -> bool:
    """THE rule: valid website + business email. Nothing else."""
    website_ok = bool(company.website) and company.website_status in {"live", "redirected"}
    email_ok = any(e.is_usable for e in company.emails)
    return website_ok and email_ok


def score_company(company: Company) -> ScoreBreakdown:
    reasons: list[str] = []
    qualified = is_qualified(company)

    # ---------- email (0-40) ----------
    email_pts = 0
    usable = [e for e in company.emails if e.is_usable]
    if usable:
        best = min(usable, key=lambda e: e.priority_key)
        email_pts = EMAIL_TYPE_POINTS.get(best.email_type, 8)
        email_pts += EMAIL_STATUS_POINTS.get(best.status, 0)
        reasons.append(f"email {best.email_type}/{best.status}")
        if len(usable) > 1:
            email_pts = min(40, email_pts + 2)
        if best.is_free_provider:
            email_pts = max(0, email_pts - 5)
            reasons.append("consumer mailbox domain")
        if best.is_disposable:
            email_pts = max(0, email_pts - 8)
    else:
        reasons.append("no usable email")
    email_pts = min(40, email_pts)

    # ---------- contact (0-20) ----------
    contact_pts = 0
    dms = [c for c in company.contacts if c.is_decision_maker]
    if dms:
        contact_pts += 12
        reasons.append(f"decision maker: {dms[0].full_name}")
        if dms[0].job_title:
            contact_pts += 3
        if dms[0].linkedin_url:
            contact_pts += 2
    elif company.contacts:
        contact_pts += 6
        reasons.append("named contact found")
        if any(c.job_title for c in company.contacts):
            contact_pts += 2
    # A decision-maker email linked to a person is the strongest signal.
    if any(e.email_type == EmailType.DECISION_MAKER.value and e.is_usable
           for e in company.emails):
        contact_pts += 3
    contact_pts = min(20, contact_pts)

    # ---------- firmographics (0-20) ----------
    firmo = 0
    if company.employee_count is not None:
        firmo += 5
    elif company.employee_range:
        firmo += 3
    if company.estimated_revenue is not None:
        firmo += 5
    elif company.revenue_range:
        firmo += 3
    if company.industry:
        firmo += 2
    if company.naics:
        firmo += 2
    if company.sic:
        firmo += 1
    if company.founded_year:
        firmo += 2
    if company.num_locations:
        firmo += 2
    if company.business_description:
        firmo += 1
    firmo = min(20, firmo)

    # ---------- reachability (0-10) ----------
    reach = 0
    if company.phone:
        reach += 4
    if company.address:
        reach += 2
    if company.city and company.state:
        reach += 1
    if company.linkedin_url:
        reach += 2
    if company.facebook_url or company.instagram_url:
        reach += 1
    reach = min(10, reach)

    # ---------- signals (0-10) ----------
    sig = 0
    if company.signals:
        high_value = {"expansion", "new_location", "acquisition", "new_construction",
                      "funding", "large_project", "new_contract"}
        for s in company.signals:
            sig += 4 if s.signal_type in high_value else 2
        reasons.append(f"{len(company.signals)} business signal(s)")
    sig = min(10, sig)

    total = email_pts + contact_pts + firmo + reach + sig

    # Qualification is binary and always outranks enrichment: a bare qualified
    # lead must never score below a richly-enriched unqualified one. So
    # qualified leads get a floor and unqualified ones a hard ceiling, with a
    # gap between them.
    # Both populations are rescaled rather than clamped, so ordering within
    # each band is fully preserved.
    if qualified:
        total = QUALIFIED_FLOOR + total * (100 - QUALIFIED_FLOOR) / 100.0
    else:
        total = total * UNQUALIFIED_CEILING / 100.0
        reasons.append("NOT QUALIFIED (needs website + email)")

    return ScoreBreakdown(
        total=int(max(0, min(100, total))),
        email=email_pts, contact=contact_pts, firmographic=firmo,
        reachability=reach, signals=sig,
        enrichment_pct=enrichment_percent(company),
        qualified=qualified, reasons=reasons,
    )


def enrichment_percent(company: Company) -> float:
    filled = 0
    best_email = company.best_email
    primary_contact = company.primary_contact
    values = {
        "website": company.website,
        "primary_email": best_email.address if best_email else None,
        "phone": company.phone,
        "address": company.address,
        "city": company.city,
        "state": company.state,
        "postal_code": company.postal_code,
        "country": company.country,
        "industry": company.industry,
        "sub_industry": company.sub_industry,
        "naics": company.naics,
        "sic": company.sic,
        "employee_count": company.employee_count,
        "estimated_revenue": company.estimated_revenue,
        "founded_year": company.founded_year,
        "num_locations": company.num_locations,
        "franchise_status": company.franchise_status,
        "business_description": company.business_description,
        "linkedin_url": company.linkedin_url,
        "facebook_url": company.facebook_url,
        "instagram_url": company.instagram_url,
        "contact_name": primary_contact.full_name if primary_contact else None,
        "contact_title": primary_contact.job_title if primary_contact else None,
        "contact_email": (best_email.address
                          if best_email and best_email.contact_id else None),
        "decision_maker": next((c.full_name for c in company.contacts
                                if c.is_decision_maker), None),
    }
    for key in ENRICHMENT_FIELDS:
        if values.get(key) not in (None, "", []):
            filled += 1
    return round(100.0 * filled / len(ENRICHMENT_FIELDS), 1)

"""STEP 9 - publicly observable business signals.

Every signal carries the exact URL it was observed on and the sentence that
triggered it, so nothing is asserted without evidence the operator can click.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..core.email_extract import PageExtract

# (signal_type, human label, confidence, regex)
SIGNAL_RULES: list[tuple[str, str, float, re.Pattern]] = [
    ("hiring", "Actively hiring", 0.7, re.compile(
        r"\b(now hiring|we'?re hiring|we are hiring|join our (?:growing )?team|"
        r"open positions|current openings|job openings|apply today|apply now|"
        r"immediate openings|accepting applications|career opportunities)\b", re.I)),
    ("rapid_growth", "Growth language", 0.55, re.compile(
        r"\b(fastest[- ]growing|rapidly growing|rapid growth|growing team|"
        r"doubled (?:our|in) \w+|record (?:year|growth|revenue)|"
        r"inc\.? 5000|inc 5000|fastest growing companies)\b", re.I)),
    ("new_location", "New location or office", 0.75, re.compile(
        r"\b(new location|newest location|now open in|now serving|grand opening|"
        r"opening (?:soon|our) (?:new )?(?:location|office|branch|facility|"
        r"showroom|shop)|second location|third location|new (?:office|branch|"
        r"facility|warehouse|showroom) in)\b", re.I)),
    ("expansion", "Expansion", 0.7, re.compile(
        r"\b(expanding (?:into|to|our)|expansion (?:into|to|of|project)|"
        r"expanded (?:our|into|to)|broadening our (?:reach|service)|"
        r"extending our service area)\b", re.I)),
    ("acquisition", "Acquisition or merger", 0.8, re.compile(
        r"\b(acquires?|acquired|acquisition of|has been acquired|merger with|"
        r"merges with|merged with|joins forces with|partnership with)\b", re.I)),
    ("new_construction", "New construction or facility build", 0.75, re.compile(
        r"\b(breaks? ground|groundbreaking|new headquarters|new facility|"
        r"building a new|construction of our|new (?:plant|warehouse|campus)|"
        r"ribbon cutting)\b", re.I)),
    ("equipment_purchase", "Equipment or fleet investment", 0.65, re.compile(
        r"\b(new (?:fleet|trucks?|equipment|machinery|excavators?|cnc|"
        r"press|line)|invested in (?:new )?(?:equipment|machinery|technology)|"
        r"fleet expansion|added \d+ (?:new )?(?:trucks?|vehicles?|machines?))\b", re.I)),
    ("large_project", "Major project or award", 0.7, re.compile(
        r"\b(awarded (?:the|a|our)|awarded a \$?[\d.,]+ ?(?:million|m|k)?|"
        r"selected (?:as|to)|wins? (?:the )?(?:contract|bid|project)|"
        r"completed (?:the|a) \$?[\d.,]+ ?(?:million|m)|multi[- ]million dollar "
        r"(?:project|contract))\b", re.I)),
    ("new_contract", "New contract", 0.7, re.compile(
        r"\b(new contract|signed (?:a|an) (?:contract|agreement)|"
        r"multi[- ]year (?:contract|agreement)|contract award|"
        r"renewed (?:its|their|our) contract)\b", re.I)),
    ("franchise_expansion", "Franchise expansion", 0.7, re.compile(
        r"\b(franchise opportunit|become a franchisee|franchising available|"
        r"new franchise|franchise expansion|now franchising)\b", re.I)),
    ("certification", "New certification or accreditation", 0.5, re.compile(
        r"\b(newly certified|now certified|achieved (?:iso|nate|osha)|"
        r"iso ?900\d certified|earned (?:our|the) .{0,25}certification)\b", re.I)),
    ("funding", "Funding or investment", 0.75, re.compile(
        r"\b(raised \$?[\d.,]+ ?(?:million|m|k|billion)|series [a-e] (?:round|funding)|"
        r"secured (?:financing|funding|investment)|closed (?:a|an) \$?[\d.,]+)\b", re.I)),
]

# A signal on a careers page is much stronger evidence of hiring.
_KIND_BOOST = {
    ("hiring", "careers"): 0.25,
    ("new_location", "locations"): 0.15,
    ("new_location", "news"): 0.1,
    ("expansion", "news"): 0.1,
    ("acquisition", "news"): 0.15,
    ("large_project", "news"): 0.1,
    ("funding", "news"): 0.15,
}

_JOB_LISTING_RE = re.compile(
    r"\b(apply|view (?:job|position)|full[- ]time|part[- ]time|"
    r"job (?:id|number|title)|salary|hourly|benefits package)\b", re.I)


@dataclass
class FoundSignal:
    signal_type: str
    title: str
    snippet: str
    source_url: str
    source_type: str
    confidence: float


SOURCE_TYPE_FOR_PAGE = {
    "home": "website_homepage",
    "contact": "website_contact_page",
    "about": "website_about_page",
    "team": "website_team_page",
    "leadership": "website_leadership_page",
    "locations": "website_locations_page",
    "careers": "website_careers_page",
    "news": "website_news_page",
    "services": "website_homepage",
    "other": "website_homepage",
}


def detect_signals(pages: list[PageExtract], max_signals: int = 12) -> list[FoundSignal]:
    found: dict[tuple[str, str], FoundSignal] = {}

    for page in pages:
        text = page.text
        if not text:
            continue
        source_type = SOURCE_TYPE_FOR_PAGE.get(page.page_kind, "website_homepage")

        for signal_type, label, base_conf, pattern in SIGNAL_RULES:
            m = pattern.search(text)
            if not m:
                continue
            conf = min(0.95, base_conf + _KIND_BOOST.get((signal_type, page.page_kind), 0.0))
            snippet = _sentence_around(text, m.start(), m.end())
            key = (signal_type, page.url)
            if key in found and found[key].confidence >= conf:
                continue
            found[key] = FoundSignal(signal_type, label, snippet, page.url,
                                     source_type, round(conf, 2))

        # A careers page that actually lists roles is stronger than the phrase alone.
        if page.page_kind == "careers" and len(_JOB_LISTING_RE.findall(text)) >= 3:
            key = ("hiring", page.url)
            existing = found.get(key)
            conf = 0.85
            if existing is None or existing.confidence < conf:
                found[key] = FoundSignal(
                    "hiring", "Job listings published", _sentence_around(text, 0, 200),
                    page.url, "website_careers_page", conf)

    out = sorted(found.values(), key=lambda s: -s.confidence)
    # Keep at most one instance of a signal type from each page kind, capped overall.
    seen_types: dict[str, int] = {}
    result = []
    for s in out:
        n = seen_types.get(s.signal_type, 0)
        if n >= 2:
            continue
        seen_types[s.signal_type] = n + 1
        result.append(s)
        if len(result) >= max_signals:
            break
    return result


def _sentence_around(text: str, start: int, end: int, width: int = 220) -> str:
    lo = max(0, start - width)
    hi = min(len(text), end + width)
    chunk = text[lo:hi]
    chunk = re.sub(r"\s+", " ", chunk).strip()
    # Trim to sentence-ish boundaries.
    if lo > 0:
        idx = chunk.find(". ")
        if 0 <= idx < 80:
            chunk = chunk[idx + 2:]
    if hi < len(text):
        idx = chunk.rfind(". ")
        if idx > len(chunk) - 120:
            chunk = chunk[: idx + 1]
    return chunk[:500]

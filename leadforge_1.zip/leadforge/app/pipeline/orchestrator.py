"""The enrichment pipeline.

STEP 1  Business discovery
STEP 2  Website validation
STEP 3  Deduplication
STEP 4  Website scraping
STEP 5  Email discovery
STEP 6  Email validation
STEP 7  Contact enrichment
STEP 8  Firmographic enrichment
STEP 9  Business signals
STEP 10 Lead score

Cost discipline: a company only advances to the next (more expensive) step if
the cheaper steps left something worth paying for, and every provider response
is cached by domain so the same company is never enriched twice.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import settings
from ..core.cache import cache_get, cache_set, job_paid_spend, make_key, record_call
from ..core.email_extract import (
    FoundEmail,
    classify_email_type,
    is_disposable_domain,
    is_free_provider,
    is_role_account,
    local_part_matches_person,
)
from ..core.normalize import (
    address_fingerprint,
    employee_range,
    extract_domain,
    normalize_company_name,
    normalize_phone,
    registrable_domain,
    revenue_range,
    split_person_name,
)
from ..core.taxonomy import find_industry, industry_by_key, normalize_state
from ..db import session_scope
from ..models import (
    Company,
    Contact,
    EmailRecord,
    EmailStatus,
    EmailType,
    FieldSource,
    Job,
    JobCompany,
    JobStatus,
    Signal,
    SourceType,
    WebsiteStatus,
)
from ..providers import registry
from ..providers.base import CostTier, DiscoveredBusiness
from ..schemas import SearchCriteria
from .crawler import SiteCrawler, SiteProfile
from .dedupe import find_existing, merge_companies, merge_into
from .scoring import is_qualified, score_company
from .signals import detect_signals

log = logging.getLogger(__name__)

CACHE_OPERATION_SITE = "site_profile"

# Job counters live in memory and are written to the DB at most this often.
STATS_FLUSH_SECONDS = 2.0


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ==========================================================================
# Source-tracking helper
# ==========================================================================

async def record_source(session: AsyncSession, company: Company, field: str,
                        value, source_type: str, *, source_url: str | None = None,
                        provider: str | None = None, confidence: float = 0.6,
                        is_estimate: bool = False) -> None:
    """Write/refresh the provenance row for one field of one company."""
    if value in (None, "", []):
        return
    existing = (await session.execute(
        select(FieldSource).where(FieldSource.company_id == company.id,
                                  FieldSource.field == field)
    )).scalar_one_or_none()
    text_value = str(value)[:2000]
    if existing:
        if existing.confidence >= confidence:
            return
        existing.value = text_value
        existing.source_type = source_type
        existing.source_url = source_url
        existing.provider = provider
        existing.confidence = confidence
        existing.is_estimate = is_estimate
        existing.observed_at = utcnow()
    else:
        session.add(FieldSource(
            company_id=company.id, field=field, value=text_value,
            source_type=source_type, source_url=source_url, provider=provider,
            confidence=confidence, is_estimate=is_estimate,
        ))


# ==========================================================================
# Job runner
# ==========================================================================

class JobRunner:
    def __init__(self, job_id: int):
        self.job_id = job_id
        self.crawler = SiteCrawler()
        self.stats: dict = {}
        self._stats_lock = asyncio.Lock()
        self._stats_flushed_at = 0.0
        self._cancelled = False
        self._cancel_checked_at = 0.0

    # ---------------------------------------------------------------- run
    async def run(self) -> None:
        flusher = asyncio.create_task(self._stats_flusher())
        try:
            criteria, target = await self._load_job()
            await self._set_status(JobStatus.RUNNING, stage="discovery")
            companies = await self._step1_discovery(criteria, target)
            if not companies:
                await self._finish(JobStatus.COMPLETED,
                                   error="No businesses matched the search criteria.")
                return
            await self._set_status(JobStatus.RUNNING, stage="enrichment")
            await self._enrich_all(companies)
            await self._finish(JobStatus.COMPLETED)
        except asyncio.CancelledError:
            await self._finish(JobStatus.CANCELLED)
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("job %s failed", self.job_id)
            await self._finish(JobStatus.FAILED, error=f"{type(exc).__name__}: {exc}"[:2000])
        finally:
            flusher.cancel()

    async def _load_job(self) -> tuple[SearchCriteria, int]:
        async with session_scope() as session:
            job = await session.get(Job, self.job_id)
            if job is None:
                raise RuntimeError(f"job {self.job_id} not found")
            self.stats = dict(job.stats or {})
            return SearchCriteria(**(job.query or {})), job.target_count

    # ================================================== STEP 1: discovery
    async def _step1_discovery(self, criteria: SearchCriteria, target: int) -> list[int]:
        providers = registry.discovery_providers()
        if not providers:
            raise RuntimeError("no discovery providers configured")

        collected: list[DiscoveredBusiness] = []
        seen_ids: set[str] = set()
        for provider in providers:
            if await self._check_cancel():
                break
            remaining = target - len(collected)
            if remaining <= 0:
                break
            try:
                found = await provider.search(criteria, remaining)
            except Exception as exc:  # noqa: BLE001
                log.warning("discovery provider %s failed: %s", provider.name, exc)
                await self._bump(errors=1)
                continue
            async with session_scope() as session:
                await record_call(session, provider.name, "search", job_id=self.job_id,
                                  cost_units=provider.cost_units * max(1, len(found) // 20))
            for biz in found:
                key = biz.external_id or f"{biz.name}|{biz.postal_code or ''}"
                if key in seen_ids:
                    continue
                seen_ids.add(key)
                collected.append(biz)
            log.info("discovery %s -> %s records (total %s)",
                     provider.name, len(found), len(collected))
            if provider.cost_tier == CostTier.FREE and len(collected) >= target:
                break

        company_ids = await self._persist_discovered(collected, criteria)
        await self._bump(businesses_found=len(company_ids))
        return company_ids

    async def _persist_discovered(self, businesses: list[DiscoveredBusiness],
                                  criteria: SearchCriteria) -> list[int]:
        """Insert with STEP 3 deduplication applied at write time."""
        ids: list[int] = []
        merged = 0
        async with session_scope() as session:
            for biz in businesses:
                existing = await find_existing(session, biz)
                if existing is not None:
                    changed = merge_into(existing, _biz_to_values(biz))
                    for field in changed:
                        await record_source(session, existing, field,
                                            getattr(existing, field),
                                            SourceType.DIRECTORY.value,
                                            source_url=biz.source_url,
                                            provider=biz.provider, confidence=0.55)
                    merged += 1
                    company = existing
                else:
                    company = self._new_company(biz, criteria)
                    session.add(company)
                    await session.flush()
                    for field, value in _biz_to_values(biz).items():
                        if value not in (None, "", []):
                            await record_source(session, company, field, value,
                                                SourceType.DIRECTORY.value,
                                                source_url=biz.source_url,
                                                provider=biz.provider, confidence=0.55)
                # OSM/import records sometimes carry a published email.
                published = (biz.extra or {}).get("email")
                if published:
                    await self._store_directory_email(session, company, published,
                                                      biz.source_url, biz.provider)
                for key in ("facebook", "instagram", "linkedin", "twitter"):
                    val = (biz.extra or {}).get(key)
                    if val and not getattr(company, f"{key}_url", None):
                        setattr(company, f"{key}_url", val)

                link = (await session.execute(
                    select(JobCompany).where(JobCompany.job_id == self.job_id,
                                             JobCompany.company_id == company.id)
                )).scalar_one_or_none()
                if link is None:
                    session.add(JobCompany(job_id=self.job_id, company_id=company.id,
                                           stage="discovered"))
                if company.id not in ids:
                    ids.append(company.id)
        await self._bump(duplicates_merged=merged)
        return ids

    def _new_company(self, biz: DiscoveredBusiness, criteria: SearchCriteria) -> Company:
        domain = extract_domain(biz.website) if biz.website else None
        ind = industry_by_key().get(criteria.industry or "") or find_industry(biz.industry or biz.name)
        return Company(
            name=biz.name[:512],
            name_normalized=normalize_company_name(biz.name),
            domain=domain,
            website=biz.website,
            phone=biz.phone,
            phone_normalized=normalize_phone(biz.phone, biz.country or "US"),
            address=biz.address,
            address_hash=address_fingerprint(biz.address, biz.city, biz.postal_code),
            city=biz.city, state=normalize_state(biz.state) or biz.state,
            postal_code=biz.postal_code, country=biz.country or criteria.country,
            latitude=biz.latitude, longitude=biz.longitude,
            industry=biz.industry or (ind.name if ind else None),
            sub_industry=biz.sub_industry or (ind.sub_industry if ind else None),
            naics=biz.naics or (ind.naics if ind else None),
            sic=biz.sic or (ind.sic if ind else None),
            employee_count=biz.employee_count,
            employee_range=employee_range(biz.employee_count),
            founded_year=biz.founded_year,
            business_description=biz.description,
            franchise_status=(biz.extra or {}).get("franchise_hint"),
            website_status=(WebsiteStatus.UNCHECKED.value if biz.website
                            else WebsiteStatus.NOT_FOUND.value),
            discovery_provider=biz.provider,
            discovery_query=criteria.describe()[:512],
            external_ids={biz.provider: biz.external_id} if biz.external_id else {},
            pipeline_stage="discovered",
        )

    async def _store_directory_email(self, session: AsyncSession, company: Company,
                                     raw: str, source_url: str | None,
                                     provider: str) -> None:
        from ..core.email_extract import EMAIL_RE
        for piece in str(raw).split(";"):
            m = EMAIL_RE.search(piece.strip())
            if not m:
                continue
            address = f"{m.group(1).lower()}@{m.group(2).lower()}"  # reassembly-of-parsed-address
            if any(e.address == address for e in company.emails):
                continue
            local, dom = address.split("@", 1)
            company.emails.append(EmailRecord(
                company_id=company.id, address=address, local_part=local,
                email_domain=dom,
                email_type=(EmailType.GENERAL_BUSINESS.value if is_role_account(local)
                            else EmailType.GENERAL_BUSINESS.value),
                status=EmailStatus.UNKNOWN.value,
                discovery_method="directory_listing",
                source_type=SourceType.DIRECTORY.value,
                source_url=source_url, provider=provider,
                is_role_account=is_role_account(local),
                is_disposable=is_disposable_domain(dom),
                is_free_provider=is_free_provider(dom),
                confidence=0.7,
            ))

    # ============================================== STEPS 2-10 (per company)
    async def _enrich_all(self, company_ids: list[int]) -> None:
        sem = asyncio.Semaphore(settings.worker_concurrency)
        queue: asyncio.Queue[int] = asyncio.Queue()
        for cid in company_ids:
            queue.put_nowait(cid)

        async def worker() -> None:
            while True:
                try:
                    cid = queue.get_nowait()
                except asyncio.QueueEmpty:
                    return
                try:
                    if await self._check_cancel():
                        return
                    async with sem:
                        await self._enrich_one(cid)
                except Exception as exc:  # noqa: BLE001
                    log.warning("company %s enrichment failed: %s", cid, exc)
                    await self._bump(errors=1)
                    async with session_scope() as session:
                        link = (await session.execute(
                            select(JobCompany).where(JobCompany.job_id == self.job_id,
                                                     JobCompany.company_id == cid)
                        )).scalar_one_or_none()
                        if link:
                            link.error = f"{type(exc).__name__}: {exc}"[:500]
                            link.stage = "error"
                finally:
                    await self._bump(companies_processed=1)
                    queue.task_done()

        workers = [asyncio.create_task(worker())
                   for _ in range(min(settings.worker_concurrency, max(1, len(company_ids))))]
        await asyncio.gather(*workers, return_exceptions=True)

    async def _enrich_one(self, company_id: int) -> None:
        # ---------------- STEP 2: website validation ----------------
        # Read first, do the network work with NO transaction open, then write.
        # Holding a write transaction across an await would serialise every
        # worker behind one HTTP request.
        async with session_scope(write=False) as session:
            company = await session.get(Company, company_id)
            if company is None:
                return
            website = company.website

        if not website:
            async with session_scope() as session:
                company = await session.get(Company, company_id)
                if company is None:
                    return
                company.website_status = WebsiteStatus.NOT_FOUND.value
                company.pipeline_stage = "no_website"
                company.is_qualified = False
                await self._score_and_store(session, company)
                await self._set_item_stage(session, company_id, "no_website")
            return

        status, first = await self.crawler.validate(website)          # network
        final_url = first.final_url if first is not None else None
        await self._bump(websites_found=1)

        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None:
                return
            company.website_status = status
            company.website_checked_at = utcnow()
            company.website_final_url = final_url
            await record_source(session, company, "website", company.website,
                                SourceType.WEBSITE_HOMEPAGE.value,
                                source_url=final_url or company.website,
                                provider="website_validation", confidence=0.9)
            if status not in ("live", "redirected"):
                company.pipeline_stage = f"website_{status}"
                company.is_qualified = False
                await self._score_and_store(session, company)
                await self._set_item_stage(session, company_id, company.pipeline_stage)
                return

            # ---------------- STEP 3: dedupe on resolved domain -------------
            merged_into = None
            resolved_domain = extract_domain(final_url or company.website)
            if resolved_domain and resolved_domain != company.domain:
                dup = (await session.execute(
                    select(Company).where(Company.domain == resolved_domain,
                                          Company.id != company.id)
                )).scalars().first()
                if dup is not None:
                    await merge_companies(session, dup, company)
                    await self._relink_job_company(session, company_id, dup.id)
                    merged_into = dup.id
                else:
                    company.domain = resolved_domain
            elif resolved_domain:
                company.domain = resolved_domain

        await self._bump(websites_validated=1)
        if merged_into is not None:
            await self._bump(duplicates_merged=1)
            company_id = merged_into

        # ---------------- STEP 4: crawl (network, no transaction) -----------
        profile = await self._crawl_cached(company_id)

        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None:
                return
            if profile.notes.get("crawl_blocked"):
                company.scrape_notes = {**(company.scrape_notes or {}),
                                        "crawl_blocked": profile.notes["crawl_blocked"]}
            if profile.pages:
                await self._bump(sites_scraped=1)

            # ---------------- STEP 7 (part 1): contacts from the site --------
            await self._step7_contacts(session, company, profile)

            # ---------------- STEP 5: email discovery -----------------------
            n_new = await self._step5_emails(session, company, profile)

            # ---------------- STEP 8: firmographics from the site -----------
            await self._step8_firmographics(session, company, profile)

            # ---------------- STEP 9: signals -------------------------------
            await self._step9_signals(session, company, profile)

            company.pipeline_stage = "scraped"
            await session.flush()

        # ---------------- STEP 5b: paid email finders (only if needed) ------
        await self._step5b_paid_finders(company_id)

        # ---------------- STEP 6: email validation --------------------------
        await self._step6_validate(company_id)

        # ---------------- STEP 8b: paid enrichment (only if worthwhile) -----
        await self._step8b_paid_enrichment(company_id)

        # ---------------- STEP 10: score ------------------------------------
        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None:
                return
            was_qualified = company.is_qualified
            breakdown = await self._score_and_store(session, company)
            company.pipeline_stage = "enriched"
            company.last_enriched_at = utcnow()
            await self._set_item_stage(session, company_id, "enriched")
            if breakdown.qualified and not was_qualified:
                await self._bump(qualified_leads=1)
        _ = n_new

    # ------------------------------------------------------------------
    async def _crawl_cached(self, company_id: int) -> SiteProfile:
        """STEP 4. Cached by domain so re-running a job never re-crawls."""
        async with session_scope(write=False) as session:
            company = await session.get(Company, company_id)
            if company is None or not company.website:
                return SiteProfile(base_url="", domain="")
            url = company.website_final_url or company.website
            domain = company.domain or extract_domain(url) or ""
            key = make_key(domain)
            cached = await cache_get(session, "website_crawl", CACHE_OPERATION_SITE, key)
            if cached:
                await record_call(session, "website_crawl", CACHE_OPERATION_SITE,
                                  job_id=self.job_id, company_id=company_id, cache_hit=True)
                await self._bump(cache_hits=1)
                return _profile_from_cache(cached)

        profile = await self.crawler.crawl(url)

        async with session_scope() as session:
            await cache_set(session, "website_crawl", CACHE_OPERATION_SITE,
                            make_key(domain), _profile_to_cache(profile))
            await record_call(session, "website_crawl", CACHE_OPERATION_SITE,
                              job_id=self.job_id, company_id=company_id, cost_units=0.0)
        return profile

    # ---------------------------------------------- STEP 7: contacts
    async def _step7_contacts(self, session: AsyncSession, company: Company,
                              profile: SiteProfile) -> None:
        existing = {c.full_name.lower() for c in company.contacts}
        added = 0
        for person in profile.people[:25]:
            if person.full_name.lower() in existing:
                continue
            if not person.job_title and not person.is_decision_maker:
                # Names with no recognisable role add noise; keep only titled people.
                continue
            existing.add(person.full_name.lower())
            contact = Contact(
                company_id=company.id,
                first_name=person.first_name, last_name=person.last_name,
                full_name=person.full_name[:256], job_title=person.job_title,
                seniority=person.seniority, is_decision_maker=person.is_decision_maker,
                linkedin_url=person.linkedin_url,
                source_type=person.source_type, source_url=person.source_url,
                provider="website_scrape", confidence=round(min(0.95, person.confidence), 2),
            )
            # Append to the relationship, not just session.add(): STEP 5 reads
            # company.contacts to tie discovered emails to discovered people, and
            # a bare session.add() leaves that already-loaded collection stale.
            company.contacts.append(contact)
            added += 1
        if added:
            await session.flush()
            await self._bump(contacts_found=added)
            if any(p.is_decision_maker for p in profile.people):
                await self._bump(decision_makers_found=1)
            dm = next((c for c in company.contacts if c.is_decision_maker), None)
            if dm:
                await record_source(session, company, "decision_maker", dm.full_name,
                                    dm.source_type, source_url=dm.source_url,
                                    provider="website_scrape", confidence=dm.confidence)

    # ---------------------------------------------- STEP 5: emails
    async def _step5_emails(self, session: AsyncSession, company: Company,
                            profile: SiteProfile) -> int:
        if not profile.emails:
            return 0
        company_domain = registrable_domain(company.domain or profile.domain)
        existing = {e.address for e in company.emails}
        contacts = list(company.contacts)
        added = 0

        ranked = sorted(profile.emails, key=lambda e: -_email_source_weight(e, company_domain))
        for found in ranked[:30]:
            if found.address in existing:
                continue
            email_domain = registrable_domain(found.domain)
            on_company_domain = bool(company_domain) and email_domain == company_domain
            free_mailbox = is_free_provider(found.domain)

            matched_contact, matched_is_dm = _match_contact(found, contacts, profile)

            # Which off-domain addresses to keep. Plenty of real businesses
            # publish an address on a different domain (a .net variant, a parent
            # company, a mail-only domain), so rejecting every off-domain address
            # silently loses genuine leads. Keep the ones the site itself
            # presents as a way to contact it; drop the rest as third-party noise
            # (a web designer's address in a footer, a vendor mentioned in copy).
            if not on_company_domain:
                published_as_contact = (
                    found.method in ("mailto_link", "structured_data")
                    or is_role_account(found.local_part)
                    or matched_contact is not None
                )
                if free_mailbox:
                    if not (published_as_contact
                            or _looks_like_company_contact(found, profile)):
                        continue
                elif not published_as_contact:
                    continue
            etype = classify_email_type(found.local_part,
                                        matched_is_dm,
                                        matched_contact is not None)

            confidence = found.confidence
            if on_company_domain:
                confidence = min(0.95, confidence + 0.1)
            else:
                # Real, but the operator should know it isn't the website domain.
                confidence = max(0.2, confidence - 0.1)
            if matched_contact is not None:
                confidence = min(0.95, confidence + 0.05)

            record = EmailRecord(
                company_id=company.id,
                contact_id=matched_contact.id if matched_contact else None,
                address=found.address, local_part=found.local_part,
                email_domain=found.domain,
                email_type=etype,
                status=EmailStatus.UNKNOWN.value,
                discovery_method=found.method,
                source_type=_source_type_for_url(found.source_url, profile),
                source_url=found.source_url,
                provider="website_crawl",
                is_role_account=is_role_account(found.local_part),
                is_disposable=is_disposable_domain(found.domain),
                is_free_provider=free_mailbox,
                confidence=round(confidence, 2),
            )
            # Append to the relationship so the already-loaded company.emails
            # collection stays current for the source-tracking and scoring
            # steps that read it later in this same transaction.
            company.emails.append(record)
            existing.add(found.address)
            added += 1
            if matched_contact is not None and not matched_contact.linkedin_url:
                pass

        if added:
            await session.flush()
            await self._bump(emails_found=added)
            best = min((e for e in company.emails if e.is_usable),
                       key=lambda e: e.priority_key, default=None)
            if best:
                await record_source(session, company, "email", best.address,
                                    best.source_type, source_url=best.source_url,
                                    provider=best.provider, confidence=best.confidence)
        return added

    async def _step5b_paid_finders(self, company_id: int) -> None:
        """Only reached when free discovery produced nothing usable."""
        finders = registry.email_finders()
        if not finders:
            return
        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None or not company.domain:
                return
            has_dm = any(e.email_type == EmailType.DECISION_MAKER.value and e.is_usable
                         for e in company.emails)
            has_any = any(e.is_usable for e in company.emails)
            if has_dm or (has_any and settings.skip_paid_when_qualified):
                return
            if not await self._budget_ok(session):
                return
            domain = company.domain
            existing = {e.address for e in company.emails}
            contacts = list(company.contacts)
            company_pk = company.id

        for provider in finders:
            async with session_scope(write=False) as session:
                key = make_key(domain)
                cached = await cache_get(session, provider.name, "domain_search", key)
            if cached is None:
                try:
                    results = await provider.find(domain)
                except Exception as exc:  # noqa: BLE001
                    log.warning("email finder %s failed for %s: %s", provider.name, domain, exc)
                    continue
                payload = [_provider_email_to_dict(r) for r in results]
                async with session_scope() as session:
                    await cache_set(session, provider.name, "domain_search", key, payload)
                    await record_call(session, provider.name, "domain_search",
                                      job_id=self.job_id, company_id=company_pk,
                                      cost_units=provider.cost_units)
            else:
                payload = cached
                async with session_scope() as session:
                    await record_call(session, provider.name, "domain_search",
                                      job_id=self.job_id, company_id=company_pk,
                                      cache_hit=True)
                await self._bump(cache_hits=1)

            if not payload:
                continue

            async with session_scope() as session:
                company = await session.get(Company, company_pk)
                if company is None:
                    return
                added = 0
                for item in payload:
                    address = (item.get("address") or "").lower()
                    if not address or address in existing:
                        continue
                    local, dom = address.split("@", 1) if "@" in address else (address, "")
                    if not dom:
                        continue
                    contact = None
                    full_name = " ".join(x for x in [item.get("first_name"),
                                                     item.get("last_name")] if x)
                    if full_name:
                        contact = await self._upsert_contact(
                            session, company, full_name, item.get("job_title"),
                            provider.name, item.get("source_url"))
                    company.emails.append(EmailRecord(
                        company_id=company.id,
                        contact_id=contact.id if contact else None,
                        address=address, local_part=local, email_domain=dom,
                        email_type=item.get("email_type") or EmailType.GENERAL_BUSINESS.value,
                        status=EmailStatus.UNKNOWN.value,
                        discovery_method=f"provider:{provider.name}",
                        source_type=SourceType.EMAIL_PROVIDER.value,
                        source_url=item.get("source_url"),
                        provider=provider.name,
                        is_role_account=is_role_account(local),
                        is_disposable=is_disposable_domain(dom),
                        is_free_provider=is_free_provider(dom),
                        confidence=float(item.get("confidence") or 0.7),
                    ))
                    existing.add(address)
                    added += 1
                if added:
                    await session.flush()
                    await self._bump(emails_found=added)
                    break  # stop escalating once we have something
            _ = contacts

    async def _upsert_contact(self, session: AsyncSession, company: Company,
                              full_name: str, title: str | None, provider: str,
                              source_url: str | None) -> Contact | None:
        from ..core.titles import classify_title
        for c in company.contacts:
            if c.full_name.lower() == full_name.lower():
                if title and not c.job_title:
                    c.job_title = title
                    sen, _, dm = classify_title(title)
                    c.seniority, c.is_decision_maker = sen, dm
                return c
        seniority, _, is_dm = classify_title(title)
        first, last = split_person_name(full_name)
        contact = Contact(company_id=company.id, first_name=first, last_name=last,
                          full_name=full_name[:256], job_title=title,
                          seniority=seniority, is_decision_maker=is_dm,
                          source_type=SourceType.ENRICHMENT_PROVIDER.value,
                          source_url=source_url, provider=provider, confidence=0.8)
        session.add(contact)
        await session.flush()
        company.contacts.append(contact)
        if is_dm:
            await self._bump(decision_makers_found=1)
        await self._bump(contacts_found=1)
        return contact

    # ---------------------------------------------- STEP 6: validation
    async def _step6_validate(self, company_id: int) -> None:
        local = next((p for p in registry.email_verifiers() if p.cost_tier == CostTier.FREE),
                     None)
        paid = registry.best_paid_verifier()

        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None or not company.emails:
                return
            pending = [e for e in company.emails
                       if e.status == EmailStatus.UNKNOWN.value or e.verified_at is None]
            addresses = [(e.id, e.address) for e in pending]

        if not addresses:
            return

        # ---- free verifier first (always) ----
        results: dict[int, object] = {}
        if local is not None:
            for email_id, address in addresses:
                async with session_scope(write=False) as session:
                    key = make_key(address)
                    cached = await cache_get(session, local.name, "verify", key)
                if cached:
                    results[email_id] = cached
                    await self._bump(cache_hits=1)
                    continue
                try:
                    res = await local.verify(address)
                except Exception as exc:  # noqa: BLE001
                    log.debug("local verify failed for %s: %s", address, exc)
                    continue
                payload = _verification_to_dict(res)
                results[email_id] = payload
                async with session_scope() as session:
                    await cache_set(session, local.name, "verify", key, payload, ttl_days=14)
                    await record_call(session, local.name, "verify", job_id=self.job_id,
                                      company_id=company_id)

        await self._apply_verifications(company_id, results)

        # ---- paid verifier: only to upgrade the single best usable email ----
        if paid is None:
            return
        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None:
                return
            if not await self._budget_ok(session):
                return
            usable = [e for e in company.emails if e.is_usable]
            if not usable:
                return
            best = min(usable, key=lambda e: e.priority_key)
            if best.status == EmailStatus.VERIFIED.value or \
                    best.verification_provider == paid.name:
                return
            best_id, best_address = best.id, best.address

        async with session_scope(write=False) as session:
            key = make_key(best_address)
            cached = await cache_get(session, paid.name, "verify", key)
        if cached:
            payload = cached
            await self._bump(cache_hits=1)
            async with session_scope() as session:
                await record_call(session, paid.name, "verify", job_id=self.job_id,
                                  company_id=company_id, cache_hit=True)
        else:
            try:
                res = await paid.verify(best_address)
            except Exception as exc:  # noqa: BLE001
                log.warning("paid verify failed for %s: %s", best_address, exc)
                return
            payload = _verification_to_dict(res)
            async with session_scope() as session:
                await cache_set(session, paid.name, "verify", key, payload, ttl_days=60)
                await record_call(session, paid.name, "verify", job_id=self.job_id,
                                  company_id=company_id, cost_units=paid.cost_units)
        await self._apply_verifications(company_id, {best_id: payload})

    async def _apply_verifications(self, company_id: int, results: dict) -> None:
        if not results:
            return
        newly_good = 0
        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None:
                return
            for email in company.emails:
                payload = results.get(email.id)
                if not payload:
                    continue
                was_good = email.status in (EmailStatus.VERIFIED.value, EmailStatus.VALID.value)
                email.status = payload.get("status", EmailStatus.UNKNOWN.value)
                email.verification_provider = payload.get("provider")
                email.verified_at = utcnow()
                email.syntax_ok = payload.get("syntax_ok")
                email.mx_found = payload.get("mx_found")
                email.mx_host = payload.get("mx_host")
                email.smtp_accepted = payload.get("smtp_accepted")
                email.is_catch_all = payload.get("is_catch_all")
                if payload.get("is_role") is not None:
                    email.is_role_account = bool(payload["is_role"])
                if payload.get("is_disposable") is not None:
                    email.is_disposable = bool(payload["is_disposable"])
                if payload.get("is_free") is not None:
                    email.is_free_provider = bool(payload["is_free"])
                email.validation_detail = payload.get("detail") or {}
                email.confidence = max(email.confidence, float(payload.get("confidence") or 0.5))
                is_good = email.status in (EmailStatus.VERIFIED.value, EmailStatus.VALID.value)
                if is_good and not was_good:
                    newly_good += 1
            best = company.best_email
            if best:
                await record_source(session, company, "email_status", best.status,
                                    SourceType.VERIFICATION_PROVIDER.value,
                                    provider=best.verification_provider,
                                    confidence=best.confidence)
        if newly_good:
            await self._bump(emails_verified_or_valid=newly_good)

    # ---------------------------------------------- STEP 8: firmographics
    async def _step8_firmographics(self, session: AsyncSession, company: Company,
                                   profile: SiteProfile) -> None:
        home = profile.pages_by_kind.get("home", profile.base_url)

        if profile.description and not company.business_description:
            company.business_description = profile.description[:4000]
            await record_source(session, company, "business_description",
                                company.business_description[:200],
                                SourceType.WEBSITE_ABOUT_PAGE.value,
                                source_url=profile.description_source or home,
                                provider="website_scrape", confidence=0.8)

        if profile.founded_year and not company.founded_year:
            company.founded_year = profile.founded_year
            await record_source(session, company, "founded_year", profile.founded_year,
                                SourceType.WEBSITE_ABOUT_PAGE.value,
                                source_url=profile.founded_source or home,
                                provider="website_scrape", confidence=0.75)

        if profile.employee_hint and not company.employee_count:
            company.employee_count = profile.employee_hint
            company.employee_range = employee_range(profile.employee_hint)
            await record_source(session, company, "employee_count", profile.employee_hint,
                                SourceType.WEBSITE_ABOUT_PAGE.value,
                                source_url=profile.employee_hint_source or home,
                                provider="website_scrape", confidence=0.6,
                                is_estimate=True)

        if profile.locations_hint and not company.num_locations:
            company.num_locations = profile.locations_hint
            await record_source(session, company, "num_locations", profile.locations_hint,
                                SourceType.WEBSITE_LOCATIONS_PAGE.value,
                                source_url=profile.locations_hint_source or home,
                                provider="website_scrape", confidence=0.6,
                                is_estimate=True)

        if profile.franchise_hint and not company.franchise_status:
            company.franchise_status = profile.franchise_hint
            await record_source(session, company, "franchise_status", profile.franchise_hint,
                                SourceType.WEBSITE_HOMEPAGE.value, source_url=home,
                                provider="website_scrape", confidence=0.5, is_estimate=True)

        for key, attr in (("linkedin", "linkedin_url"), ("facebook", "facebook_url"),
                          ("instagram", "instagram_url"), ("twitter", "twitter_url"),
                          ("youtube", "youtube_url")):
            val = profile.social.get(key)
            if val and not getattr(company, attr):
                setattr(company, attr, val[:512])
                await record_source(session, company, attr, val,
                                    SourceType.WEBSITE_HOMEPAGE.value, source_url=home,
                                    provider="website_scrape", confidence=0.85)

        if not company.phone and profile.phones:
            company.phone = profile.phones[0][:64]
            company.phone_normalized = normalize_phone(company.phone, company.country or "US")
            await record_source(session, company, "phone", company.phone,
                                SourceType.WEBSITE_CONTACT_PAGE.value,
                                source_url=profile.pages_by_kind.get("contact", home),
                                provider="website_scrape", confidence=0.8)

        if profile.addresses and not company.address:
            addr = profile.addresses[0]
            if addr.get("street"):
                company.address = str(addr["street"])[:512]
                company.city = company.city or addr.get("city")
                company.state = company.state or normalize_state(addr.get("state"))
                company.postal_code = company.postal_code or addr.get("postal_code")
                company.address_hash = address_fingerprint(company.address, company.city,
                                                           company.postal_code)
                await record_source(session, company, "address", company.address,
                                    SourceType.WEBSITE_STRUCTURED_DATA.value,
                                    source_url=addr.get("source_url") or home,
                                    provider="website_scrape", confidence=0.85)

        # Industry codes are derived from classification, never claimed as verified.
        if company.industry and (not company.naics or not company.sic):
            ind = find_industry(company.industry) or find_industry(company.name)
            if ind:
                if not company.naics:
                    company.naics = ind.naics
                    await record_source(session, company, "naics", ind.naics,
                                        SourceType.DERIVED.value, provider="taxonomy",
                                        confidence=0.5, is_estimate=True)
                if not company.sic:
                    company.sic = ind.sic
                    await record_source(session, company, "sic", ind.sic,
                                        SourceType.DERIVED.value, provider="taxonomy",
                                        confidence=0.5, is_estimate=True)
                if not company.sub_industry:
                    company.sub_industry = ind.sub_industry

        company.employee_range = company.employee_range or employee_range(company.employee_count)
        company.revenue_range = company.revenue_range or revenue_range(company.estimated_revenue)

    async def _step8b_paid_enrichment(self, company_id: int) -> None:
        providers = registry.enrichment_providers()
        if not providers:
            return
        async with session_scope() as session:
            company = await session.get(Company, company_id)
            if company is None or not company.domain:
                return
            if settings.skip_paid_when_qualified and not is_qualified(company):
                return  # don't pay to enrich something that will never be a lead
            if company.employee_count and company.estimated_revenue and company.founded_year:
                return  # nothing left worth buying
            if not await self._budget_ok(session):
                return
            domain, pk = company.domain, company.id

        for provider in providers:
            async with session_scope(write=False) as session:
                key = make_key(domain)
                cached = await cache_get(session, provider.name, "company_enrich", key)
            if cached is not None:
                payload = cached
                await self._bump(cache_hits=1)
                async with session_scope() as session:
                    await record_call(session, provider.name, "company_enrich",
                                      job_id=self.job_id, company_id=pk, cache_hit=True)
            else:
                try:
                    result = await provider.enrich(domain)
                except Exception as exc:  # noqa: BLE001
                    log.warning("enrichment %s failed for %s: %s", provider.name, domain, exc)
                    continue
                payload = _enrichment_to_dict(result) if result else {}
                async with session_scope() as session:
                    await cache_set(session, provider.name, "company_enrich", key, payload)
                    await record_call(session, provider.name, "company_enrich",
                                      job_id=self.job_id, company_id=pk,
                                      cost_units=provider.cost_units)
            if not payload:
                continue

            async with session_scope() as session:
                company = await session.get(Company, pk)
                if company is None:
                    return
                is_est = bool(payload.get("is_estimate"))
                src_url = payload.get("source_url")
                for field in ("employee_count", "estimated_revenue", "founded_year",
                              "num_locations", "industry", "sub_industry", "naics", "sic",
                              "business_description", "linkedin_url", "facebook_url",
                              "instagram_url", "twitter_url", "address", "city", "state",
                              "postal_code", "country", "phone", "franchise_status"):
                    key_name = "description" if field == "business_description" else field
                    value = payload.get(key_name)
                    if value in (None, "", []):
                        continue
                    if getattr(company, field, None) in (None, "", []):
                        setattr(company, field, value)
                        await record_source(session, company, field, value,
                                            SourceType.ENRICHMENT_PROVIDER.value,
                                            source_url=src_url, provider=provider.name,
                                            confidence=0.8, is_estimate=is_est)
                company.employee_range = employee_range(company.employee_count) or company.employee_range
                company.revenue_range = revenue_range(company.estimated_revenue) or company.revenue_range
            break  # one successful enrichment provider is enough

    # ---------------------------------------------- STEP 9: signals
    async def _step9_signals(self, session: AsyncSession, company: Company,
                             profile: SiteProfile) -> None:
        if not profile.pages:
            return
        existing = {(s.signal_type, s.source_url) for s in company.signals}
        added = 0
        for sig in detect_signals(profile.pages):
            if (sig.signal_type, sig.source_url) in existing:
                continue
            company.signals.append(Signal(
                company_id=company.id, signal_type=sig.signal_type, title=sig.title[:512],
                snippet=sig.snippet, source_url=sig.source_url[:1024],
                source_type=sig.source_type, confidence=sig.confidence,
            ))
            existing.add((sig.signal_type, sig.source_url))
            added += 1
        if added:
            await session.flush()
            await self._bump(signals_found=added)

    # ---------------------------------------------- STEP 10: score
    async def _score_and_store(self, session: AsyncSession, company: Company):
        breakdown = score_company(company)
        company.lead_score = breakdown.total
        company.enrichment_pct = breakdown.enrichment_pct
        company.is_qualified = breakdown.qualified
        notes = dict(company.scrape_notes or {})
        notes["score_breakdown"] = {
            "email": breakdown.email, "contact": breakdown.contact,
            "firmographic": breakdown.firmographic,
            "reachability": breakdown.reachability, "signals": breakdown.signals,
            "reasons": breakdown.reasons,
        }
        company.scrape_notes = notes
        await session.flush()
        return breakdown

    # ---------------------------------------------- bookkeeping
    async def _budget_ok(self, session: AsyncSession) -> bool:
        if not settings.job_paid_call_budget:
            return True
        spent = await job_paid_spend(session, self.job_id)
        return spent < settings.job_paid_call_budget

    async def _relink_job_company(self, session: AsyncSession, old_id: int,
                                  new_id: int) -> None:
        link = (await session.execute(
            select(JobCompany).where(JobCompany.job_id == self.job_id,
                                     JobCompany.company_id == old_id)
        )).scalar_one_or_none()
        if link:
            dup = (await session.execute(
                select(JobCompany).where(JobCompany.job_id == self.job_id,
                                         JobCompany.company_id == new_id)
            )).scalar_one_or_none()
            if dup:
                await session.delete(link)
            else:
                link.company_id = new_id

    async def _set_item_stage(self, session: AsyncSession, company_id: int,
                              stage: str) -> None:
        link = (await session.execute(
            select(JobCompany).where(JobCompany.job_id == self.job_id,
                                     JobCompany.company_id == company_id)
        )).scalar_one_or_none()
        if link:
            link.stage = stage
            link.updated_at = utcnow()

    async def _bump(self, **kwargs) -> None:
        """Increment in-memory counters ONLY.

        This is called from inside open write transactions (e.g. while STEP 5
        holds a session), so it must never open a database session of its own:
        doing so would try to re-acquire the process-wide write lock that the
        caller already holds and deadlock the worker. A background task
        (``_stats_flusher``) persists the counters instead.
        """
        async with self._stats_lock:
            for k, v in kwargs.items():
                self.stats[k] = self.stats.get(k, 0) + v

    async def _flush_stats(self) -> None:
        """Persist the counters. Only ever called outside a write transaction."""
        async with self._stats_lock:
            snapshot = dict(self.stats)
        async with session_scope() as session:
            job = await session.get(Job, self.job_id)
            if job is not None:
                job.stats = snapshot

    async def _stats_flusher(self) -> None:
        try:
            while True:
                await asyncio.sleep(STATS_FLUSH_SECONDS)
                try:
                    await self._flush_stats()
                except Exception:  # noqa: BLE001
                    log.debug("stats flush failed", exc_info=True)
        except asyncio.CancelledError:
            pass

    async def _set_status(self, status: JobStatus, stage: str | None = None) -> None:
        async with session_scope() as session:
            job = await session.get(Job, self.job_id)
            if job is None:
                return
            job.status = status.value
            if stage:
                job.stage = stage
            if status is JobStatus.RUNNING and job.started_at is None:
                job.started_at = utcnow()

    async def _finish(self, status: JobStatus, error: str | None = None) -> None:
        await self._recount()
        async with session_scope() as session:
            job = await session.get(Job, self.job_id)
            if job is None:
                return
            job.status = status.value
            job.finished_at = utcnow()
            job.stage = None
            if error:
                job.error = error
            job.stats = dict(self.stats)

    async def _recount(self) -> None:
        """Recompute the headline metrics directly from the data (authoritative)."""
        async with session_scope(write=False) as session:
            base = select(Company.id).join(
                JobCompany, JobCompany.company_id == Company.id
            ).where(JobCompany.job_id == self.job_id)
            ids = [r for r in (await session.execute(base)).scalars().all()]
            if not ids:
                return
            total = len(ids)

            websites = (await session.execute(
                select(func.count()).select_from(Company).where(
                    Company.id.in_(ids), Company.website.is_not(None),
                    Company.website_status.in_(["live", "redirected"]))
            )).scalar_one()

            from ..models import EmailRecord as ER
            emails_sub = select(ER.company_id).where(ER.company_id.in_(ids)).distinct()
            with_email = len((await session.execute(emails_sub)).scalars().all())

            good_sub = select(ER.company_id).where(
                ER.company_id.in_(ids),
                ER.status.in_([EmailStatus.VERIFIED.value, EmailStatus.VALID.value])
            ).distinct()
            with_good = len((await session.execute(good_sub)).scalars().all())

            qualified = (await session.execute(
                select(func.count()).select_from(Company).where(
                    Company.id.in_(ids), Company.is_qualified.is_(True))
            )).scalar_one()

            dm_sub = select(Contact.company_id).where(
                Contact.company_id.in_(ids), Contact.is_decision_maker.is_(True)
            ).distinct()
            dms = len((await session.execute(dm_sub)).scalars().all())

            self.stats.update({
                "businesses_found": total,
                "websites_found": int(websites),
                "emails_found": int(with_email),
                "emails_verified_or_valid": int(with_good),
                "qualified_leads": int(qualified),
                "decision_makers_found": int(dms),
            })

    async def _check_cancel(self) -> bool:
        """Poll the cancel flag, but not more than once a second per worker."""
        import time
        if self._cancelled:
            return True
        now = time.monotonic()
        if now - self._cancel_checked_at < 1.0:
            return False
        self._cancel_checked_at = now
        async with session_scope(write=False) as session:
            job = await session.get(Job, self.job_id)
            if job is not None and job.cancel_requested:
                self._cancelled = True
        return self._cancelled


# ==========================================================================
# helpers
# ==========================================================================

def _biz_to_values(biz: DiscoveredBusiness) -> dict:
    return {
        "website": biz.website, "phone": biz.phone, "address": biz.address,
        "city": biz.city, "state": normalize_state(biz.state) or biz.state,
        "postal_code": biz.postal_code, "country": biz.country,
        "latitude": biz.latitude, "longitude": biz.longitude,
        "industry": biz.industry, "sub_industry": biz.sub_industry,
        "naics": biz.naics, "sic": biz.sic,
        "employee_count": biz.employee_count, "founded_year": biz.founded_year,
        "business_description": biz.description,
    }


def _email_source_weight(found: FoundEmail, company_domain: str | None) -> float:
    weight = found.confidence
    if company_domain and registrable_domain(found.domain) == company_domain:
        weight += 0.5
    if found.method == "mailto_link":
        weight += 0.3
    if found.method == "structured_data":
        weight += 0.25
    if not is_role_account(found.local_part):
        weight += 0.15
    return weight


def _looks_like_company_contact(found: FoundEmail, profile: SiteProfile) -> bool:
    """A gmail-style address only counts if the site presents it as its contact."""
    ctx = (found.context or "").lower()
    if found.method in ("mailto_link", "structured_data"):
        return True
    return any(word in ctx for word in ("contact", "email us", "reach us", "inquiries",
                                        "questions", "call or email", "estimate"))


def _match_contact(found: FoundEmail, contacts: list[Contact],
                   profile: SiteProfile) -> tuple[Contact | None, bool | None]:
    """Tie a discovered address to a discovered person, purely by matching."""
    if is_role_account(found.local_part):
        return None, None
    for contact in contacts:
        if local_part_matches_person(found.local_part, contact.full_name):
            return contact, contact.is_decision_maker
    # The address may sit right next to the person's name in the page context.
    ctx = found.context or ""
    if ctx:
        for contact in contacts:
            if contact.full_name and contact.full_name.lower() in ctx.lower():
                return contact, contact.is_decision_maker
    return None, None


def _source_type_for_url(url: str | None, profile: SiteProfile) -> str:
    if not url:
        return SourceType.WEBSITE_HOMEPAGE.value
    from .crawler import SOURCE_TYPE_FOR_PAGE
    for kind, page_url in profile.pages_by_kind.items():
        if page_url and page_url.rstrip("/") == url.rstrip("/"):
            return SOURCE_TYPE_FOR_PAGE.get(kind, SourceType.WEBSITE_HOMEPAGE.value)
    for page in profile.pages:
        if page.url.rstrip("/") == url.rstrip("/"):
            return SOURCE_TYPE_FOR_PAGE.get(page.page_kind, SourceType.WEBSITE_HOMEPAGE.value)
    return SourceType.WEBSITE_HOMEPAGE.value


def _provider_email_to_dict(pe) -> dict:
    return {
        "address": pe.address, "email_type": pe.email_type,
        "first_name": pe.first_name, "last_name": pe.last_name,
        "job_title": pe.job_title, "confidence": pe.confidence,
        "status_hint": pe.status_hint, "source_url": pe.source_url,
    }


def _verification_to_dict(res) -> dict:
    return {
        "status": res.status, "provider": res.provider, "syntax_ok": res.syntax_ok,
        "mx_found": res.mx_found, "mx_host": res.mx_host,
        "smtp_accepted": res.smtp_accepted, "is_catch_all": res.is_catch_all,
        "is_role": res.is_role, "is_disposable": res.is_disposable,
        "is_free": res.is_free, "confidence": res.confidence, "detail": res.detail,
    }


def _enrichment_to_dict(res) -> dict:
    if res is None:
        return {}
    return {
        "employee_count": res.employee_count, "estimated_revenue": res.estimated_revenue,
        "founded_year": res.founded_year, "num_locations": res.num_locations,
        "industry": res.industry, "sub_industry": res.sub_industry,
        "naics": res.naics, "sic": res.sic, "description": res.description,
        "linkedin_url": res.linkedin_url, "facebook_url": res.facebook_url,
        "instagram_url": res.instagram_url, "twitter_url": res.twitter_url,
        "address": res.address, "city": res.city, "state": res.state,
        "postal_code": res.postal_code, "country": res.country, "phone": res.phone,
        "franchise_status": res.franchise_status,
        "is_estimate": res.is_estimate, "source_url": res.source_url,
    }


def _profile_to_cache(profile: SiteProfile) -> dict:
    return {
        "base_url": profile.base_url, "domain": profile.domain,
        "reachable": profile.reachable, "status": profile.status,
        "final_url": profile.final_url,
        "pages": [{"url": p.url, "page_kind": p.page_kind, "title": p.title,
                   "text": p.text[:120_000], "meta_description": p.meta_description,
                   "jsonld": p.jsonld[:12]}
                  for p in profile.pages],
        "emails": [{"address": e.address, "local_part": e.local_part, "domain": e.domain,
                    "method": e.method, "source_url": e.source_url,
                    "context": e.context[:400], "confidence": e.confidence}
                   for e in profile.emails],
        "people": [{"full_name": p.full_name, "first_name": p.first_name,
                    "last_name": p.last_name, "job_title": p.job_title,
                    "seniority": p.seniority, "is_decision_maker": p.is_decision_maker,
                    "source_url": p.source_url, "source_type": p.source_type,
                    "confidence": p.confidence, "linkedin_url": p.linkedin_url}
                   for p in profile.people],
        "phones": profile.phones, "social": profile.social,
        "description": profile.description, "description_source": profile.description_source,
        "addresses": profile.addresses, "founded_year": profile.founded_year,
        "founded_source": profile.founded_source,
        "employee_hint": profile.employee_hint,
        "employee_hint_source": profile.employee_hint_source,
        "locations_hint": profile.locations_hint,
        "locations_hint_source": profile.locations_hint_source,
        "franchise_hint": profile.franchise_hint,
        "pages_by_kind": profile.pages_by_kind, "notes": profile.notes,
    }


def _profile_from_cache(data: dict) -> SiteProfile:
    from ..core.email_extract import PageExtract
    from ..core.people_extract import FoundPerson

    profile = SiteProfile(base_url=data.get("base_url", ""), domain=data.get("domain", ""))
    profile.reachable = data.get("reachable", False)
    profile.status = data.get("status", "unchecked")
    profile.final_url = data.get("final_url")
    profile.pages = [PageExtract(url=p["url"], page_kind=p.get("page_kind", "other"),
                                 title=p.get("title", ""), text=p.get("text", ""),
                                 meta_description=p.get("meta_description", ""),
                                 jsonld=p.get("jsonld", []))
                     for p in data.get("pages", [])]
    profile.emails = [FoundEmail(address=e["address"], local_part=e["local_part"],
                                 domain=e["domain"], method=e["method"],
                                 source_url=e.get("source_url", ""),
                                 context=e.get("context", ""),
                                 confidence=e.get("confidence", 0.6))
                      for e in data.get("emails", [])]
    profile.people = [FoundPerson(full_name=p["full_name"], first_name=p.get("first_name"),
                                  last_name=p.get("last_name"), job_title=p.get("job_title"),
                                  seniority=p.get("seniority"),
                                  is_decision_maker=p.get("is_decision_maker", False),
                                  source_url=p.get("source_url", ""),
                                  source_type=p.get("source_type", "website_homepage"),
                                  confidence=p.get("confidence", 0.5),
                                  linkedin_url=p.get("linkedin_url"))
                      for p in data.get("people", [])]
    profile.phones = data.get("phones", [])
    profile.social = data.get("social", {})
    profile.description = data.get("description")
    profile.description_source = data.get("description_source")
    profile.addresses = data.get("addresses", [])
    profile.founded_year = data.get("founded_year")
    profile.founded_source = data.get("founded_source")
    profile.employee_hint = data.get("employee_hint")
    profile.employee_hint_source = data.get("employee_hint_source")
    profile.locations_hint = data.get("locations_hint")
    profile.locations_hint_source = data.get("locations_hint_source")
    profile.franchise_hint = data.get("franchise_hint")
    profile.pages_by_kind = data.get("pages_by_kind", {})
    profile.notes = data.get("notes", {})
    return profile

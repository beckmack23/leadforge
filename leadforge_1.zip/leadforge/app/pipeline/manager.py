"""In-process job manager: runs pipeline jobs as asyncio tasks."""
from __future__ import annotations

import asyncio
import logging

from ..db import session_scope
from ..models import Job, JobStatus
from .orchestrator import JobRunner

log = logging.getLogger(__name__)


class JobManager:
    def __init__(self) -> None:
        self._tasks: dict[int, asyncio.Task] = {}
        self._lock = asyncio.Lock()

    async def start(self, job_id: int) -> bool:
        async with self._lock:
            task = self._tasks.get(job_id)
            if task is not None and not task.done():
                return False
            runner = JobRunner(job_id)
            t = asyncio.create_task(self._run(job_id, runner), name=f"job-{job_id}")
            self._tasks[job_id] = t
            return True

    async def _run(self, job_id: int, runner: JobRunner) -> None:
        try:
            await runner.run()
        except asyncio.CancelledError:
            log.info("job %s cancelled", job_id)
        except Exception:  # noqa: BLE001
            log.exception("job %s crashed", job_id)
        finally:
            async with self._lock:
                self._tasks.pop(job_id, None)

    async def cancel(self, job_id: int) -> bool:
        async with session_scope() as session:
            job = await session.get(Job, job_id)
            if job is None:
                return False
            job.cancel_requested = True
        async with self._lock:
            task = self._tasks.get(job_id)
        if task and not task.done():
            task.cancel()
            return True
        async with session_scope() as session:
            job = await session.get(Job, job_id)
            if job and job.status in (JobStatus.QUEUED.value, JobStatus.RUNNING.value):
                job.status = JobStatus.CANCELLED.value
        return True

    def is_running(self, job_id: int) -> bool:
        t = self._tasks.get(job_id)
        return bool(t and not t.done())

    @property
    def running_ids(self) -> list[int]:
        return [jid for jid, t in self._tasks.items() if not t.done()]

    async def shutdown(self) -> None:
        async with self._lock:
            tasks = list(self._tasks.values())
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def recover_orphans(self) -> int:
        """On startup, mark jobs left RUNNING by a previous process as failed."""
        from sqlalchemy import select
        count = 0
        async with session_scope() as session:
            rows = (await session.execute(
                select(Job).where(Job.status.in_([JobStatus.RUNNING.value,
                                                  JobStatus.QUEUED.value]))
            )).scalars().all()
            for job in rows:
                job.status = JobStatus.FAILED.value
                job.error = "Interrupted by a server restart. Re-run this search to continue."
                count += 1
        return count


manager = JobManager()

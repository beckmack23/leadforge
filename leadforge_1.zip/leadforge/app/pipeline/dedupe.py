"""STEP 3 - deduplication.

Match order (strongest key first):
  1. domain                      - two records on the same website are one company
  2. LinkedIn company URL
  3. normalised phone
  4. address fingerprint + normalised name
  5. normalised name + city/state

When a duplicate is found the incoming record is MERGED into the stored one:
we never lose a field, and the provenance ledger records which source each
surviving value came from.
"""
from __future__ import annotations

import logging

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.normalize import (
    address_fingerprint,
    extract_domain,
    normalize_company_name,
    normalize_phone,
)
from ..models import Company
from ..providers.base import DiscoveredBusiness

log = logging.getLogger(__name__)


async def find_existing(session: AsyncSession, biz: DiscoveredBusiness) -> Company | None:
    domain = extract_domain(biz.website) if biz.website else None
    phone = normalize_phone(biz.phone, biz.country or "US")
    name_norm = normalize_company_name(biz.name)
    addr_hash = address_fingerprint(biz.address, biz.city, biz.postal_code)

    # 1. domain
    if domain:
        row = (await session.execute(
            select(Company).where(Company.domain == domain)
        )).scalars().first()
        if row:
            return row

    # 2. phone (a shared phone number is a strong same-business signal)
    if phone:
        row = (await session.execute(
            select(Company).where(Company.phone_normalized == phone)
        )).scalars().first()
        if row:
            # Guard against shared answering services: require a name or address overlap.
            if (name_norm and row.name_normalized and
                    _name_similar(name_norm, row.name_normalized)) or \
                    (addr_hash and row.address_hash == addr_hash):
                return row

    # 3. address + name
    if addr_hash and name_norm:
        row = (await session.execute(
            select(Company).where(Company.address_hash == addr_hash,
                                  Company.name_normalized == name_norm)
        )).scalars().first()
        if row:
            return row

    # 4. name + city/state
    if name_norm and (biz.city or biz.state):
        conds = [Company.name_normalized == name_norm]
        if biz.city:
            conds.append(or_(Company.city == biz.city, Company.city.is_(None)))
        if biz.state:
            conds.append(or_(Company.state == biz.state, Company.state.is_(None)))
        row = (await session.execute(select(Company).where(*conds))).scalars().first()
        if row:
            return row

    return None


async def find_by_domain(session: AsyncSession, domain: str) -> Company | None:
    if not domain:
        return None
    return (await session.execute(
        select(Company).where(Company.domain == domain)
    )).scalars().first()


async def find_duplicate_of(session: AsyncSession, company: Company) -> Company | None:
    """Called after website resolution, when a domain first becomes known."""
    if not company.domain:
        return None
    row = (await session.execute(
        select(Company).where(Company.domain == company.domain,
                              Company.id != company.id)
        .order_by(Company.id)
    )).scalars().first()
    return row


def _name_similar(a: str, b: str) -> bool:
    if a == b:
        return True
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return False
    overlap = len(ta & tb) / min(len(ta), len(tb))
    return overlap >= 0.6


MERGEABLE_SCALARS = [
    "website", "phone", "address", "city", "state", "postal_code", "country",
    "latitude", "longitude", "industry", "sub_industry", "naics", "sic",
    "employee_count", "employee_range", "estimated_revenue", "revenue_range",
    "founded_year", "num_locations", "franchise_status", "business_description",
    "linkedin_url", "facebook_url", "instagram_url", "twitter_url", "youtube_url",
]


def merge_into(target: Company, source_values: dict) -> list[str]:
    """Fill blanks on ``target`` from ``source_values``. Returns fields changed."""
    changed = []
    for key in MERGEABLE_SCALARS:
        if key not in source_values:
            continue
        new = source_values[key]
        if new in (None, "", []):
            continue
        if getattr(target, key, None) in (None, "", []):
            setattr(target, key, new)
            changed.append(key)
    return changed


async def merge_companies(session: AsyncSession, keep: Company, drop: Company) -> None:
    """Fold ``drop`` into ``keep`` and delete it."""
    payload = {k: getattr(drop, k) for k in MERGEABLE_SCALARS}
    merge_into(keep, payload)

    existing_addresses = {e.address for e in keep.emails}
    for email in list(drop.emails):
        if email.address in existing_addresses:
            continue
        email.company_id = keep.id
        email.contact_id = None
        keep.emails.append(email)
        existing_addresses.add(email.address)

    existing_names = {c.full_name.lower() for c in keep.contacts}
    for contact in list(drop.contacts):
        if contact.full_name.lower() in existing_names:
            continue
        contact.company_id = keep.id
        keep.contacts.append(contact)
        existing_names.add(contact.full_name.lower())

    existing_signals = {(s.signal_type, s.source_url) for s in keep.signals}
    for sig in list(drop.signals):
        if (sig.signal_type, sig.source_url) in existing_signals:
            continue
        sig.company_id = keep.id
        keep.signals.append(sig)

    existing_fields = {f.field for f in keep.sources}
    for src in list(drop.sources):
        if src.field in existing_fields:
            continue
        src.company_id = keep.id
        keep.sources.append(src)

    merged_ids = dict(keep.external_ids or {})
    merged_ids.update(drop.external_ids or {})
    keep.external_ids = merged_ids

    await session.delete(drop)
    await session.flush()

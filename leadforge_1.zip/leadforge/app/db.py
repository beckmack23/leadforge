"""Async database engine / session management."""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from .config import settings
from .core import aiolocks
from .models import Base

log = logging.getLogger(__name__)

def _apply_sqlite_pragmas(dbapi_conn, _record):  # pragma: no cover - driver hook
    """WAL + long busy timeout: essential for concurrent worker writes on SQLite."""
    try:
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA busy_timeout=30000")
        cur.execute("PRAGMA cache_size=-64000")
        cur.close()
    except Exception:  # non-sqlite backends
        pass


def make_engine(url: str | None = None):
    """Create an engine for either SQLite or Postgres.

    SQLite gets the WAL/busy-timeout pragmas attached; without them concurrent
    workers hit "database is locked". Postgres gets a real connection pool.
    Tests and alternate entry points must use this rather than
    ``create_async_engine`` directly.
    """
    target = url or settings.effective_database_url
    if target.startswith("postgresql"):
        return create_async_engine(
            target, echo=False, future=True, pool_pre_ping=True,
            pool_size=10, max_overflow=10, pool_recycle=1800,
        )
    eng = create_async_engine(target, echo=False, future=True, pool_pre_ping=True)
    event.listens_for(eng.sync_engine, "connect")(_apply_sqlite_pragmas)
    return eng


engine = make_engine()
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

# SQLite allows exactly one writer at a time. Serialising our own write
# transactions in-process turns lock contention into a short await instead of
# an OperationalError, which matters at worker_concurrency > 1. The lock is
# resolved per running event loop (see core.aiolocks) so it never ends up bound
# to a loop that has since been replaced.
def _write_lock() -> asyncio.Lock:
    return aiolocks.lock("sqlite_write")


def _safe_url(url: str) -> str:
    """Redact the password before a connection string reaches the logs."""
    import re
    return re.sub(r"://([^:/@]+):[^@]*@", r"://\1:***@", url)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    log.info("database ready: %s", _safe_url(settings.effective_database_url))


async def get_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency."""
    async with SessionLocal() as session:
        yield session


@asynccontextmanager
async def session_scope(write: bool = True) -> AsyncIterator[AsyncSession]:
    """Transactional scope for worker code.

    Write scopes are serialised process-wide (see ``_write_lock``) because
    SQLite permits a single writer; readers are unrestricted under WAL.
    """
    # Postgres handles concurrent writers itself; the process-wide lock is only
    # needed for SQLite, which permits a single writer at a time.
    if write and not settings.is_postgres:
        async with _write_lock():
            async with SessionLocal() as session:
                try:
                    yield session
                    await session.commit()
                except Exception:
                    await session.rollback()
                    raise
        return
    async with SessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def healthcheck() -> bool:
    try:
        async with SessionLocal() as s:
            await s.execute(text("SELECT 1"))
        return True
    except Exception:
        return False

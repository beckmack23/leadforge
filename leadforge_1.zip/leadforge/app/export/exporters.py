"""CSV / XLSX / JSON export with named presets."""
from __future__ import annotations

import csv
import io
import json
from datetime import datetime

from ..models import Company

# (column key, header label, accessor)
ALL_COLUMNS: list[tuple[str, str]] = [
    ("lead_score", "Lead Score"),
    ("is_qualified", "Qualified"),
    ("enrichment_pct", "Enrichment %"),
    ("name", "Company"),
    ("website", "Website"),
    ("website_source", "Website Source"),
    ("email", "Email"),
    ("email_type", "Email Type"),
    ("email_status", "Email Status"),
    ("email_source", "Email Source"),
    ("email_verification_provider", "Verification Provider"),
    ("email_verified_at", "Verification Date"),
    ("email_confidence", "Email Confidence"),
    ("general_business_email", "General Business Email"),
    ("direct_email", "Direct Email"),
    ("first_name", "First Name"),
    ("last_name", "Last Name"),
    ("contact_name", "Contact Name"),
    ("job_title", "Job Title"),
    ("is_decision_maker", "Decision Maker"),
    ("contact_source", "Contact Source"),
    ("phone", "Phone"),
    ("industry", "Industry"),
    ("sub_industry", "Sub-industry"),
    ("naics", "NAICS"),
    ("sic", "SIC"),
    ("employee_count", "Employee Count"),
    ("employee_range", "Employee Range"),
    ("estimated_revenue", "Estimated Revenue"),
    ("revenue_range", "Revenue Range"),
    ("founded_year", "Founded Year"),
    ("num_locations", "Number of Locations"),
    ("franchise_status", "Franchise Status"),
    ("address", "Address"),
    ("city", "City"),
    ("state", "State"),
    ("postal_code", "ZIP"),
    ("country", "Country"),
    ("linkedin_url", "LinkedIn Company URL"),
    ("contact_linkedin", "LinkedIn Decision Maker URL"),
    ("facebook_url", "Facebook"),
    ("instagram_url", "Instagram"),
    ("business_description", "Business Description"),
    ("signals", "Business Signals"),
    ("discovery_provider", "Discovery Source"),
    ("last_enriched_at", "Last Enriched"),
]

PRESETS: dict[str, list[str]] = {
    "outbound_leads": [
        "first_name", "last_name", "name", "website", "email", "email_status",
        "phone", "industry", "employee_count", "estimated_revenue", "city",
        "state", "linkedin_url", "lead_score",
    ],
    "full": [key for key, _ in ALL_COLUMNS],
}

HEADERS = dict(ALL_COLUMNS)
# The "Outbound Leads" preset uses friendlier labels for two shared columns.
PRESET_HEADER_OVERRIDES = {
    # Exactly the header row the "Outbound Leads" preset is specified to produce.
    "outbound_leads": {
        "name": "Company",
        "linkedin_url": "LinkedIn",
        "employee_count": "Employees",
        "estimated_revenue": "Revenue",
    },
}


def row_for(company: Company) -> dict:
    best = company.best_email
    contact = company.primary_contact
    dm = next((c for c in company.contacts if c.is_decision_maker), None)
    general = next((e for e in sorted(company.emails, key=lambda x: x.priority_key)
                    if e.email_type == "general_business" and e.is_usable), None)
    direct = next((e for e in sorted(company.emails, key=lambda x: x.priority_key)
                   if e.email_type in ("decision_maker", "employee") and e.is_usable), None)
    website_src = next((s.source_url for s in company.sources if s.field == "website"), None)

    return {
        "lead_score": company.lead_score,
        "is_qualified": "YES" if company.is_qualified else "NO",
        "enrichment_pct": company.enrichment_pct,
        "name": company.name,
        "website": company.website or "",
        "website_source": website_src or company.website_final_url or "",
        "email": best.address if best else "",
        "email_type": best.email_type if best else "",
        "email_status": best.status if best else "",
        "email_source": (best.source_url or best.source_type) if best else "",
        "email_verification_provider": best.verification_provider if best else "",
        "email_verified_at": _dt(best.verified_at) if best else "",
        "email_confidence": best.confidence if best else "",
        "general_business_email": general.address if general else "",
        "direct_email": direct.address if direct else "",
        "first_name": (dm or contact).first_name if (dm or contact) else "",
        "last_name": (dm or contact).last_name if (dm or contact) else "",
        "contact_name": (dm or contact).full_name if (dm or contact) else "",
        "job_title": (dm or contact).job_title if (dm or contact) else "",
        "is_decision_maker": "YES" if dm else ("NO" if contact else ""),
        "contact_source": (dm or contact).source_url if (dm or contact) else "",
        "phone": company.phone or "",
        "industry": company.industry or "",
        "sub_industry": company.sub_industry or "",
        "naics": company.naics or "",
        "sic": company.sic or "",
        "employee_count": company.employee_count if company.employee_count is not None else "",
        "employee_range": company.employee_range or "",
        "estimated_revenue": company.estimated_revenue
        if company.estimated_revenue is not None else "",
        "revenue_range": company.revenue_range or "",
        "founded_year": company.founded_year if company.founded_year is not None else "",
        "num_locations": company.num_locations if company.num_locations is not None else "",
        "franchise_status": company.franchise_status or "",
        "address": company.address or "",
        "city": company.city or "",
        "state": company.state or "",
        "postal_code": company.postal_code or "",
        "country": company.country or "",
        "linkedin_url": company.linkedin_url or "",
        "contact_linkedin": (dm or contact).linkedin_url if (dm or contact) else "",
        "facebook_url": company.facebook_url or "",
        "instagram_url": company.instagram_url or "",
        "business_description": (company.business_description or "")[:1000],
        "signals": "; ".join(f"{s.signal_type} ({s.source_url})" for s in company.signals),
        "discovery_provider": company.discovery_provider or "",
        "last_enriched_at": _dt(company.last_enriched_at),
    }


def resolve_columns(preset: str, columns: list[str] | None) -> list[str]:
    if preset == "custom" and columns:
        return [c for c in columns if c in HEADERS]
    return PRESETS.get(preset, PRESETS["outbound_leads"])


def header_for(preset: str, key: str) -> str:
    return PRESET_HEADER_OVERRIDES.get(preset, {}).get(key, HEADERS.get(key, key))


def to_csv(companies: list[Company], preset: str = "outbound_leads",
           columns: list[str] | None = None) -> bytes:
    cols = resolve_columns(preset, columns)
    buf = io.StringIO()
    writer = csv.writer(buf, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
    writer.writerow([header_for(preset, c) for c in cols])
    for company in companies:
        row = row_for(company)
        writer.writerow([row.get(c, "") for c in cols])
    return buf.getvalue().encode("utf-8-sig")


def to_json(companies: list[Company], preset: str = "full",
            columns: list[str] | None = None) -> bytes:
    cols = resolve_columns(preset, columns)
    payload = {
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "preset": preset,
        "count": len(companies),
        "qualification_rule": "QUALIFIED LEAD = valid website + business email",
        "leads": [],
    }
    for company in companies:
        row = row_for(company)
        item = {c: row.get(c) for c in cols}
        item["sources"] = [
            {"field": s.field, "value": s.value, "source_type": s.source_type,
             "source_url": s.source_url, "provider": s.provider,
             "confidence": s.confidence, "is_estimate": s.is_estimate}
            for s in company.sources
        ]
        item["emails"] = [
            {"address": e.address, "type": e.email_type, "status": e.status,
             "discovery_method": e.discovery_method, "source_url": e.source_url,
             "verification_provider": e.verification_provider,
             "verified_at": _dt(e.verified_at), "confidence": e.confidence}
            for e in sorted(company.emails, key=lambda x: x.priority_key)
        ]
        item["contacts"] = [
            {"full_name": c.full_name, "job_title": c.job_title,
             "seniority": c.seniority, "is_decision_maker": c.is_decision_maker,
             "linkedin_url": c.linkedin_url, "source_url": c.source_url}
            for c in company.contacts
        ]
        item["signals"] = [
            {"type": s.signal_type, "title": s.title, "snippet": s.snippet,
             "source_url": s.source_url, "confidence": s.confidence}
            for s in company.signals
        ]
        payload["leads"].append(item)
    return json.dumps(payload, indent=2, default=str).encode("utf-8")


def to_xlsx(companies: list[Company], preset: str = "outbound_leads",
            columns: list[str] | None = None) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    cols = resolve_columns(preset, columns)
    wb = Workbook()
    ws = wb.active
    ws.title = "Leads"

    header_fill = PatternFill("solid", fgColor="1F2937")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    for idx, key in enumerate(cols, start=1):
        cell = ws.cell(row=1, column=idx, value=header_for(preset, key))
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(vertical="center")
    ws.freeze_panes = "A2"

    numeric = {"lead_score", "enrichment_pct", "employee_count", "estimated_revenue",
               "founded_year", "num_locations", "email_confidence"}

    for r, company in enumerate(companies, start=2):
        row = row_for(company)
        for c, key in enumerate(cols, start=1):
            value = row.get(key, "")
            if key in numeric and value not in ("", None):
                try:
                    value = float(value) if key in {"enrichment_pct", "estimated_revenue",
                                                    "email_confidence"} else int(value)
                except (TypeError, ValueError):
                    pass
            cell = ws.cell(row=r, column=c, value=value)
            if key == "estimated_revenue" and isinstance(value, (int, float)):
                cell.number_format = '"$"#,##0'
            elif key == "website" and value:
                cell.hyperlink = value
                cell.style = "Hyperlink"
            elif key == "email" and value:
                cell.hyperlink = f"mailto:{value}"
                cell.style = "Hyperlink"

    widths = {"name": 34, "website": 32, "email": 30, "business_description": 60,
              "signals": 50, "address": 30, "job_title": 24, "contact_name": 22,
              "linkedin_url": 34, "contact_linkedin": 34, "email_source": 40,
              "website_source": 34, "contact_source": 34, "industry": 20}
    for idx, key in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = widths.get(key, 16)

    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{max(1, len(companies) + 1)}"

    # A second sheet documenting where each value came from.
    src = wb.create_sheet("Sources")
    src.append(["Company", "Field", "Value", "Source Type", "Source URL",
                "Provider", "Confidence", "Estimate?"])
    for cell in src[1]:
        cell.fill = header_fill
        cell.font = header_font
    for company in companies:
        for s in company.sources:
            src.append([company.name, s.field, (s.value or "")[:300], s.source_type,
                        s.source_url or "", s.provider or "", s.confidence,
                        "YES" if s.is_estimate else "NO"])
    for idx, width in enumerate([28, 20, 40, 24, 46, 18, 12, 10], start=1):
        src.column_dimensions[get_column_letter(idx)].width = width
    src.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _dt(value) -> str:
    if not value:
        return ""
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


EXPORTERS = {"csv": to_csv, "xlsx": to_xlsx, "json": to_json}
CONTENT_TYPES = {
    "csv": "text/csv; charset=utf-8",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "json": "application/json",
}

/* LeadForge UI — vanilla JS, no build step. */
(() => {
"use strict";

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };

const STATE = {
  meta: null,
  liveJobId: null,
  pollTimer: null,
  page: { limit: 50, offset: 0, total: 0 },
  sort: { key: "lead_score", dir: "desc" },
};

const US_STATES = {AL:"Alabama",AK:"Alaska",AZ:"Arizona",AR:"Arkansas",CA:"California",CO:"Colorado",CT:"Connecticut",DE:"Delaware",DC:"District of Columbia",FL:"Florida",GA:"Georgia",HI:"Hawaii",ID:"Idaho",IL:"Illinois",IN:"Indiana",IA:"Iowa",KS:"Kansas",KY:"Kentucky",LA:"Louisiana",ME:"Maine",MD:"Maryland",MA:"Massachusetts",MI:"Michigan",MN:"Minnesota",MS:"Mississippi",MO:"Missouri",MT:"Montana",NE:"Nebraska",NV:"Nevada",NH:"New Hampshire",NJ:"New Jersey",NM:"New Mexico",NY:"New York",NC:"North Carolina",ND:"North Dakota",OH:"Ohio",OK:"Oklahoma",OR:"Oregon",PA:"Pennsylvania",RI:"Rhode Island",SC:"South Carolina",SD:"South Dakota",TN:"Tennessee",TX:"Texas",UT:"Utah",VT:"Vermont",VA:"Virginia",WA:"Washington",WV:"West Virginia",WI:"Wisconsin",WY:"Wyoming",PR:"Puerto Rico"};

/* ---------------- helpers ---------------- */
async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...opts });
  if (!res.ok) {
    let msg = `${res.status} ${res.statusText}`;
    try { const j = await res.json(); msg = j.detail || JSON.stringify(j); } catch {}
    throw new Error(msg);
  }
  return res.status === 204 ? null : res.json();
}

function toast(msg, ms = 3200) {
  const t = $("toast");
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, ms);
}

const nf = new Intl.NumberFormat("en-US");
const num = (v) => (v == null || v === "" ? "—" : nf.format(v));
function money(v) {
  if (v == null || v === "") return "—";
  const n = Number(v);
  if (n >= 1e9) return "$" + (n / 1e9).toFixed(n % 1e9 === 0 ? 0 : 1) + "B";
  if (n >= 1e6) return "$" + (n / 1e6).toFixed(n % 1e6 === 0 ? 0 : 1) + "M";
  if (n >= 1e3) return "$" + Math.round(n / 1e3) + "K";
  return "$" + nf.format(Math.round(n));
}
function parseMoneyInput(s) {
  if (!s) return null;
  const m = String(s).trim().toLowerCase().replace(/[$,\s]/g, "").match(/^([\d.]+)(k|m|mm|b)?$/);
  if (!m) return null;
  const mult = { undefined: 1, k: 1e3, m: 1e6, mm: 1e6, b: 1e9 }[m[2]];
  return parseFloat(m[1]) * (mult || 1);
}
const dateShort = (s) => (s ? new Date(s).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "—");
const dateFull = (s) => (s ? new Date(s).toLocaleString() : "—");
const titleCase = (s) => (s || "").replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return u; } };

function badge(kind, label) {
  const b = el("span", `badge ${kind}`, label ?? titleCase(kind));
  return b;
}
function link(href, text, cls) {
  if (!href) return el("span", cls, text || "—");
  const a = el("a", cls, text || href);
  a.href = href; a.target = "_blank"; a.rel = "noopener noreferrer";
  return a;
}

/* ---------------- tabs ---------------- */
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
    tab.classList.add("active");
    $("view-" + tab.dataset.view).classList.add("active");
    if (tab.dataset.view === "leads") loadLeads();
    if (tab.dataset.view === "jobs") loadJobs();
  });
});

/* ---------------- bootstrap ---------------- */
async function boot() {
  try { STATE.meta = await api("/api/meta"); }
  catch (e) { toast("Could not reach the API: " + e.message, 8000); return; }

  const industrySelects = [$("f_industry"), $("lf_industry")];
  STATE.meta.industries.forEach((i) => {
    industrySelects.forEach((sel, idx) => {
      const o = el("option", null, i.name);
      o.value = idx === 0 ? i.key : i.name;
      o.dataset.sub = i.sub_industry; o.dataset.naics = i.naics; o.dataset.sic = i.sic;
      sel.appendChild(o);
    });
  });
  Object.entries(US_STATES).forEach(([abbr, name]) => {
    [$("f_state"), $("lf_state")].forEach((sel) => {
      const o = el("option", null, `${name} (${abbr})`);
      o.value = abbr; sel.appendChild(o);
    });
  });

  $("f_industry").addEventListener("change", (e) => {
    const opt = e.target.selectedOptions[0];
    if (opt && opt.dataset.sub) {
      $("f_sub_industry").value = opt.dataset.sub;
      $("f_naics").value = opt.dataset.naics || "";
      $("f_sic").value = opt.dataset.sic || "";
    }
  });

  const statusWrap = $("lf_email_status");
  STATE.meta.email_statuses.forEach((s) => {
    const l = el("label"); const c = document.createElement("input");
    c.type = "checkbox"; c.value = s; c.className = "email-status-check";
    l.append(c, document.createTextNode(" " + titleCase(s)));
    statusWrap.appendChild(l);
  });
  const typeWrap = $("lf_email_type");
  STATE.meta.email_types.forEach((s) => {
    const l = el("label"); const c = document.createElement("input");
    c.type = "checkbox"; c.value = s; c.className = "email-type-check";
    l.append(c, document.createTextNode(" " + titleCase(s)));
    typeWrap.appendChild(l);
  });

  renderProviders();
  loadJobs();
}

/* ---------------- providers ---------------- */
function renderProviders() {
  const body = $("providerBody");
  body.innerHTML = "";
  STATE.meta.providers.forEach((p) => {
    const tr = el("tr");
    tr.style.cursor = "default";
    tr.append(
      el("td", null, titleCase(p.kind)),
      el("td", null, p.name),
      el("td", null, titleCase(p.cost_tier)),
      (() => { const td = el("td"); td.appendChild(badge(p.available ? "verified" : "unknown", p.available ? "Active" : "Needs key")); return td; })(),
      el("td", "mono", (p.requires_keys || []).join(", ") || "—"),
      el("td", null, p.description || "")
    );
    body.appendChild(tr);
  });

  const notes = $("capabilityNotes");
  notes.innerHTML = "";
  (STATE.meta.capabilities.notes || []).forEach((n) => notes.appendChild(el("div", "note", n)));
}

/* ---------------- search ---------------- */
$("toggleAdvanced").addEventListener("click", () => {
  const g = $("advancedGrid");
  g.hidden = !g.hidden;
  $("toggleAdvanced").textContent = g.hidden ? "Show all filters" : "Hide extra filters";
});

document.querySelectorAll(".chip").forEach((c) =>
  c.addEventListener("click", () => { $("nlInput").value = c.dataset.q; parseNL(); })
);
$("nlParse").addEventListener("click", parseNL);
$("nlInput").addEventListener("keydown", (e) => { if (e.key === "Enter") parseNL(); });

async function parseNL() {
  const text = $("nlInput").value.trim();
  if (!text) return;
  try {
    const r = await api("/api/parse", {
      method: "POST",
      body: JSON.stringify({ text, target_count: parseInt($("f_target").value) || 500 }),
    });
    const box = $("interpretation");
    box.textContent = r.interpretation;
    box.hidden = false;
    fillForm(r.criteria);
    const m = r.interpretation.match(/up to ([\d,]+)/);
    if (m) $("f_target").value = m[1].replace(/,/g, "");
  } catch (e) { toast("Could not interpret: " + e.message); }
}

function fillForm(c) {
  const set = (id, v) => { const n = $(id); if (n) n.value = v == null ? "" : v; };
  set("f_industry", c.industry || "");
  set("f_sub_industry", c.sub_industry);
  set("f_keywords", (c.keywords || []).join(", "));
  set("f_naics", c.naics); set("f_sic", c.sic);
  set("f_city", c.city); set("f_state", c.state || ""); set("f_postal_code", c.postal_code);
  set("f_country", c.country || "US"); set("f_radius_miles", c.radius_miles);
  set("f_employee_min", c.employee_min); set("f_employee_max", c.employee_max);
  set("f_revenue_min", c.revenue_min); set("f_revenue_max", c.revenue_max);
  set("f_founded_year_min", c.founded_year_min); set("f_founded_year_max", c.founded_year_max);
  set("f_locations_min", c.locations_min);
  $("f_franchise_status").value = c.franchise_status || "any";
  if (c.employee_min || c.revenue_min || c.founded_year_min || c.naics) $("advancedGrid").hidden = false;
}

function collectCriteria() {
  const v = (id) => { const n = $(id); const s = n ? n.value.trim() : ""; return s === "" ? null : s; };
  const n = (id) => { const s = v(id); return s == null ? null : Number(s); };
  return {
    industry: v("f_industry"),
    sub_industry: v("f_sub_industry"),
    keywords: (v("f_keywords") || "").split(",").map((s) => s.trim()).filter(Boolean),
    naics: v("f_naics"), sic: v("f_sic"),
    city: v("f_city"), state: v("f_state"), postal_code: v("f_postal_code"),
    country: v("f_country") || "US",
    radius_miles: n("f_radius_miles"),
    employee_min: n("f_employee_min"), employee_max: n("f_employee_max"),
    revenue_min: parseMoneyInput(v("f_revenue_min")),
    revenue_max: parseMoneyInput(v("f_revenue_max")),
    founded_year_min: n("f_founded_year_min"), founded_year_max: n("f_founded_year_max"),
    locations_min: n("f_locations_min"),
    franchise_status: $("f_franchise_status").value,
  };
}

$("runSearch").addEventListener("click", async () => {
  $("searchError").hidden = true;
  const criteria = collectCriteria();
  const target = parseInt($("f_target").value) || 500;
  $("runSearch").disabled = true;
  try {
    const job = await api("/api/jobs", {
      method: "POST",
      body: JSON.stringify({ criteria, target_count: target, query_text: $("nlInput").value.trim() || null }),
    });
    toast(`Job #${job.id} started`);
    watchJob(job.id, job.name);
    loadJobs();
  } catch (e) {
    const p = $("searchError"); p.textContent = e.message; p.hidden = false;
  } finally { $("runSearch").disabled = false; }
});

$("importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  try {
    const res = await fetch("/api/import", { method: "POST", body: fd });
    if (!res.ok) throw new Error((await res.json()).detail || res.statusText);
    const job = await res.json();
    toast(`Importing ${file.name} as job #${job.id}`);
    watchJob(job.id, job.name);
  } catch (err) { toast("Import failed: " + err.message, 6000); }
  finally { e.target.value = ""; }
});

/* ---------------- live job ---------------- */
function watchJob(id, name) {
  STATE.liveJobId = id;
  $("liveJobPanel").hidden = false;
  $("liveJobName").textContent = name || `Job #${id}`;
  $("liveJobPanel").scrollIntoView({ behavior: "smooth", block: "nearest" });
  clearInterval(STATE.pollTimer);
  pollJob();
  STATE.pollTimer = setInterval(pollJob, 2500);
}

$("cancelJob").addEventListener("click", async () => {
  if (!STATE.liveJobId) return;
  try { await api(`/api/jobs/${STATE.liveJobId}/cancel`, { method: "POST" }); toast("Cancelling…"); }
  catch (e) { toast(e.message); }
});

const METRIC_ORDER = [
  ["businesses_found", "Businesses Found", false],
  ["websites_found", "Websites Found", false],
  ["emails_found", "Emails Found", false],
  ["verified_or_valid_emails", "Verified/Valid Emails", false],
  ["qualified_leads", "Qualified Leads", true],
  ["decision_makers_found", "Decision Makers Found", false],
];

async function pollJob() {
  if (!STATE.liveJobId) return;
  let p;
  try { p = await api(`/api/jobs/${STATE.liveJobId}/progress`); }
  catch { return; }

  const status = $("liveJobStatus");
  status.textContent = titleCase(p.status) + (p.stage ? ` · ${titleCase(p.stage)}` : "");
  status.className = "pill " + p.status;

  $("progressBar").style.width = (p.progress.pct || 0) + "%";
  $("progressText").textContent =
    `${nf.format(p.progress.processed)} of ${nf.format(p.progress.total)} businesses processed (${p.progress.pct}%)` +
    (p.error ? ` — ${p.error}` : "");

  const box = $("liveMetrics");
  box.innerHTML = "";
  METRIC_ORDER.forEach(([key, label, isKey]) => {
    const d = el("div", "metric" + (isKey ? " key" : ""));
    d.append(el("div", "v", nf.format(p.metrics[key] || 0)), el("div", "k", label));
    box.appendChild(d);
  });

  const sub = $("liveSubMetrics");
  sub.innerHTML = "";
  Object.entries(p.internal).forEach(([k, v]) => {
    const s = el("span");
    s.append(document.createTextNode(titleCase(k) + ": "), el("b", null, nf.format(v)));
    sub.appendChild(s);
  });

  if (["completed", "failed", "cancelled"].includes(p.status)) {
    clearInterval(STATE.pollTimer);
    STATE.pollTimer = null;
    toast(`Job #${p.job_id} ${p.status}: ${nf.format(p.metrics.qualified_leads)} qualified leads`);
    loadJobs();
  }
}

/* ---------------- jobs list ---------------- */
$("refreshJobs").addEventListener("click", loadJobs);

async function loadJobs() {
  let jobs;
  try { jobs = await api("/api/jobs?limit=50"); } catch { return; }

  const sel = $("lf_job");
  const cur = sel.value;
  sel.innerHTML = '<option value="">All jobs</option>';
  jobs.forEach((j) => { const o = el("option", null, `#${j.id} — ${j.name}`); o.value = j.id; sel.appendChild(o); });
  sel.value = cur;

  const body = $("jobBody");
  body.innerHTML = "";
  jobs.forEach((j) => {
    const s = j.stats || {};
    const tr = el("tr");
    const statusTd = el("td");
    statusTd.appendChild((() => { const p = el("span", "pill " + j.status, titleCase(j.status)); return p; })());
    const actionTd = el("td");
    const view = el("button", "btn ghost small", "Leads");
    view.addEventListener("click", (ev) => {
      ev.stopPropagation();
      document.querySelector('.tab[data-view="leads"]').click();
      $("lf_job").value = j.id;
      STATE.page.offset = 0;
      loadLeads();
    });
    const watch = el("button", "btn ghost small", "Watch");
    watch.style.marginLeft = "6px";
    watch.addEventListener("click", (ev) => {
      ev.stopPropagation();
      document.querySelector('.tab[data-view="search"]').click();
      watchJob(j.id, j.name);
    });
    actionTd.append(view, watch);
    tr.append(
      el("td", null, "#" + j.id),
      el("td", null, j.name),
      statusTd,
      el("td", "num", num(s.businesses_found)),
      el("td", "num", num(s.websites_found)),
      el("td", "num", num(s.emails_found)),
      el("td", "num", num(s.qualified_leads)),
      el("td", null, dateShort(j.created_at)),
      actionTd
    );
    tr.style.cursor = "default";
    body.appendChild(tr);
  });
}

/* ---------------- leads ---------------- */
function leadFilterParams() {
  const p = new URLSearchParams();
  const add = (k, v) => { if (v !== null && v !== undefined && v !== "") p.append(k, v); };
  add("job_id", $("lf_job").value);
  add("q", $("lf_q").value.trim());
  add("industry", $("lf_industry").value);
  add("state", $("lf_state").value);
  add("city", $("lf_city").value.trim());
  add("employee_min", $("lf_employee_min").value);
  add("employee_max", $("lf_employee_max").value);
  add("revenue_min", parseMoneyInput($("lf_revenue_min").value));
  add("revenue_max", parseMoneyInput($("lf_revenue_max").value));
  add("score_min", $("lf_score_min").value);
  add("enrichment_min", $("lf_enrichment_min").value);
  document.querySelectorAll(".email-status-check:checked").forEach((c) => p.append("email_status", c.value));
  document.querySelectorAll(".email-type-check:checked").forEach((c) => p.append("email_type", c.value));
  p.append("qualified_only", $("lf_qualified").checked);
  if ($("lf_dm").checked) p.append("has_decision_maker", "true");
  if ($("lf_contact").checked) p.append("has_contact", "true");
  p.append("sort", STATE.sort.key);
  p.append("direction", STATE.sort.dir);
  p.append("limit", STATE.page.limit);
  p.append("offset", STATE.page.offset);
  return p;
}

function currentFilterObject() {
  const p = leadFilterParams();
  const o = {};
  for (const [k, v] of p.entries()) {
    if (k === "email_status" || k === "email_type") { (o[k] ||= []).push(v); }
    else if (["qualified_only", "has_decision_maker", "has_contact"].includes(k)) o[k] = v === "true";
    else if (["limit", "offset", "sort", "direction"].includes(k)) o[k] = k === "sort" || k === "direction" ? v : Number(v);
    else o[k] = isNaN(Number(v)) ? v : Number(v);
  }
  o.email_status ||= []; o.email_type ||= [];
  return o;
}

async function loadLeads() {
  let data;
  try { data = await api("/api/leads?" + leadFilterParams().toString()); }
  catch (e) { toast("Load failed: " + e.message); return; }

  STATE.page.total = data.total;
  $("leadCount").textContent = nf.format(data.total);
  const body = $("leadBody");
  body.innerHTML = "";
  $("leadEmpty").hidden = data.items.length > 0;

  data.items.forEach((L) => {
    const tr = el("tr");
    tr.addEventListener("click", () => openDrawer(L.id));

    const scoreTd = el("td", "num");
    const cls = L.lead_score >= 70 ? "s-high" : L.lead_score >= 40 ? "s-mid" : "s-low";
    scoreTd.appendChild(el("span", "score " + cls, String(L.lead_score)));

    const siteTd = el("td");
    siteTd.appendChild(link(L.website, hostOf(L.website || ""), "truncate"));

    const emailTd = el("td");
    if (L.primary_email) {
      const wrap = el("span");
      wrap.appendChild(link("mailto:" + L.primary_email, L.primary_email, "truncate"));
      wrap.appendChild(document.createTextNode(" "));
      wrap.appendChild(badge(L.primary_email_type, L.primary_email_type === "decision_maker" ? "DM" : L.primary_email_type === "employee" ? "EMP" : "GEN"));
      emailTd.appendChild(wrap);
    } else emailTd.textContent = "—";

    const statusTd = el("td");
    if (L.primary_email_status) statusTd.appendChild(badge(L.primary_email_status));
    else statusTd.textContent = "—";

    const enrichTd = el("td", "num");
    const bar = el("div", "bar"); const i = el("i"); i.style.width = (L.enrichment_pct || 0) + "%";
    bar.appendChild(i);
    const w = el("div"); w.style.display = "flex"; w.style.alignItems = "center"; w.style.gap = "6px"; w.style.justifyContent = "flex-end";
    w.append(el("span", null, Math.round(L.enrichment_pct || 0) + "%"), bar);
    enrichTd.appendChild(w);

    tr.append(
      scoreTd,
      (() => { const td = el("td"); td.appendChild(el("span", "truncate", L.name)); return td; })(),
      siteTd, emailTd, statusTd,
      el("td", null, L.contact_name || "—"),
      (() => { const td = el("td"); td.appendChild(el("span", "truncate", L.contact_title || "—")); return td; })(),
      el("td", null, L.phone || "—"),
      el("td", null, L.industry || "—"),
      el("td", "num", num(L.employee_count)),
      el("td", "num", money(L.estimated_revenue)),
      el("td", null, L.city || "—"),
      el("td", null, L.state || "—"),
      enrichTd,
      el("td", null, L.discovery_provider || "—"),
      el("td", null, dateShort(L.last_enriched_at))
    );
    body.appendChild(tr);
  });

  const from = data.total ? STATE.page.offset + 1 : 0;
  const to = Math.min(STATE.page.offset + STATE.page.limit, data.total);
  $("pageInfo").textContent = `${nf.format(from)}–${nf.format(to)} of ${nf.format(data.total)}`;
  $("prevPage").disabled = STATE.page.offset === 0;
  $("nextPage").disabled = to >= data.total;
}

document.querySelectorAll("#leadTable th.sortable").forEach((th) => {
  th.addEventListener("click", () => {
    const key = th.dataset.sort;
    STATE.sort = { key, dir: STATE.sort.key === key && STATE.sort.dir === "desc" ? "asc" : "desc" };
    document.querySelectorAll("#leadTable th").forEach((h) => h.classList.remove("sorted", "asc"));
    th.classList.add("sorted");
    if (STATE.sort.dir === "asc") th.classList.add("asc");
    STATE.page.offset = 0;
    loadLeads();
  });
});

$("applyFilters").addEventListener("click", () => { STATE.page.offset = 0; loadLeads(); });
$("lf_q").addEventListener("keydown", (e) => { if (e.key === "Enter") { STATE.page.offset = 0; loadLeads(); } });
["lf_job", "lf_industry", "lf_state"].forEach((id) => $(id).addEventListener("change", () => { STATE.page.offset = 0; loadLeads(); }));
$("resetFilters").addEventListener("click", () => {
  ["lf_q", "lf_city", "lf_employee_min", "lf_employee_max", "lf_revenue_min", "lf_revenue_max", "lf_score_min", "lf_enrichment_min"].forEach((id) => ($(id).value = ""));
  ["lf_job", "lf_industry", "lf_state"].forEach((id) => ($(id).value = ""));
  document.querySelectorAll(".email-status-check, .email-type-check").forEach((c) => (c.checked = false));
  $("lf_qualified").checked = true; $("lf_dm").checked = false; $("lf_contact").checked = false;
  STATE.page.offset = 0; loadLeads();
});
$("prevPage").addEventListener("click", () => { STATE.page.offset = Math.max(0, STATE.page.offset - STATE.page.limit); loadLeads(); });
$("nextPage").addEventListener("click", () => { STATE.page.offset += STATE.page.limit; loadLeads(); });

/* ---------------- export ---------------- */
$("exportBtn").addEventListener("click", async () => {
  const fmt = $("exportFormat").value;
  const preset = $("exportPreset").value;
  $("exportBtn").disabled = true;
  try {
    const res = await fetch("/api/export", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ format: fmt, preset, filters: currentFilterObject() }),
    });
    if (!res.ok) throw new Error(await res.text());
    const rows = res.headers.get("X-Row-Count");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = (res.headers.get("Content-Disposition") || "").match(/filename="([^"]+)"/)?.[1] || `leads.${fmt}`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast(`Exported ${nf.format(rows || 0)} leads`);
  } catch (e) { toast("Export failed: " + e.message, 6000); }
  finally { $("exportBtn").disabled = false; }
});

/* ---------------- drawer ---------------- */
$("closeDrawer").addEventListener("click", closeDrawer);
$("scrim").addEventListener("click", closeDrawer);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });
function closeDrawer() { $("drawer").hidden = true; $("scrim").hidden = true; }

async function openDrawer(id) {
  let L, score;
  try {
    [L, score] = await Promise.all([api(`/api/leads/${id}`), api(`/api/leads/${id}/score`)]);
  } catch (e) { toast(e.message); return; }

  $("d_name").textContent = L.name;
  $("d_sub").textContent = [L.industry, L.sub_industry, [L.city, L.state].filter(Boolean).join(", ")].filter(Boolean).join(" · ");

  const body = $("drawerBody");
  body.innerHTML = "";
  const sourceByField = Object.fromEntries((L.sources || []).map((s) => [s.field, s]));

  /* qualification banner */
  const banner = el("div", "note");
  banner.style.background = L.is_qualified ? "var(--good-soft)" : "var(--bad-soft)";
  banner.style.color = L.is_qualified ? "var(--good)" : "var(--bad)";
  banner.textContent = L.is_qualified
    ? `QUALIFIED — has a live website and a business email. Lead score ${L.lead_score}/100.`
    : `NOT QUALIFIED — ${!L.website || !["live", "redirected"].includes(L.website_status) ? "no valid website" : "no usable business email"}. Everything below is enrichment.`;
  body.appendChild(banner);

  /* score */
  const sSec = el("div", "d-section");
  sSec.appendChild(el("h4", null, `Lead score — ${score.total}/100`));
  const sGrid = el("div", "score-grid");
  Object.entries(score.components).forEach(([k, v]) => {
    const c = el("div", "score-cell");
    c.append(el("div", "n", `${v.points}/${v.max}`), el("div", "l", titleCase(k)));
    sGrid.appendChild(c);
  });
  sSec.appendChild(sGrid);
  if (score.reasons?.length) sSec.appendChild(el("p", "hint", score.reasons.join(" · ")));
  body.appendChild(sSec);

  /* emails */
  const eSec = el("div", "d-section");
  eSec.appendChild(el("h4", null, `Emails (${L.emails.length})`));
  if (!L.emails.length) eSec.appendChild(el("p", "muted", "No email discovered. This lead cannot qualify until one is found — and none will be guessed."));
  L.emails.forEach((e) => {
    const card = el("div", "card");
    const row = el("div", "row1");
    row.append(el("strong", null, e.address), badge(e.email_type), badge(e.status));
    if (e.is_role_account) row.appendChild(badge("general_business", "role"));
    if (e.is_free_provider) row.appendChild(badge("est", "consumer domain"));
    if (e.is_disposable) row.appendChild(badge("invalid", "disposable"));
    if (e.is_catch_all) row.appendChild(badge("catch_all", "catch-all"));
    card.appendChild(row);

    const meta = el("div", "meta");
    meta.textContent = `How found: ${titleCase(e.discovery_method)} · Confidence ${Math.round(e.confidence * 100)}%`;
    card.appendChild(meta);

    const v = el("div", "meta");
    v.textContent = `Verification: ${e.verification_provider || "not verified"}${e.verified_at ? " on " + dateFull(e.verified_at) : ""}`;
    card.appendChild(v);

    if (e.validation_detail?.note) card.appendChild(el("div", "snippet", e.validation_detail.note));
    if (e.source_url) { const s = el("div", "src"); s.append(document.createTextNode("Source: "), link(e.source_url, e.source_url)); card.appendChild(s); }
    else card.appendChild(el("div", "src", "Source: " + titleCase(e.source_type)));
    eSec.appendChild(card);
  });
  body.appendChild(eSec);

  /* contacts */
  const cSec = el("div", "d-section");
  cSec.appendChild(el("h4", null, `Contacts (${L.contacts.length})`));
  if (!L.contacts.length) cSec.appendChild(el("p", "muted", "No named contact found on the public site."));
  L.contacts.forEach((c) => {
    const card = el("div", "card");
    const row = el("div", "row1");
    row.append(el("strong", null, c.full_name));
    if (c.job_title) row.appendChild(el("span", "muted", c.job_title));
    if (c.is_decision_maker) row.appendChild(badge("decision_maker", "Decision maker"));
    if (c.linkedin_url) row.appendChild(link(c.linkedin_url, "LinkedIn"));
    card.appendChild(row);
    card.appendChild(el("div", "meta", `Seniority: ${titleCase(c.seniority || "unknown")} · Confidence ${Math.round(c.confidence * 100)}%`));
    if (c.source_url) { const s = el("div", "src"); s.append(document.createTextNode("Source: "), link(c.source_url, c.source_url)); card.appendChild(s); }
    cSec.appendChild(card);
  });
  body.appendChild(cSec);

  /* firmographics with sources */
  const fSec = el("div", "d-section");
  fSec.appendChild(el("h4", null, "Company data"));
  const dl = el("dl", "kv");
  const rows = [
    ["Website", L.website ? link(L.website, L.website) : "—", "website"],
    ["Website status", titleCase(L.website_status), null],
    ["Phone", L.phone || "—", "phone"],
    ["Address", [L.address, L.city, L.state, L.postal_code, L.country].filter(Boolean).join(", ") || "—", "address"],
    ["Industry", L.industry || "—", "industry"],
    ["Sub-industry", L.sub_industry || "—", null],
    ["NAICS", L.naics || "—", "naics"],
    ["SIC", L.sic || "—", "sic"],
    ["Employees", L.employee_count != null ? `${num(L.employee_count)} (${L.employee_range || "—"})` : (L.employee_range || "—"), "employee_count"],
    ["Estimated revenue", L.estimated_revenue != null ? `${money(L.estimated_revenue)} (${L.revenue_range || "—"})` : (L.revenue_range || "—"), "estimated_revenue"],
    ["Founded", L.founded_year || "—", "founded_year"],
    ["Locations", L.num_locations || "—", "num_locations"],
    ["Franchise status", titleCase(L.franchise_status || "unknown"), "franchise_status"],
    ["LinkedIn", L.linkedin_url ? link(L.linkedin_url, L.linkedin_url) : "—", "linkedin_url"],
    ["Facebook", L.facebook_url ? link(L.facebook_url, L.facebook_url) : "—", "facebook_url"],
    ["Instagram", L.instagram_url ? link(L.instagram_url, L.instagram_url) : "—", "instagram_url"],
    ["Discovered via", L.discovery_provider || "—", null],
    ["Last enriched", dateFull(L.last_enriched_at), null],
  ];
  rows.forEach(([k, v, field]) => {
    dl.appendChild(el("dt", null, k));
    const dd = el("dd");
    if (v instanceof Node) dd.appendChild(v); else dd.textContent = v;
    const src = field && sourceByField[field];
    if (src) {
      const s = el("div", "src");
      s.appendChild(document.createTextNode("via " + titleCase(src.source_type) + (src.provider ? ` (${src.provider})` : "") + " "));
      if (src.source_url) s.appendChild(link(src.source_url, "source"));
      if (src.is_estimate) { s.appendChild(document.createTextNode(" ")); s.appendChild(badge("est", "estimate")); }
      dd.appendChild(s);
    }
    dl.appendChild(dd);
  });
  fSec.appendChild(dl);
  if (L.business_description) {
    fSec.appendChild(el("h4", null, "Description"));
    fSec.appendChild(el("p", "muted", L.business_description));
  }
  body.appendChild(fSec);

  /* signals */
  const gSec = el("div", "d-section");
  gSec.appendChild(el("h4", null, `Business signals (${L.signals.length})`));
  if (!L.signals.length) gSec.appendChild(el("p", "muted", "No public growth or hiring signals detected."));
  L.signals.forEach((s) => {
    const card = el("div", "card");
    const row = el("div", "row1");
    row.append(el("strong", null, titleCase(s.signal_type)), el("span", "muted", s.title));
    row.appendChild(badge("valid", Math.round(s.confidence * 100) + "%"));
    card.appendChild(row);
    if (s.snippet) card.appendChild(el("div", "snippet", "“" + s.snippet + "”"));
    const src = el("div", "src");
    src.append(document.createTextNode("Source: "), link(s.source_url, s.source_url));
    card.appendChild(src);
    gSec.appendChild(card);
  });
  body.appendChild(gSec);

  $("drawer").hidden = false;
  $("scrim").hidden = false;
  body.scrollTop = 0;
}

boot();
})();

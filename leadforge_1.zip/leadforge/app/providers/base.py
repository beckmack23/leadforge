"""Provider abstractions.

Every external data source implements one of these interfaces. Providers declare
a ``cost_tier`` so the pipeline can exhaust free/public sources before spending
paid credits, and an ``is_available`` flag driven purely by configuration - so
the whole app runs with zero API keys.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any


class CostTier(IntEnum):
    FREE = 0        # public data, no credits (OSM, the company's own website)
    CHEAP = 1       # metered but inexpensive (search APIs)
    PAID = 2        # per-record credits (Hunter, ZeroBounce, ...)
    PREMIUM = 3     # expensive per-record (Apollo/PDL full enrichment)


@dataclass
class DiscoveredBusiness:
    """Raw output of STEP 1. Deliberately loose - validation happens later."""
    name: str
    website: str | None = None
    phone: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str = "US"
    latitude: float | None = None
    longitude: float | None = None
    industry: str | None = None
    sub_industry: str | None = None
    naics: str | None = None
    sic: str | None = None
    description: str | None = None
    employee_count: int | None = None
    founded_year: int | None = None
    external_id: str | None = None
    provider: str = ""
    source_url: str | None = None
    extra: dict = field(default_factory=dict)


@dataclass
class ProviderEmail:
    address: str
    email_type: str | None = None          # decision_maker | employee | general_business
    first_name: str | None = None
    last_name: str | None = None
    job_title: str | None = None
    confidence: float = 0.5
    status_hint: str | None = None
    source_url: str | None = None
    provider: str = ""


@dataclass
class VerificationResult:
    address: str
    status: str                             # models.EmailStatus value
    provider: str
    syntax_ok: bool | None = None
    mx_found: bool | None = None
    mx_host: str | None = None
    smtp_accepted: bool | None = None
    is_catch_all: bool | None = None
    is_role: bool | None = None
    is_disposable: bool | None = None
    is_free: bool | None = None
    confidence: float = 0.5
    detail: dict = field(default_factory=dict)


@dataclass
class CompanyEnrichment:
    employee_count: int | None = None
    estimated_revenue: float | None = None
    founded_year: int | None = None
    num_locations: int | None = None
    industry: str | None = None
    sub_industry: str | None = None
    naics: str | None = None
    sic: str | None = None
    description: str | None = None
    linkedin_url: str | None = None
    facebook_url: str | None = None
    instagram_url: str | None = None
    twitter_url: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    phone: str | None = None
    franchise_status: str | None = None
    provider: str = ""
    is_estimate: bool = False
    source_url: str | None = None
    raw: dict = field(default_factory=dict)


class Provider(abc.ABC):
    name: str = "base"
    cost_tier: CostTier = CostTier.FREE
    cost_units: float = 0.0          # credits consumed per successful call
    description: str = ""
    docs_url: str = ""
    requires_keys: tuple[str, ...] = ()

    @property
    def is_available(self) -> bool:
        """True when this provider is configured and usable."""
        return True

    def info(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "cost_tier": self.cost_tier.name.lower(),
            "cost_units": self.cost_units,
            "available": self.is_available,
            "description": self.description,
            "docs_url": self.docs_url,
            "requires_keys": list(self.requires_keys),
        }

    kind: str = "generic"


class DiscoveryProvider(Provider):
    kind = "discovery"

    @abc.abstractmethod
    async def search(self, criteria: "SearchCriteria", limit: int) -> list[DiscoveredBusiness]:
        ...


class EmailFinderProvider(Provider):
    kind = "email_finder"

    @abc.abstractmethod
    async def find(self, domain: str, company_name: str | None = None,
                   people: list[dict] | None = None) -> list[ProviderEmail]:
        ...


class EmailVerifyProvider(Provider):
    kind = "email_verify"

    @abc.abstractmethod
    async def verify(self, address: str) -> VerificationResult:
        ...


class EnrichmentProvider(Provider):
    kind = "enrichment"

    @abc.abstractmethod
    async def enrich(self, domain: str, company_name: str | None = None) -> CompanyEnrichment | None:
        ...


# Imported late to avoid a circular import at module load.
from ..schemas import SearchCriteria  # noqa: E402  isort:skip

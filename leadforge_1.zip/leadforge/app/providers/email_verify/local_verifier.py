"""FREE email verification: syntax + MX + policy checks, optional SMTP probe.

Honesty rules baked in:
  * Without an SMTP probe (or a commercial verifier) we can never prove a
    mailbox exists, so the best status we return is VALID, never VERIFIED.
  * A catch-all domain always downgrades to CATCH_ALL - the address is
    unprovable there by definition.
  * Disposable domains and no-MX domains are flagged, not silently accepted.
"""
from __future__ import annotations

import asyncio
import logging
import re
import socket
from email.utils import parseaddr

import dns.asyncresolver
import dns.exception

from ...config import settings
from ...core import aiolocks
from ...core.email_extract import (
    is_disposable_domain,
    is_free_provider,
    is_role_account,
)
from ...models import EmailStatus
from ..base import CostTier, EmailVerifyProvider, VerificationResult

log = logging.getLogger(__name__)

SYNTAX_RE = re.compile(
    r"^[A-Za-z0-9!#$%&'*+/=?^_`{|}~\-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~\-]+)*"
    r"@(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$"
)

_MX_CACHE: dict[str, tuple[bool, str | None]] = {}
_CATCHALL_CACHE: dict[str, bool | None] = {}


class LocalVerifier(EmailVerifyProvider):
    name = "local_mx"
    cost_tier = CostTier.FREE
    cost_units = 0.0
    description = ("Built-in verifier: RFC syntax, MX lookup, disposable/role/free-provider "
                   "detection, and (optionally) an SMTP RCPT probe with catch-all detection. "
                   "Returns 'valid' rather than 'verified' when the mailbox cannot be proven.")

    @property
    def is_available(self) -> bool:
        return True

    async def verify(self, address: str) -> VerificationResult:
        address = (address or "").strip().lower()
        _, parsed = parseaddr(address)
        detail: dict = {"checks": []}

        syntax_ok = bool(parsed) and bool(SYNTAX_RE.match(parsed)) and len(parsed) <= 254
        if not syntax_ok:
            return VerificationResult(
                address=address, status=EmailStatus.INVALID.value, provider=self.name,
                syntax_ok=False, confidence=0.95,
                detail={"reason": "syntax_failed", "checks": ["syntax"]},
            )
        detail["checks"].append("syntax")

        local_part, domain = parsed.rsplit("@", 1)
        is_role = is_role_account(local_part)
        is_disp = is_disposable_domain(domain)
        is_free = is_free_provider(domain)
        detail.update({"local_part": local_part, "domain": domain})

        mx_found, mx_host = await self._mx_lookup(domain)
        detail["checks"].append("mx")
        detail["mx_host"] = mx_host

        if not mx_found:
            return VerificationResult(
                address=parsed, status=EmailStatus.INVALID.value, provider=self.name,
                syntax_ok=True, mx_found=False, is_role=is_role,
                is_disposable=is_disp, is_free=is_free, confidence=0.85,
                detail={**detail, "reason": "no_mx_records"},
            )

        if is_disp:
            return VerificationResult(
                address=parsed, status=EmailStatus.RISKY.value, provider=self.name,
                syntax_ok=True, mx_found=True, mx_host=mx_host, is_role=is_role,
                is_disposable=True, is_free=is_free, confidence=0.8,
                detail={**detail, "reason": "disposable_domain"},
            )

        # ---- optional SMTP probe ----
        smtp_accepted: bool | None = None
        catch_all: bool | None = None
        if settings.smtp_probe_enabled:
            detail["checks"].append("smtp")
            catch_all = await self._is_catch_all(domain, mx_host)
            detail["catch_all_probe"] = catch_all
            if catch_all is True:
                return VerificationResult(
                    address=parsed, status=EmailStatus.CATCH_ALL.value, provider=self.name,
                    syntax_ok=True, mx_found=True, mx_host=mx_host, is_catch_all=True,
                    is_role=is_role, is_disposable=False, is_free=is_free, confidence=0.6,
                    detail={**detail, "reason": "domain_accepts_all_recipients"},
                )
            smtp_accepted, smtp_note = await self._rcpt_probe(parsed, mx_host)
            detail["smtp_note"] = smtp_note
            if smtp_accepted is True:
                return VerificationResult(
                    address=parsed, status=EmailStatus.VERIFIED.value, provider=self.name,
                    syntax_ok=True, mx_found=True, mx_host=mx_host, smtp_accepted=True,
                    is_catch_all=False, is_role=is_role, is_disposable=False,
                    is_free=is_free, confidence=0.92, detail=detail,
                )
            if smtp_accepted is False:
                return VerificationResult(
                    address=parsed, status=EmailStatus.INVALID.value, provider=self.name,
                    syntax_ok=True, mx_found=True, mx_host=mx_host, smtp_accepted=False,
                    is_role=is_role, is_disposable=False, is_free=is_free, confidence=0.85,
                    detail={**detail, "reason": "mailbox_rejected"},
                )
            # None -> greylisted / blocked / timeout: fall through to VALID.

        status = EmailStatus.VALID.value
        confidence = 0.7
        if is_role:
            # Role mailboxes are legitimate business contacts and stay usable,
            # but the mailbox owner is unknown, so confidence is lower.
            confidence = 0.65
        if is_free:
            confidence = 0.55
            detail["note"] = "free consumer mailbox provider, not a company domain"

        return VerificationResult(
            address=parsed, status=status, provider=self.name, syntax_ok=True,
            mx_found=True, mx_host=mx_host, smtp_accepted=smtp_accepted,
            is_catch_all=catch_all, is_role=is_role, is_disposable=False,
            is_free=is_free, confidence=confidence,
            detail={**detail,
                    "note": detail.get("note",
                                       "syntax + MX confirmed; mailbox existence not "
                                       "individually proven (no SMTP probe / verifier)")},
        )

    # ------------------------------------------------------------------
    async def _mx_lookup(self, domain: str) -> tuple[bool, str | None]:
        if domain in _MX_CACHE:
            return _MX_CACHE[domain]
        resolver = dns.asyncresolver.Resolver()
        resolver.lifetime = 6.0
        resolver.timeout = 3.0
        try:
            answers = await resolver.resolve(domain, "MX")
            hosts = sorted(((r.preference, str(r.exchange).rstrip(".")) for r in answers),
                           key=lambda x: x[0])
            hosts = [h for _, h in hosts if h and h != "."]
            if hosts:
                _MX_CACHE[domain] = (True, hosts[0])
                return _MX_CACHE[domain]
        except (dns.exception.DNSException, Exception):  # noqa: BLE001
            pass
        # RFC 5321: an A record makes the domain a valid implicit mail target.
        try:
            await resolver.resolve(domain, "A")
            _MX_CACHE[domain] = (True, domain)
            return _MX_CACHE[domain]
        except Exception:  # noqa: BLE001
            _MX_CACHE[domain] = (False, None)
            return _MX_CACHE[domain]

    async def _is_catch_all(self, domain: str, mx_host: str | None) -> bool | None:
        if domain in _CATCHALL_CACHE:
            return _CATCHALL_CACHE[domain]
        probe = f"lf-probe-{abs(hash(domain)) % 10**10}-nx@{domain}"
        accepted, _ = await self._rcpt_probe(probe, mx_host)
        _CATCHALL_CACHE[domain] = accepted if accepted is not None else None
        return _CATCHALL_CACHE[domain]

    async def _rcpt_probe(self, address: str, mx_host: str | None) -> tuple[bool | None, str]:
        """SMTP RCPT TO probe. Returns (accepted|None, note). Never sends mail."""
        if not mx_host:
            return None, "no_mx_host"
        async with aiolocks.semaphore("smtp_probe", 4):
            try:
                return await asyncio.wait_for(
                    asyncio.to_thread(_blocking_rcpt, mx_host, address),
                    timeout=settings.smtp_probe_timeout + 4,
                )
            except asyncio.TimeoutError:
                return None, "timeout"
            except Exception as exc:  # noqa: BLE001
                return None, f"error:{type(exc).__name__}"


def _blocking_rcpt(mx_host: str, address: str) -> tuple[bool | None, str]:
    import smtplib

    try:
        server = smtplib.SMTP(timeout=settings.smtp_probe_timeout)
        server.connect(mx_host, 25)
        server.helo(settings.smtp_probe_helo)
        server.mail(settings.smtp_probe_from)
        code, msg = server.rcpt(address)
        try:
            server.quit()
        except Exception:
            pass
        text = msg.decode("utf-8", "replace") if isinstance(msg, bytes) else str(msg)
        if code in (250, 251):
            return True, f"{code} {text[:120]}"
        if code in (550, 551, 553, 554):
            return False, f"{code} {text[:120]}"
        return None, f"{code} {text[:120]}"          # 4xx greylisting etc.
    except (socket.timeout, TimeoutError):
        return None, "socket_timeout"
    except (ConnectionRefusedError, OSError) as exc:
        return None, f"connect_failed:{exc.__class__.__name__}"
    except Exception as exc:  # noqa: BLE001
        return None, f"smtp_error:{type(exc).__name__}"

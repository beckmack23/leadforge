"""Commercial email verification adapters.

Each activates only when its API key is configured. All of them map the
provider's native result onto our six-value status vocabulary and preserve the
raw response in ``detail`` for auditing.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from ...config import settings
from ...core.http import get_client
from ...models import EmailStatus
from ..base import CostTier, EmailVerifyProvider, VerificationResult

log = logging.getLogger(__name__)


class ZeroBounceVerifier(EmailVerifyProvider):
    name = "zerobounce"
    cost_tier = CostTier.PAID
    cost_units = 1.0
    description = "ZeroBounce single email validation."
    docs_url = "https://www.zerobounce.net/docs/email-validation-api-quickstart/"
    requires_keys = ("ZEROBOUNCE_API_KEY",)

    STATUS_MAP = {
        "valid": EmailStatus.VERIFIED,
        "invalid": EmailStatus.INVALID,
        "catch-all": EmailStatus.CATCH_ALL,
        "spamtrap": EmailStatus.INVALID,
        "abuse": EmailStatus.RISKY,
        "do_not_mail": EmailStatus.RISKY,
        "unknown": EmailStatus.UNKNOWN,
    }

    @property
    def is_available(self) -> bool:
        return bool(settings.zerobounce_api_key)

    async def verify(self, address: str) -> VerificationResult:
        status_code, data = await get_client().get_json(
            "https://api.zerobounce.net/v2/validate",
            params={"api_key": settings.zerobounce_api_key, "email": address,
                    "ip_address": ""},
        )
        if status_code != 200 or not isinstance(data, dict):
            return VerificationResult(address, EmailStatus.UNKNOWN.value, self.name,
                                      confidence=0.3, detail={"http": status_code})
        raw = (data.get("status") or "unknown").lower()
        mapped = self.STATUS_MAP.get(raw, EmailStatus.UNKNOWN)
        sub = (data.get("sub_status") or "").lower()
        if mapped is EmailStatus.VERIFIED and sub in {"role_based", "role_based_catch_all"}:
            mapped = EmailStatus.VALID
        return VerificationResult(
            address=address, status=mapped.value, provider=self.name,
            mx_found=bool(data.get("mx_found") in (True, "true")),
            mx_host=data.get("mx_record"),
            is_free=bool(data.get("free_email") in (True, "true")),
            is_role=sub.startswith("role"),
            is_catch_all=(mapped is EmailStatus.CATCH_ALL),
            confidence=0.95 if mapped in (EmailStatus.VERIFIED, EmailStatus.INVALID) else 0.6,
            detail={"provider_status": raw, "sub_status": sub, "raw": data},
        )


class NeverBounceVerifier(EmailVerifyProvider):
    name = "neverbounce"
    cost_tier = CostTier.PAID
    cost_units = 1.0
    description = "NeverBounce single email verification."
    docs_url = "https://developers.neverbounce.com/reference/single-check"
    requires_keys = ("NEVERBOUNCE_API_KEY",)

    STATUS_MAP = {
        "valid": EmailStatus.VERIFIED,
        "invalid": EmailStatus.INVALID,
        "disposable": EmailStatus.RISKY,
        "catchall": EmailStatus.CATCH_ALL,
        "unknown": EmailStatus.UNKNOWN,
    }

    @property
    def is_available(self) -> bool:
        return bool(settings.neverbounce_api_key)

    async def verify(self, address: str) -> VerificationResult:
        status_code, data = await get_client().get_json(
            "https://api.neverbounce.com/v4/single/check",
            params={"key": settings.neverbounce_api_key, "email": address,
                    "address_info": 1, "credits_info": 0},
        )
        if status_code != 200 or not isinstance(data, dict):
            return VerificationResult(address, EmailStatus.UNKNOWN.value, self.name,
                                      confidence=0.3, detail={"http": status_code})
        raw = (data.get("result") or "unknown").lower()
        mapped = self.STATUS_MAP.get(raw, EmailStatus.UNKNOWN)
        flags = data.get("flags") or []
        return VerificationResult(
            address=address, status=mapped.value, provider=self.name,
            is_role="role_account" in flags,
            is_free="free_email_host" in flags,
            is_disposable="disposable_email" in flags,
            is_catch_all=(mapped is EmailStatus.CATCH_ALL),
            confidence=0.95 if mapped in (EmailStatus.VERIFIED, EmailStatus.INVALID) else 0.6,
            detail={"provider_status": raw, "flags": flags, "raw": data},
        )


class MillionVerifierVerifier(EmailVerifyProvider):
    name = "millionverifier"
    cost_tier = CostTier.PAID
    cost_units = 1.0
    description = "MillionVerifier single email verification."
    docs_url = "https://developer.millionverifier.com/"
    requires_keys = ("MILLIONVERIFIER_API_KEY",)

    STATUS_MAP = {
        "ok": EmailStatus.VERIFIED,
        "good": EmailStatus.VERIFIED,
        "invalid": EmailStatus.INVALID,
        "bad": EmailStatus.INVALID,
        "catch_all": EmailStatus.CATCH_ALL,
        "catchall": EmailStatus.CATCH_ALL,
        "unknown": EmailStatus.UNKNOWN,
        "disposable": EmailStatus.RISKY,
        "risky": EmailStatus.RISKY,
    }

    @property
    def is_available(self) -> bool:
        return bool(settings.millionverifier_api_key)

    async def verify(self, address: str) -> VerificationResult:
        status_code, data = await get_client().get_json(
            "https://api.millionverifier.com/api/v3/",
            params={"api": settings.millionverifier_api_key, "email": address, "timeout": 20},
        )
        if status_code != 200 or not isinstance(data, dict):
            return VerificationResult(address, EmailStatus.UNKNOWN.value, self.name,
                                      confidence=0.3, detail={"http": status_code})
        raw = (data.get("result") or data.get("resultcode") or "unknown")
        raw = str(raw).lower()
        mapped = self.STATUS_MAP.get(raw, EmailStatus.UNKNOWN)
        return VerificationResult(
            address=address, status=mapped.value, provider=self.name,
            is_role=bool(data.get("role")),
            is_free=bool(data.get("free")),
            is_catch_all=(mapped is EmailStatus.CATCH_ALL),
            confidence=0.95 if mapped in (EmailStatus.VERIFIED, EmailStatus.INVALID) else 0.6,
            detail={"provider_status": raw, "raw": data},
        )


def verified_at_now() -> datetime:
    return datetime.now(timezone.utc)

"""Provider registry.

The registry is what makes cost optimisation work: every consumer asks for
providers *in cost order*, so free/public sources are always exhausted before a
paid credit is spent.
"""
from __future__ import annotations

from functools import lru_cache

from .base import (
    CostTier,
    DiscoveryProvider,
    EmailFinderProvider,
    EmailVerifyProvider,
    EnrichmentProvider,
    Provider,
)
from .discovery.csv_import import CsvImportDiscovery
from .discovery.google_places import GooglePlacesDiscovery
from .discovery.overpass import OverpassDiscovery
from .discovery.yelp import YelpDiscovery
from .email_finder.commercial import ApolloFinder, HunterFinder, SnovFinder
from .email_verify.commercial import (
    MillionVerifierVerifier,
    NeverBounceVerifier,
    ZeroBounceVerifier,
)
from .email_verify.local_verifier import LocalVerifier
from .enrichment.commercial import ClearbitEnrichment, PeopleDataLabsEnrichment


@lru_cache
def _all() -> list[Provider]:
    return [
        # discovery
        OverpassDiscovery(),
        GooglePlacesDiscovery(),
        YelpDiscovery(),
        CsvImportDiscovery(),
        # email finding (website crawling is built into the pipeline, tier FREE)
        HunterFinder(),
        SnovFinder(),
        ApolloFinder(),
        # verification
        LocalVerifier(),
        ZeroBounceVerifier(),
        NeverBounceVerifier(),
        MillionVerifierVerifier(),
        # enrichment
        ClearbitEnrichment(),
        PeopleDataLabsEnrichment(),
    ]


def _of_kind(cls) -> list:
    return sorted(
        [p for p in _all() if isinstance(p, cls) and p.is_available],
        key=lambda p: (int(p.cost_tier), p.cost_units, p.name),
    )


def discovery_providers(include_import: bool = False) -> list[DiscoveryProvider]:
    out = _of_kind(DiscoveryProvider)
    if not include_import:
        out = [p for p in out if p.name != "user_import"]
    return out


def email_finders() -> list[EmailFinderProvider]:
    return _of_kind(EmailFinderProvider)


def email_verifiers() -> list[EmailVerifyProvider]:
    """Free local verifier first; a commercial verifier is used to upgrade a
    result from VALID/UNKNOWN to VERIFIED when one is configured."""
    return _of_kind(EmailVerifyProvider)


def best_paid_verifier() -> EmailVerifyProvider | None:
    for p in email_verifiers():
        if p.cost_tier >= CostTier.PAID:
            return p
    return None


def enrichment_providers() -> list[EnrichmentProvider]:
    return _of_kind(EnrichmentProvider)


def get_provider(name: str) -> Provider | None:
    for p in _all():
        if p.name == name:
            return p
    return None


def registry_report() -> list[dict]:
    return [p.info() for p in sorted(_all(), key=lambda p: (p.kind, int(p.cost_tier), p.name))]


def capability_summary() -> dict:
    """What the system can actually do right now, given current configuration."""
    disc = discovery_providers()
    finders = email_finders()
    verifiers = email_verifiers()
    enrich = enrichment_providers()
    paid_verifier = best_paid_verifier()
    return {
        "discovery": [p.name for p in disc],
        "email_finders": ["website_crawl"] + [p.name for p in finders],
        "email_verifiers": [p.name for p in verifiers],
        "enrichment": ["website_scrape"] + [p.name for p in enrich],
        "can_reach_verified_status": bool(paid_verifier) or _smtp_enabled(),
        "notes": _notes(disc, finders, paid_verifier),
    }


def _smtp_enabled() -> bool:
    from ..config import settings
    return settings.smtp_probe_enabled


def _notes(disc, finders, paid_verifier) -> list[str]:
    notes = []
    if not paid_verifier and not _smtp_enabled():
        notes.append(
            "No commercial verifier configured and SMTP probing is off, so emails "
            "top out at status 'valid' (syntax + MX confirmed). Set "
            "ZEROBOUNCE_API_KEY / NEVERBOUNCE_API_KEY / MILLIONVERIFIER_API_KEY, or "
            "SMTP_PROBE_ENABLED=true on a network with outbound port 25, to reach "
            "'verified'."
        )
    if not finders:
        notes.append(
            "Email discovery is running on website crawling only. Adding "
            "HUNTER_API_KEY or SNOV_* credentials increases email hit rate on sites "
            "that do not publish addresses in HTML."
        )
    if all(p.name in {"openstreetmap"} for p in disc):
        notes.append(
            "Discovery is running on OpenStreetMap only. Adding "
            "GOOGLE_PLACES_API_KEY substantially increases business coverage and "
            "the share of records that already carry a website."
        )
    return notes

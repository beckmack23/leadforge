"""Commercial email-finding adapters (Hunter, Snov.io, Apollo).

IMPORTANT: these providers can return *pattern-guessed* addresses. We only
accept results the provider marks as actually sourced:

  * Hunter  - requires ``sources`` to be non-empty, or ``verification.status``
              to be ``valid``. Hunter's ``email-finder`` endpoint (pure pattern
              guessing) is deliberately NOT used.
  * Snov.io - accepts only emails with ``status`` in valid/verified.
  * Apollo  - accepts only when ``email_status`` is ``verified``; Apollo's
              "guessed" status is rejected.

Anything else is discarded rather than stored, because a guessed address stored
as a lead is exactly the failure mode this system must not have.
"""
from __future__ import annotations

import logging
import time

from ...config import settings
from ...core.http import get_client
from ..base import CostTier, EmailFinderProvider, ProviderEmail

log = logging.getLogger(__name__)


def _tier_from_title(title: str | None, has_name: bool) -> str:
    from ...core.titles import classify_title
    if title:
        _, _, is_dm = classify_title(title)
        if is_dm:
            return "decision_maker"
    return "employee" if has_name else "general_business"


class HunterFinder(EmailFinderProvider):
    name = "hunter"
    cost_tier = CostTier.PAID
    cost_units = 1.0
    description = ("Hunter.io Domain Search. Only accepts addresses Hunter reports "
                   "a public source for (or verifies as valid); pattern-guessed "
                   "results are discarded.")
    docs_url = "https://hunter.io/api-documentation/v2#domain-search"
    requires_keys = ("HUNTER_API_KEY",)

    @property
    def is_available(self) -> bool:
        return bool(settings.hunter_api_key)

    async def find(self, domain: str, company_name: str | None = None,
                   people: list[dict] | None = None) -> list[ProviderEmail]:
        if not self.is_available:
            return []
        status, data = await get_client().get_json(
            "https://api.hunter.io/v2/domain-search",
            params={"domain": domain, "api_key": settings.hunter_api_key, "limit": 25},
        )
        if status != 200 or not isinstance(data, dict):
            log.warning("hunter HTTP %s for %s", status, domain)
            return []
        payload = data.get("data") or {}
        out: list[ProviderEmail] = []
        for item in payload.get("emails", []) or []:
            address = (item.get("value") or "").strip().lower()
            if not address:
                continue
            sources = item.get("sources") or []
            verification = (item.get("verification") or {}).get("status")
            # ---- the anti-fabrication gate ----
            if not sources and verification != "valid":
                continue
            first = item.get("first_name")
            last = item.get("last_name")
            title = item.get("position")
            etype = item.get("type")  # 'personal' | 'generic'
            tier = ("general_business" if etype == "generic"
                    else _tier_from_title(title, bool(first or last)))
            out.append(ProviderEmail(
                address=address, email_type=tier, first_name=first, last_name=last,
                job_title=title,
                confidence=min(0.95, (item.get("confidence") or 50) / 100.0),
                status_hint="valid" if verification == "valid" else None,
                source_url=(sources[0].get("uri") if sources else None),
                provider=self.name,
            ))
        return out


class SnovFinder(EmailFinderProvider):
    name = "snov"
    cost_tier = CostTier.PAID
    cost_units = 1.0
    description = "Snov.io domain email search. Accepts only valid/verified results."
    docs_url = "https://snov.io/api"
    requires_keys = ("SNOV_CLIENT_ID", "SNOV_CLIENT_SECRET")

    _token: str | None = None
    _token_expiry: float = 0.0

    @property
    def is_available(self) -> bool:
        return bool(settings.snov_client_id and settings.snov_client_secret)

    async def _get_token(self) -> str | None:
        if self._token and time.time() < self._token_expiry:
            return self._token
        status, data = await get_client().get_json(
            "https://api.snov.io/v1/oauth/access_token", method="POST",
            json_body={"grant_type": "client_credentials",
                       "client_id": settings.snov_client_id,
                       "client_secret": settings.snov_client_secret},
        )
        if status != 200 or not isinstance(data, dict) or not data.get("access_token"):
            return None
        SnovFinder._token = data["access_token"]
        SnovFinder._token_expiry = time.time() + float(data.get("expires_in", 3600)) - 60
        return SnovFinder._token

    async def find(self, domain: str, company_name: str | None = None,
                   people: list[dict] | None = None) -> list[ProviderEmail]:
        if not self.is_available:
            return []
        token = await self._get_token()
        if not token:
            return []
        status, data = await get_client().get_json(
            "https://api.snov.io/v2/domain-emails-with-info",
            params={"access_token": token, "domain": domain, "type": "all",
                    "limit": 25, "lastId": 0},
        )
        if status != 200 or not isinstance(data, dict):
            return []
        out: list[ProviderEmail] = []
        for item in data.get("emails", []) or []:
            address = (item.get("email") or "").strip().lower()
            if not address:
                continue
            if str(item.get("status", "")).lower() not in {"valid", "verified"}:
                continue
            first, last = item.get("firstName"), item.get("lastName")
            title = item.get("position")
            etype = "general_business" if item.get("type") == "generic" else \
                _tier_from_title(title, bool(first or last))
            out.append(ProviderEmail(
                address=address, email_type=etype, first_name=first, last_name=last,
                job_title=title, confidence=0.85, status_hint="valid",
                source_url=item.get("sourcePage"), provider=self.name,
            ))
        return out


class ApolloFinder(EmailFinderProvider):
    name = "apollo"
    cost_tier = CostTier.PREMIUM
    cost_units = 2.0
    description = ("Apollo.io people search by company domain. Accepts only records "
                   "whose email_status is 'verified'; guessed emails are discarded.")
    docs_url = "https://docs.apollo.io/reference/people-search"
    requires_keys = ("APOLLO_API_KEY",)

    @property
    def is_available(self) -> bool:
        return bool(settings.apollo_api_key)

    async def find(self, domain: str, company_name: str | None = None,
                   people: list[dict] | None = None) -> list[ProviderEmail]:
        if not self.is_available:
            return []
        status, data = await get_client().get_json(
            "https://api.apollo.io/api/v1/mixed_people/search", method="POST",
            headers={"X-Api-Key": settings.apollo_api_key or "",
                     "Content-Type": "application/json", "Cache-Control": "no-cache"},
            json_body={
                "q_organization_domains_list": [domain],
                "person_seniorities": ["owner", "founder", "c_suite", "partner",
                                       "vp", "head", "director"],
                "page": 1, "per_page": 10,
            },
        )
        if status != 200 or not isinstance(data, dict):
            log.warning("apollo HTTP %s for %s", status, domain)
            return []
        out: list[ProviderEmail] = []
        for person in data.get("people", []) or []:
            address = (person.get("email") or "").strip().lower()
            email_status = (person.get("email_status") or "").lower()
            # ---- the anti-fabrication gate ----
            if not address or email_status != "verified":
                continue
            if address.endswith("email_not_unlocked@domain.com"):
                continue
            title = person.get("title")
            out.append(ProviderEmail(
                address=address,
                email_type=_tier_from_title(title, True),
                first_name=person.get("first_name"), last_name=person.get("last_name"),
                job_title=title, confidence=0.9, status_hint="verified",
                source_url=person.get("linkedin_url"), provider=self.name,
            ))
        return out

"""FREE business discovery via OpenStreetMap (Overpass API + Nominatim).

OSM data is ODbL-licensed and openly queryable, so this provider needs no API
key and is the default discovery source. It returns real, published business
records including - crucially - the ``website`` tag for a large share of
commercial POIs.

We are guests on a volunteer-run API, so we:
  * send a descriptive User-Agent
  * cap query timeouts and result counts
  * cache area lookups and query responses
  * serialise requests (Overpass rejects parallel heavy queries)
"""
from __future__ import annotations

import asyncio
import logging
import re

from ...config import settings
from ...core import aiolocks
from ...core.http import get_client
from ...core.normalize import normalize_url
from ...core.taxonomy import find_industry, industry_by_key, state_full_name
from ..base import CostTier, DiscoveredBusiness, DiscoveryProvider, SearchCriteria

log = logging.getLogger(__name__)

_AREA_CACHE: dict[str, str] = {}

# Tags on a POI that tell us it is a business rather than a footpath.
_NAME_TAGS = ("name", "operator", "brand")


class OverpassDiscovery(DiscoveryProvider):
    name = "openstreetmap"
    cost_tier = CostTier.FREE
    cost_units = 0.0
    description = ("OpenStreetMap Overpass API. Free, no key. Best coverage for "
                   "physical/local businesses; returns website + phone tags.")
    docs_url = "https://wiki.openstreetmap.org/wiki/Overpass_API"

    @property
    def is_available(self) -> bool:
        return True

    # ------------------------------------------------------------------
    async def search(self, criteria: SearchCriteria, limit: int) -> list[DiscoveredBusiness]:
        selectors = self._selectors(criteria)
        if not selectors:
            log.warning("overpass: no usable selectors for criteria")
            return []

        area_clause = await self._area_clause(criteria)
        if area_clause is None:
            log.warning("overpass: could not resolve a search area")
            return []

        results: list[DiscoveredBusiness] = []
        seen: set[str] = set()
        # Chunk selectors so a single query never gets too heavy.
        for chunk in _chunks(selectors, 6):
            if len(results) >= limit:
                break
            body = self._build_query(chunk, area_clause, criteria,
                                     min(limit * 3, 4000))
            payload = await self._run(body)
            for el in payload.get("elements", []):
                biz = self._to_business(el, criteria)
                if biz is None:
                    continue
                key = (biz.external_id or "") + "|" + biz.name.lower()
                if key in seen:
                    continue
                seen.add(key)
                results.append(biz)
        return results[: limit * 2]  # over-fetch: many will lack a website

    # ------------------------------------------------------------------
    def _selectors(self, criteria: SearchCriteria) -> list[str]:
        """Build Overpass tag filters from industry + keywords."""
        out: list[str] = []
        ind = None
        if criteria.industry:
            ind = industry_by_key().get(criteria.industry) or find_industry(criteria.industry)
        if ind is None and criteria.keywords:
            ind = find_industry(" ".join(criteria.keywords))

        if ind:
            for spec in ind.osm:
                parts = spec.split("+")
                clause = ""
                for part in parts:
                    if "=" in part:
                        k, v = part.split("=", 1)
                        clause += f'["{k}"="{v}"]'
                    else:
                        clause += f'["{part}"]'
                out.append(clause)

        # Keyword search across name/operator tags (case-insensitive regex).
        kws = list(criteria.keywords)
        if ind and not out:
            kws.extend(ind.keywords[:5])
        if kws:
            pattern = "|".join(re.escape(k) for k in kws[:8] if k)
            if pattern:
                for tag in _NAME_TAGS[:1]:
                    out.append(f'["{tag}"~"{pattern}",i]["website"]')
        return out or ['["office"]["website"]']

    async def _area_clause(self, criteria: SearchCriteria) -> str | None:
        """Return the Overpass spatial filter, e.g. '(area.searchArea)'."""
        if criteria.latitude is not None and criteria.longitude is not None:
            radius_m = int((criteria.radius_miles or 25) * 1609.34)
            return f"(around:{radius_m},{criteria.latitude},{criteria.longitude})"

        # ZIP / city / state -> geocode via Nominatim, then use an area id.
        query_bits = []
        if criteria.postal_code:
            query_bits.append(criteria.postal_code)
        if criteria.city:
            query_bits.append(criteria.city)
        if criteria.state:
            query_bits.append(state_full_name(criteria.state) or criteria.state)
        if criteria.country and criteria.country != "US":
            query_bits.append(criteria.country)
        elif not criteria.state and not criteria.city and not criteria.postal_code:
            return None

        # A state with no city: use the ISO3166-2 area directly (fast + exact).
        if criteria.state and not criteria.city and not criteria.postal_code:
            iso = f"{criteria.country}-{criteria.state}"
            return ("__AREA__", f'area["ISO3166-2"="{iso}"]->.searchArea;')  # type: ignore[return-value]

        place = ", ".join(query_bits)
        geo = await self._geocode(place)
        if geo is None:
            return None
        lat, lon, osm_type, osm_id = geo
        if criteria.radius_miles:
            radius_m = int(criteria.radius_miles * 1609.34)
            return f"(around:{radius_m},{lat},{lon})"
        if osm_type == "relation":
            return ("__AREA__", f"area({3600000000 + int(osm_id)})->.searchArea;")  # type: ignore[return-value]
        if osm_type == "way":
            return ("__AREA__", f"area({2400000000 + int(osm_id)})->.searchArea;")  # type: ignore[return-value]
        radius_m = int((criteria.radius_miles or 15) * 1609.34)
        return f"(around:{radius_m},{lat},{lon})"

    async def _geocode(self, place: str) -> tuple[float, float, str, int] | None:
        key = place.lower().strip()
        if key in _AREA_CACHE:
            cached = _AREA_CACHE[key]
            if cached == "__NONE__":
                return None
            lat, lon, t, i = cached.split("|")
            return float(lat), float(lon), t, int(i)

        client = get_client()
        async with aiolocks.semaphore("overpass", 1):
            await asyncio.sleep(1.1)  # Nominatim: max 1 req/sec
            status, data = await client.get_json(
                settings.nominatim_url,
                params={"q": place, "format": "json", "limit": 1,
                        "addressdetails": 0, "polygon_geojson": 0},
                headers={"User-Agent": settings.effective_user_agent},
            )
        if status != 200 or not isinstance(data, list) or not data:
            _AREA_CACHE[key] = "__NONE__"
            return None
        top = data[0]
        try:
            res = (float(top["lat"]), float(top["lon"]),
                   top.get("osm_type", "node"), int(top.get("osm_id", 0)))
        except (KeyError, TypeError, ValueError):
            _AREA_CACHE[key] = "__NONE__"
            return None
        _AREA_CACHE[key] = f"{res[0]}|{res[1]}|{res[2]}|{res[3]}"
        return res

    def _build_query(self, selectors: list[str], area_clause, criteria: SearchCriteria,
                     cap: int) -> str:
        if isinstance(area_clause, tuple):
            prelude = area_clause[1]
            spatial = "(area.searchArea)"
        else:
            prelude = ""
            spatial = area_clause

        lines = []
        for sel in selectors:
            for kind in ("nwr",):
                lines.append(f"  {kind}{sel}{spatial};")
        body = "\n".join(lines)
        return (
            f"[out:json][timeout:120];\n"
            f"{prelude}\n"
            f"(\n{body}\n);\n"
            f"out center tags {cap};"
        )

    async def _run(self, query: str) -> dict:
        client = get_client()
        async with aiolocks.semaphore("overpass", 1):
            await client.start()
            for attempt in range(3):
                # Overpass wants a urlencoded form body, not JSON.
                try:
                    resp = await client.raw.post(
                        settings.overpass_url,
                        content=f"data={_urlencode(query)}",
                        headers={"User-Agent": settings.effective_user_agent,
                                 "Content-Type": "application/x-www-form-urlencoded"},
                        timeout=180.0,
                    )
                except Exception as exc:  # noqa: BLE001
                    log.warning("overpass request failed: %s", exc)
                    await asyncio.sleep(3 * (attempt + 1))
                    continue
                if resp.status_code == 200:
                    try:
                        return resp.json()
                    except Exception:
                        return {}
                if resp.status_code in (429, 504):
                    log.info("overpass busy (%s), backing off", resp.status_code)
                    await asyncio.sleep(8 * (attempt + 1))
                    continue
                log.warning("overpass HTTP %s: %s", resp.status_code, resp.text[:200])
                return {}
            return {}

    # ------------------------------------------------------------------
    def _to_business(self, el: dict, criteria: SearchCriteria) -> DiscoveredBusiness | None:
        tags = el.get("tags") or {}
        name = (tags.get("name") or tags.get("operator") or tags.get("brand") or "").strip()
        if not name or len(name) > 300:
            return None

        website = None
        for k in ("website", "contact:website", "url", "website:en"):
            if tags.get(k):
                website = normalize_url(tags[k])
                if website:
                    break

        phone = tags.get("phone") or tags.get("contact:phone") or tags.get("phone:mobile")

        street = " ".join(x for x in [tags.get("addr:housenumber"), tags.get("addr:street")] if x)
        address = street or tags.get("addr:full") or None

        lat = el.get("lat") or (el.get("center") or {}).get("lat")
        lon = el.get("lon") or (el.get("center") or {}).get("lon")

        ind = None
        if criteria.industry:
            ind = industry_by_key().get(criteria.industry)
        if ind is None:
            ind = find_industry(name) or find_industry(
                " ".join(f"{k}={v}" for k, v in tags.items() if k in
                         ("shop", "craft", "office", "amenity", "healthcare"))
            )

        founded = None
        for k in ("start_date", "established", "founded"):
            if tags.get(k):
                m = re.search(r"(1[6-9]\d{2}|20[0-2]\d)", str(tags[k]))
                if m:
                    founded = int(m.group(1))
                    break

        osm_type = el.get("type", "node")
        osm_id = el.get("id")

        # OSM email tags are real published addresses - carry them through.
        extra = {}
        for k in ("email", "contact:email"):
            if tags.get(k):
                extra["email"] = tags[k]
                break
        for social_key, tag_key in (("facebook", "contact:facebook"),
                                    ("instagram", "contact:instagram"),
                                    ("linkedin", "contact:linkedin"),
                                    ("twitter", "contact:twitter")):
            if tags.get(tag_key):
                extra[social_key] = tags[tag_key]
        if tags.get("description"):
            extra["description"] = tags["description"][:1000]
        if tags.get("brand:wikidata") or tags.get("brand"):
            extra["franchise_hint"] = "franchise"

        return DiscoveredBusiness(
            name=name,
            website=website,
            phone=phone,
            address=address,
            city=tags.get("addr:city"),
            state=tags.get("addr:state") or criteria.state,
            postal_code=tags.get("addr:postcode"),
            country=tags.get("addr:country") or criteria.country,
            latitude=float(lat) if lat is not None else None,
            longitude=float(lon) if lon is not None else None,
            industry=ind.name if ind else criteria.industry,
            sub_industry=ind.sub_industry if ind else None,
            naics=ind.naics if ind else criteria.naics,
            sic=ind.sic if ind else criteria.sic,
            description=tags.get("description"),
            founded_year=founded,
            external_id=f"osm:{osm_type}/{osm_id}",
            provider=self.name,
            source_url=f"https://www.openstreetmap.org/{osm_type}/{osm_id}",
            extra=extra,
        )


def _chunks(seq: list, size: int):
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


def _urlencode(s: str) -> str:
    from urllib.parse import quote
    return quote(s, safe="")

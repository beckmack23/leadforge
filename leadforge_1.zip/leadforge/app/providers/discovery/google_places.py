"""Google Places API (New) discovery adapter. Activates when GOOGLE_PLACES_API_KEY is set.

Uses Text Search + Place Details, which is the officially supported way to look
up businesses by category and location and to retrieve ``websiteUri``.
"""
from __future__ import annotations

import asyncio
import logging

from ...config import settings
from ...core.http import get_client
from ...core.normalize import normalize_url
from ...core.taxonomy import find_industry, industry_by_key, state_full_name
from ..base import CostTier, DiscoveredBusiness, DiscoveryProvider, SearchCriteria

log = logging.getLogger(__name__)

TEXT_SEARCH_URL = "https://places.googleapis.com/v1/places:searchText"

FIELD_MASK = ",".join([
    "places.id", "places.displayName", "places.formattedAddress",
    "places.addressComponents", "places.websiteUri", "places.nationalPhoneNumber",
    "places.internationalPhoneNumber", "places.location", "places.primaryTypeDisplayName",
    "places.types", "places.businessStatus", "places.editorialSummary",
    "nextPageToken",
])


class GooglePlacesDiscovery(DiscoveryProvider):
    name = "google_places"
    cost_tier = CostTier.CHEAP
    cost_units = 1.0
    description = ("Google Places API (New) Text Search. Highest-quality local "
                   "business coverage including website URLs.")
    docs_url = "https://developers.google.com/maps/documentation/places/web-service/text-search"
    requires_keys = ("GOOGLE_PLACES_API_KEY",)

    @property
    def is_available(self) -> bool:
        return bool(settings.google_places_api_key)

    async def search(self, criteria: SearchCriteria, limit: int) -> list[DiscoveredBusiness]:
        if not self.is_available:
            return []
        client = get_client()
        query = self._text_query(criteria)
        out: list[DiscoveredBusiness] = []
        page_token = None
        headers = {
            "X-Goog-Api-Key": settings.google_places_api_key or "",
            "X-Goog-FieldMask": FIELD_MASK,
            "Content-Type": "application/json",
        }
        for _ in range(20):  # 20 pages x 20 results = 400 max per query
            body: dict = {"textQuery": query, "pageSize": 20}
            if criteria.latitude and criteria.longitude and criteria.radius_miles:
                body["locationBias"] = {"circle": {
                    "center": {"latitude": criteria.latitude, "longitude": criteria.longitude},
                    "radius": min(criteria.radius_miles * 1609.34, 50000),
                }}
            if page_token:
                body["pageToken"] = page_token
            status, data = await client.get_json(TEXT_SEARCH_URL, method="POST",
                                                 headers=headers, json_body=body)
            if status != 200:
                log.warning("google places HTTP %s: %s", status, str(data)[:200])
                break
            for place in data.get("places", []) or []:
                biz = self._to_business(place, criteria)
                if biz:
                    out.append(biz)
            page_token = data.get("nextPageToken")
            if not page_token or len(out) >= limit:
                break
            await asyncio.sleep(0.5)
        return out

    def _text_query(self, criteria: SearchCriteria) -> str:
        what = criteria.industry or ""
        if criteria.industry:
            ind = industry_by_key().get(criteria.industry)
            if ind:
                what = ind.name
        if criteria.keywords:
            what = (what + " " + " ".join(criteria.keywords)).strip()
        where = ", ".join(x for x in [criteria.city,
                                      state_full_name(criteria.state) or criteria.state,
                                      criteria.postal_code] if x)
        return f"{what or 'businesses'} in {where or criteria.country}".strip()

    def _to_business(self, place: dict, criteria: SearchCriteria) -> DiscoveredBusiness | None:
        name = ((place.get("displayName") or {}).get("text") or "").strip()
        if not name:
            return None
        if place.get("businessStatus") in {"CLOSED_PERMANENTLY"}:
            return None
        comps = {}
        for c in place.get("addressComponents", []) or []:
            for t in c.get("types", []):
                comps.setdefault(t, c.get("shortText") or c.get("longText"))
        ind = industry_by_key().get(criteria.industry or "") or find_industry(
            (place.get("primaryTypeDisplayName") or {}).get("text") or name
        )
        loc = place.get("location") or {}
        return DiscoveredBusiness(
            name=name,
            website=normalize_url(place.get("websiteUri")),
            phone=place.get("nationalPhoneNumber") or place.get("internationalPhoneNumber"),
            address=place.get("formattedAddress"),
            city=comps.get("locality") or comps.get("postal_town"),
            state=comps.get("administrative_area_level_1") or criteria.state,
            postal_code=comps.get("postal_code"),
            country=comps.get("country") or criteria.country,
            latitude=loc.get("latitude"),
            longitude=loc.get("longitude"),
            industry=ind.name if ind else criteria.industry,
            sub_industry=ind.sub_industry if ind else None,
            naics=ind.naics if ind else None,
            sic=ind.sic if ind else None,
            description=(place.get("editorialSummary") or {}).get("text"),
            external_id=f"google:{place.get('id')}",
            provider=self.name,
            source_url=f"https://www.google.com/maps/place/?q=place_id:{place.get('id')}",
        )

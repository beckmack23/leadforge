"""Yelp Fusion discovery adapter. Activates when YELP_API_KEY is set."""
from __future__ import annotations

import logging

from ...config import settings
from ...core.http import get_client
from ...core.taxonomy import find_industry, industry_by_key, state_full_name
from ..base import CostTier, DiscoveredBusiness, DiscoveryProvider, SearchCriteria

log = logging.getLogger(__name__)

SEARCH_URL = "https://api.yelp.com/v3/businesses/search"


class YelpDiscovery(DiscoveryProvider):
    name = "yelp"
    cost_tier = CostTier.CHEAP
    cost_units = 1.0
    description = ("Yelp Fusion business search. Good local coverage and category "
                   "taxonomy. Note: Yelp does not return company websites, so "
                   "results feed website resolution rather than skipping it.")
    docs_url = "https://docs.developer.yelp.com/reference/v3_business_search"
    requires_keys = ("YELP_API_KEY",)

    @property
    def is_available(self) -> bool:
        return bool(settings.yelp_api_key)

    async def search(self, criteria: SearchCriteria, limit: int) -> list[DiscoveredBusiness]:
        if not self.is_available:
            return []
        client = get_client()
        headers = {"Authorization": f"Bearer {settings.yelp_api_key}"}
        term = criteria.industry or ""
        ind = industry_by_key().get(criteria.industry or "")
        if ind:
            term = ind.name
        if criteria.keywords:
            term = (term + " " + " ".join(criteria.keywords)).strip()
        location = ", ".join(x for x in [criteria.city,
                                         state_full_name(criteria.state) or criteria.state,
                                         criteria.postal_code] if x) or criteria.country

        out: list[DiscoveredBusiness] = []
        for offset in range(0, min(limit, 1000), 50):
            params = {"term": term or "business", "location": location,
                      "limit": 50, "offset": offset}
            if criteria.radius_miles:
                params["radius"] = int(min(criteria.radius_miles * 1609.34, 40000))
            status, data = await client.get_json(SEARCH_URL, params=params, headers=headers)
            if status != 200:
                log.warning("yelp HTTP %s: %s", status, str(data)[:200])
                break
            businesses = data.get("businesses", []) or []
            if not businesses:
                break
            for b in businesses:
                loc = b.get("location") or {}
                cats = ", ".join(c.get("title", "") for c in (b.get("categories") or []))
                match = ind or find_industry(cats)
                out.append(DiscoveredBusiness(
                    name=b.get("name", "").strip(),
                    website=None,  # Yelp does not expose the business website
                    phone=b.get("phone") or b.get("display_phone"),
                    address=", ".join(loc.get("display_address") or []) or None,
                    city=loc.get("city"),
                    state=loc.get("state") or criteria.state,
                    postal_code=loc.get("zip_code"),
                    country=loc.get("country") or criteria.country,
                    latitude=(b.get("coordinates") or {}).get("latitude"),
                    longitude=(b.get("coordinates") or {}).get("longitude"),
                    industry=match.name if match else criteria.industry,
                    sub_industry=match.sub_industry if match else cats or None,
                    naics=match.naics if match else None,
                    sic=match.sic if match else None,
                    external_id=f"yelp:{b.get('id')}",
                    provider=self.name,
                    source_url=b.get("url"),
                ))
            if len(out) >= limit:
                break
        return out

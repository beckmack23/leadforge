"""Import businesses the operator already has (CSV/JSON) into the pipeline.

Useful for enriching an existing list: bring your own companies, let LeadForge
find the websites, emails, contacts and signals.
"""
from __future__ import annotations

import csv
import io
import json

from ...core.normalize import normalize_url
from ...core.taxonomy import find_industry, normalize_country, normalize_state
from ..base import CostTier, DiscoveredBusiness, DiscoveryProvider, SearchCriteria

# Accepted header aliases -> canonical field
HEADER_MAP = {
    "company": "name", "company name": "name", "business": "name",
    "business name": "name", "name": "name", "organization": "name",
    "website": "website", "url": "website", "domain": "website", "site": "website",
    "web": "website", "homepage": "website",
    "phone": "phone", "telephone": "phone", "phone number": "phone",
    "address": "address", "street": "address", "address1": "address",
    "street address": "address",
    "city": "city", "town": "city",
    "state": "state", "province": "state", "region": "state",
    "zip": "postal_code", "zipcode": "postal_code", "postal code": "postal_code",
    "postcode": "postal_code", "postal_code": "postal_code",
    "country": "country",
    "industry": "industry", "sector": "industry", "category": "industry",
    "naics": "naics", "sic": "sic",
    "employees": "employee_count", "employee count": "employee_count",
    "headcount": "employee_count",
    "founded": "founded_year", "founded year": "founded_year", "year founded": "founded_year",
    "description": "description", "about": "description",
    "email": "email",
}


class CsvImportDiscovery(DiscoveryProvider):
    """Not called by the normal search flow; driven by the /api/import endpoint."""
    name = "user_import"
    cost_tier = CostTier.FREE
    cost_units = 0.0
    description = "Import your own company list (CSV or JSON) and enrich it."

    async def search(self, criteria: SearchCriteria, limit: int) -> list[DiscoveredBusiness]:
        return []

    # ------------------------------------------------------------------
    def parse(self, content: str, filename: str = "") -> list[DiscoveredBusiness]:
        content = content.strip()
        if not content:
            return []
        if filename.lower().endswith(".json") or content[0] in "[{":
            return self._parse_json(content)
        return self._parse_csv(content)

    def _parse_json(self, content: str) -> list[DiscoveredBusiness]:
        try:
            data = json.loads(content)
        except Exception:
            return []
        rows = data if isinstance(data, list) else data.get("items") or data.get("data") or []
        return [b for b in (self._row_to_business(r) for r in rows if isinstance(r, dict)) if b]

    def _parse_csv(self, content: str) -> list[DiscoveredBusiness]:
        try:
            dialect = csv.Sniffer().sniff(content[:4096], delimiters=",;\t|")
        except Exception:
            dialect = csv.excel
        reader = csv.DictReader(io.StringIO(content), dialect=dialect)
        out = []
        for row in reader:
            biz = self._row_to_business(row)
            if biz:
                out.append(biz)
        return out

    def _row_to_business(self, row: dict) -> DiscoveredBusiness | None:
        norm: dict = {}
        for key, value in row.items():
            if key is None or value is None:
                continue
            canonical = HEADER_MAP.get(str(key).strip().lower())
            if canonical and str(value).strip():
                norm[canonical] = str(value).strip()
        name = norm.get("name")
        if not name:
            return None
        ind = find_industry(norm.get("industry") or name)
        extra = {}
        if norm.get("email"):
            extra["email"] = norm["email"]
        return DiscoveredBusiness(
            name=name,
            website=normalize_url(norm.get("website")),
            phone=norm.get("phone"),
            address=norm.get("address"),
            city=norm.get("city"),
            state=normalize_state(norm.get("state")),
            postal_code=norm.get("postal_code"),
            country=normalize_country(norm.get("country") or "US"),
            industry=(ind.name if ind else norm.get("industry")),
            sub_industry=ind.sub_industry if ind else None,
            naics=norm.get("naics") or (ind.naics if ind else None),
            sic=norm.get("sic") or (ind.sic if ind else None),
            employee_count=_as_int(norm.get("employee_count")),
            founded_year=_as_int(norm.get("founded_year")),
            description=norm.get("description"),
            provider=self.name,
            extra=extra,
        )


def _as_int(v) -> int | None:
    try:
        return int(float(str(v).replace(",", "")))
    except (TypeError, ValueError):
        return None

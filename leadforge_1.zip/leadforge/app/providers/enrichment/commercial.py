"""Company (firmographic) enrichment adapters.

These are the most expensive calls in the pipeline, so the orchestrator only
reaches them after free website-derived enrichment has run and only for leads
that are already qualified (see settings.skip_paid_when_qualified).

Everything returned here is marked ``is_estimate=True`` where the provider
itself models the value (revenue, employee counts), so the UI can show it as an
estimate rather than a confirmed fact.
"""
from __future__ import annotations

import logging

from ...config import settings
from ...core.http import get_client
from ...core.normalize import normalize_url
from ...core.taxonomy import find_industry
from ..base import CompanyEnrichment, CostTier, EnrichmentProvider

log = logging.getLogger(__name__)


class ClearbitEnrichment(EnrichmentProvider):
    name = "clearbit"
    cost_tier = CostTier.PAID
    cost_units = 1.0
    description = "Clearbit Company Enrichment by domain."
    docs_url = "https://dashboard.clearbit.com/docs#enrichment-api"
    requires_keys = ("CLEARBIT_API_KEY",)

    @property
    def is_available(self) -> bool:
        return bool(settings.clearbit_api_key)

    async def enrich(self, domain: str, company_name: str | None = None):
        if not self.is_available:
            return None
        status, data = await get_client().get_json(
            "https://company.clearbit.com/v2/companies/find",
            params={"domain": domain},
            headers={"Authorization": f"Bearer {settings.clearbit_api_key}"},
        )
        if status != 200 or not isinstance(data, dict) or data.get("error"):
            return None
        metrics = data.get("metrics") or {}
        geo = data.get("geo") or {}
        cat = data.get("category") or {}
        ind = find_industry(cat.get("industry") or cat.get("sector") or "")
        return CompanyEnrichment(
            employee_count=metrics.get("employees"),
            estimated_revenue=metrics.get("annualRevenue")
            or metrics.get("estimatedAnnualRevenue"),
            founded_year=data.get("foundedYear"),
            industry=cat.get("industry") or (ind.name if ind else None),
            sub_industry=cat.get("subIndustry"),
            naics=cat.get("naicsCode") or (ind.naics if ind else None),
            sic=cat.get("sicCode") or (ind.sic if ind else None),
            description=data.get("description"),
            linkedin_url=_handle(data, "linkedin", "https://www.linkedin.com/"),
            facebook_url=_handle(data, "facebook", "https://www.facebook.com/"),
            twitter_url=_handle(data, "twitter", "https://twitter.com/"),
            address=geo.get("streetNumber") and
            f"{geo.get('streetNumber')} {geo.get('streetName') or ''}".strip() or None,
            city=geo.get("city"), state=geo.get("stateCode") or geo.get("state"),
            postal_code=geo.get("postalCode"), country=geo.get("countryCode"),
            phone=data.get("phone"),
            provider=self.name, is_estimate=True,
            source_url=f"https://clearbit.com/{domain}", raw=data,
        )


class PeopleDataLabsEnrichment(EnrichmentProvider):
    name = "peopledatalabs"
    cost_tier = CostTier.PREMIUM
    cost_units = 2.0
    description = "People Data Labs Company Enrichment by domain."
    docs_url = "https://docs.peopledatalabs.com/docs/company-enrichment-api"
    requires_keys = ("PEOPLEDATALABS_API_KEY",)

    @property
    def is_available(self) -> bool:
        return bool(settings.peopledatalabs_api_key)

    async def enrich(self, domain: str, company_name: str | None = None):
        if not self.is_available:
            return None
        status, data = await get_client().get_json(
            "https://api.peopledatalabs.com/v5/company/enrich",
            params={"website": domain},
            headers={"X-Api-Key": settings.peopledatalabs_api_key or ""},
        )
        if status != 200 or not isinstance(data, dict) or data.get("status") != 200:
            return None
        loc = data.get("location") or {}
        ind = find_industry(data.get("industry") or "")
        return CompanyEnrichment(
            employee_count=data.get("employee_count"),
            estimated_revenue=_parse_pdl_revenue(data.get("inferred_revenue")),
            founded_year=data.get("founded"),
            num_locations=len(data.get("locations") or []) or None,
            industry=data.get("industry") or (ind.name if ind else None),
            naics=_first_code(data.get("naics"), "naics_code") or (ind.naics if ind else None),
            sic=_first_code(data.get("sic"), "sic_code") or (ind.sic if ind else None),
            description=data.get("summary"),
            linkedin_url=_prefix(data.get("linkedin_url")),
            facebook_url=_prefix(data.get("facebook_url")),
            twitter_url=_prefix(data.get("twitter_url")),
            address=loc.get("street_address"), city=loc.get("locality"),
            state=(loc.get("region") or "")[:2].upper() or None,
            postal_code=loc.get("postal_code"), country=loc.get("country"),
            provider=self.name, is_estimate=True,
            source_url=f"https://peopledatalabs.com/company/{domain}", raw=data,
        )


def _handle(data: dict, key: str, prefix: str) -> str | None:
    node = data.get(key) or {}
    handle = node.get("handle") if isinstance(node, dict) else None
    return prefix + handle if handle else None


def _prefix(url: str | None) -> str | None:
    if not url:
        return None
    return normalize_url(url)


def _first_code(value, key: str) -> str | None:
    if isinstance(value, list) and value:
        first = value[0]
        if isinstance(first, dict):
            return first.get(key)
        return str(first)
    if isinstance(value, str):
        return value
    return None


def _parse_pdl_revenue(value) -> float | None:
    """PDL returns bands like '$10M-$25M'. Use the midpoint, flagged as estimate."""
    if not value:
        return None
    from ...core.normalize import parse_money
    import re
    parts = re.findall(r"\$?([\d.]+\s*[KMB]?)", str(value).upper())
    nums = [parse_money(p.replace(" ", "")) for p in parts]
    nums = [n for n in nums if n]
    if not nums:
        return None
    return sum(nums) / len(nums)

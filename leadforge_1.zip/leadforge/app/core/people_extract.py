"""Extract people (name + job title) from public About / Team / Leadership pages.

Strategy, highest confidence first:
  1. JSON-LD ``Person`` / ``employee`` / ``founder`` entities
  2. DOM card heuristics - a block that contains a name-shaped string and a
     recognised job title in close proximity
  3. Free-text patterns - "John Smith, Owner" / "Owner: John Smith" /
     "John Smith - President and Founder"

Names are only accepted when they look like real personal names and are not
obviously company names, navigation labels or city names.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from bs4 import BeautifulSoup, Tag

from .normalize import split_person_name
from .titles import classify_title

# A person name: 2-4 capitalised tokens, allowing O'Brien, McDonald, de la Cruz.
NAME_TOKEN = r"[A-Z][a-z'’\-]{1,20}|[A-Z]\.|(?:Mc|Mac|O')[A-Z][a-z'’\-]{1,20}|de|van|von|del|la|di|le"
PERSON_NAME_RE = re.compile(
    rf"\b((?:{NAME_TOKEN})(?:\s+(?:{NAME_TOKEN})){{1,3}})\b"
)

TITLE_SEPARATORS = r"(?:,|–|—|-|\||•|·|:|\n)"

# "John Smith, Owner"  /  "John Smith - President & CEO"
NAME_THEN_TITLE_RE = re.compile(
    rf"\b((?:{NAME_TOKEN})(?:\s+(?:{NAME_TOKEN})){{1,3}})\s*{TITLE_SEPARATORS}\s*"
    r"([A-Za-z&/ .'\-]{3,60})"
)

# "Owner: John Smith"  /  "President - John Smith"
TITLE_THEN_NAME_RE = re.compile(
    rf"\b([A-Za-z&/ .'\-]{{3,60}}?)\s*{TITLE_SEPARATORS}\s*"
    rf"((?:{NAME_TOKEN})(?:\s+(?:{NAME_TOKEN})){{1,3}})\b"
)

_NOT_A_PERSON = re.compile(
    r"\b(our|team|staff|meet|leadership|management|crew|people|employees|"
    r"welcome|message|values|mission|history|careers|hiring|profile|"
    r"inc|llc|llp|ltd|corp|corporation|company|co|group|services|solutions|"
    r"systems|associates|partners|enterprises|industries|holdings|construction|"
    r"heating|cooling|plumbing|roofing|electric|contracting|supply|center|centre|"
    r"clinic|hospital|university|college|school|church|county|city|street|avenue|"
    r"road|suite|floor|north|south|east|west|monday|tuesday|wednesday|thursday|"
    r"friday|saturday|sunday|january|february|march|april|june|july|august|"
    r"september|october|november|december|privacy|policy|terms|service|contact|"
    r"about|home|read|more|learn|call|email|phone|copyright|rights|reserved|"
    r"free|estimate|quote|schedule|appointment|emergency|available|licensed|"
    r"insured|bonded|reviews|testimonials|gallery|projects|financing)\b",
    re.I,
)

_ALL_CAPS_RE = re.compile(r"^[A-Z][A-Z .'\-]{3,}$")

# Job-title words that can never be part of a person's name. Kept separate from
# _TITLE_VOCAB (which includes connectors like "of"/"and" that legitimately
# appear in names such as "Ana de la Cruz").
_TITLE_VOCAB_STRICT = {
    "owner", "proprietor", "principal", "founder", "cofounder", "managing",
    "partner", "partners", "chief", "executive", "officer", "ceo", "coo", "cfo",
    "cto", "cmo", "cio", "president", "vice", "vp", "evp", "svp", "manager",
    "management", "director", "supervisor", "foreman", "specialist",
    "coordinator", "technician", "representative", "associate", "assistant",
    "analyst", "engineer", "administrator", "estimator", "consultant",
    "operations", "sales", "marketing", "finance", "financial", "resources",
    "chairman", "chairwoman", "treasurer", "controller", "department",
}

# US state abbreviations: "Philadelphia PA" is a place, not a person.
_STATE_ABBRS = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI", "ID",
    "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO",
    "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA",
    "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", "PR",
}


@dataclass
class FoundPerson:
    full_name: str
    first_name: str | None
    last_name: str | None
    job_title: str | None
    seniority: str | None
    is_decision_maker: bool
    source_url: str
    source_type: str
    confidence: float
    linkedin_url: str | None = None
    email_hint: str | None = None


def looks_like_person_name(name: str) -> bool:
    name = name.strip()
    if not name or len(name) > 60:
        return False
    tokens = [t for t in name.split() if t]
    if not (2 <= len(tokens) <= 4):
        return False
    if _NOT_A_PERSON.search(name):
        return False
    # At least two tokens must be >1 char and start uppercase
    substantive = [t for t in tokens if len(t.strip(".")) > 1]
    if len(substantive) < 2:
        return False
    if not all(t[0].isupper() or t.lower() in {"de", "van", "von", "del", "la", "di", "le"}
               for t in tokens):
        return False
    if any(ch.isdigit() for ch in name):
        return False
    # "Philadelphia PA", "Austin TX" - a place, not a person.
    if tokens[-1].strip(".,").upper() in _STATE_ABBRS and tokens[-1].isupper():
        return False
    # "Tom Alvarez Operations Manager" - a name that has run into a job title.
    # A person's name does not contain job-title vocabulary.
    if any(t.lower().strip(".,'-") in _TITLE_VOCAB_STRICT for t in tokens):
        return False
    return True


def _mk_person(full_name: str, title: str | None, source_url: str,
               source_type: str, confidence: float,
               linkedin: str | None = None) -> FoundPerson | None:
    full_name = re.sub(r"\s+", " ", full_name).strip(" ,.-–—|")
    if _ALL_CAPS_RE.match(full_name):
        full_name = full_name.title()
    if not looks_like_person_name(full_name):
        return None
    title_clean = None
    seniority = label = None
    is_dm = False
    if title:
        title_clean = _strip_title_noise(title)[:120]
        seniority, label, is_dm = classify_title(title_clean)
        if seniority is None or not _title_is_clean(title_clean):
            title_clean = None
            seniority = None
            is_dm = False
    first, last = split_person_name(full_name)
    return FoundPerson(
        full_name=full_name, first_name=first, last_name=last,
        job_title=title_clean, seniority=seniority, is_decision_maker=is_dm,
        source_url=source_url, source_type=source_type,
        confidence=confidence + (0.15 if title_clean else 0.0),
        linkedin_url=linkedin,
    )


# --------------------------------------------------------------------------
# 1. JSON-LD
# --------------------------------------------------------------------------

def people_from_jsonld(jsonld: list[dict], source_url: str,
                       source_type: str) -> list[FoundPerson]:
    out: list[FoundPerson] = []

    def handle(node, implied_title: str | None = None):
        if not isinstance(node, dict):
            return
        types = node.get("@type")
        types = [types] if isinstance(types, str) else (types or [])
        types_l = [str(t).lower() for t in types]
        if "person" in types_l:
            name = node.get("name")
            if isinstance(name, dict):
                name = name.get("name")
            if isinstance(name, str):
                title = node.get("jobTitle") or implied_title
                if isinstance(title, list):
                    title = title[0] if title else None
                sameas = node.get("sameAs")
                li = None
                if isinstance(sameas, str) and "linkedin.com" in sameas:
                    li = sameas
                elif isinstance(sameas, list):
                    li = next((s for s in sameas if isinstance(s, str)
                               and "linkedin.com" in s), None)
                p = _mk_person(name, title if isinstance(title, str) else None,
                               source_url, "website_structured_data", 0.8, li)
                if p:
                    out.append(p)
        for key, implied in (("founder", "Founder"), ("employee", None),
                             ("member", None), ("author", None), ("owner", "Owner")):
            val = node.get(key)
            if isinstance(val, dict):
                handle(val, implied)
            elif isinstance(val, list):
                for v in val:
                    handle(v, implied)

    for item in jsonld:
        handle(item)
    return out


# --------------------------------------------------------------------------
# 2. DOM cards
# --------------------------------------------------------------------------

_CARD_SELECTORS = [
    "[class*=team]", "[class*=staff]", "[class*=member]", "[class*=person]",
    "[class*=bio]", "[class*=profile]", "[class*=employee]", "[class*=leader]",
    "[class*=founder]", "[class*=owner]", "[class*=agent]", "[class*=attorney]",
    "[class*=doctor]", "[class*=provider]", "[itemtype*=Person]",
]


def people_from_dom(soup: BeautifulSoup, source_url: str,
                    source_type: str) -> list[FoundPerson]:
    out: list[FoundPerson] = []
    seen: set[str] = set()
    candidates: list[Tag] = []
    for sel in _CARD_SELECTORS:
        try:
            candidates.extend(soup.select(sel))
        except Exception:
            continue
    # Also treat heading+following-sibling pairs as cards.
    for h in soup.find_all(["h2", "h3", "h4", "h5", "strong", "b"]):
        candidates.append(h)

    for node in candidates[:600]:
        text = node.get_text(" ", strip=True)
        if not text or len(text) > 600:
            continue
        person = _person_from_block(node, text, source_url, source_type)
        if person and person.full_name.lower() not in seen:
            seen.add(person.full_name.lower())
            out.append(person)
    return out


def _person_from_block(node: Tag, text: str, source_url: str,
                       source_type: str) -> FoundPerson | None:
    linkedin = None
    for a in node.find_all("a", href=True):
        if "linkedin.com/in/" in a["href"]:
            linkedin = a["href"].split("?")[0]
            break

    # Structured pair inside the card: heading = name, sibling = title (or vice versa)
    name_el = node.find(["h1", "h2", "h3", "h4", "h5", "strong", "b"])
    if name_el:
        candidate_name = name_el.get_text(" ", strip=True)
        if looks_like_person_name(candidate_name):
            title = _title_from_siblings(node, name_el)
            if title is None:
                rest = text.replace(candidate_name, " ", 1)
                title = _first_title_in(_strip_link_labels(node, rest))
            p = _mk_person(candidate_name, title, source_url, source_type, 0.6, linkedin)
            if p:
                return p

    # Fall back to "Name, Title" inside the block text
    return _person_from_text_snippet(text, source_url, source_type, linkedin)


def _title_from_siblings(node: Tag, name_el: Tag) -> str | None:
    """Prefer the title from its own element.

    A team card is usually <h3>Name</h3><p>Title</p><a>LinkedIn</a>. Reading the
    card's concatenated text instead would yield "Owner & President LinkedIn",
    so take each candidate element's own text and skip links entirely.
    """
    for el in node.find_all(["p", "span", "div", "li", "h4", "h5", "h6", "em", "small"],
                            recursive=True, limit=25):
        if el is name_el or name_el in el.parents:
            continue
        if el.find("a") is not None and not el.get_text(strip=True).replace(
                el.find("a").get_text(strip=True), "").strip():
            continue  # element is just a link
        candidate = el.get_text(" ", strip=True)
        if not candidate or len(candidate) > 90:
            continue
        cleaned = _strip_link_labels(node, candidate)
        cleaned = cleaned.strip(" ,.-–—|·•")
        if 2 < len(cleaned) <= 80 and classify_title(cleaned)[0]:
            return cleaned
    return None


def _strip_link_labels(node: Tag, text: str) -> str:
    """Remove anchor text (LinkedIn, Email, Read Bio, ...) from a title candidate."""
    for a in node.find_all("a"):
        label = a.get_text(" ", strip=True)
        if label and len(label) <= 40:
            text = text.replace(label, " ")
    text = re.sub(r"\b(linkedin|twitter|facebook|instagram|email|e-?mail|"
                  r"read (?:more|bio)|view (?:profile|bio)|contact|profile|bio)\b",
                  " ", text, flags=re.I)
    return re.sub(r"\s+", " ", text).strip()


def _first_title_in(text: str) -> str | None:
    for chunk in re.split(r"[,–—\-|•·\n]", text):
        chunk = chunk.strip()
        if 2 < len(chunk) <= 80 and classify_title(chunk)[0]:
            return chunk
    return None


# Vocabulary that legitimately appears inside a job title. Anything left over
# after removing these is a candidate for "this title swallowed a name".
_TITLE_VOCAB = {
    "owner", "co", "coowner", "proprietor", "principal", "principals", "founder",
    "founders", "cofounder", "managing", "member", "members", "partner",
    "partners", "sole", "chief", "executive", "executives", "officer", "ceo",
    "coo", "cfo", "cto", "cmo", "cio", "cro", "president", "vice", "vp", "evp",
    "svp", "general", "manager", "management", "head", "director", "directors",
    "supervisor", "foreman", "lead", "leader", "specialist", "coordinator",
    "technician", "representative", "associate", "assistant", "analyst",
    "engineer", "administrator", "estimator", "consultant", "agent", "attorney",
    "dentist", "doctor", "operations", "operating", "sales", "marketing",
    "finance", "financial", "service", "services", "human", "resources",
    "business", "development", "project", "product", "senior", "junior",
    "regional", "national", "global", "deputy", "interim", "acting", "board",
    "chair", "chairman", "chairwoman", "treasurer", "secretary", "controller",
    "technology", "technical", "information", "revenue", "customer", "client",
    "account", "accounts", "field", "branch", "district", "area", "territory",
    "and", "of", "the", "for", "at", "to", "in", "&", "/", "-", "jr", "sr",
}


def _title_is_clean(title: str) -> bool:
    """Reject a 'title' that has swallowed a second person's name.

    On a team page the cards run together in the extracted text
    ("Tom Alvarez Operations Manager Priya Nair Chief Financial Officer"), so a
    naive match pairs a person with the NEXT card's name and title.

    Job-title vocabulary is removed first, because plenty of real titles are two
    capitalised words ("Operations Manager") and would otherwise look like a
    name. What remains must not contain a name-shaped pair.
    """
    if not title:
        return False
    stripped = _strip_title_noise(title)
    residual_tokens = [
        t for t in re.split(r"[^A-Za-z'’\-]+", stripped)
        if t and t.lower().strip("-'") not in _TITLE_VOCAB
    ]
    if len(residual_tokens) < 2:
        return True
    # Two or more consecutive leftover capitalised words = an embedded name.
    run: list[str] = []
    for token in residual_tokens:
        if token[:1].isupper():
            run.append(token)
            if len(run) >= 2 and looks_like_person_name(" ".join(run[-2:])):
                return False
        else:
            run = []
    return True


_TITLE_NOISE_RE = re.compile(
    r"\b(linkedin|twitter|facebook|instagram|email|e-?mail|read (?:more|bio)|"
    r"view (?:profile|bio)|contact|profile|bio)\b", re.I)


def _strip_title_noise(title: str) -> str:
    return re.sub(r"\s+", " ", _TITLE_NOISE_RE.sub(" ", title)).strip(" ,.-–—|·•")


def _person_from_text_snippet(text: str, source_url: str, source_type: str,
                              linkedin: str | None = None) -> FoundPerson | None:
    m = NAME_THEN_TITLE_RE.search(text)
    if m and classify_title(m.group(2))[0] and _title_is_clean(m.group(2)):
        p = _mk_person(m.group(1), m.group(2), source_url, source_type, 0.6, linkedin)
        if p:
            return p
    m = TITLE_THEN_NAME_RE.search(text)
    if m and classify_title(m.group(1))[0] and _title_is_clean(m.group(1)):
        p = _mk_person(m.group(2), m.group(1), source_url, source_type, 0.6, linkedin)
        if p:
            return p
    return None


# --------------------------------------------------------------------------
# 3. Free text
# --------------------------------------------------------------------------

def people_from_text(text: str, source_url: str, source_type: str,
                     limit: int = 40) -> list[FoundPerson]:
    out: list[FoundPerson] = []
    seen: set[str] = set()
    # Work line-by-line: titles and names are usually adjacent.
    lines = [ln.strip() for ln in re.split(r"[\n\r]+|(?<=[.!?])\s{2,}", text) if ln.strip()]
    for i, line in enumerate(lines):
        if len(line) > 400:
            continue
        person = _person_from_text_snippet(line, source_url, source_type)
        if person is None and i + 1 < len(lines):
            # "John Smith" on one line, "Owner" on the next
            nxt = lines[i + 1]
            if looks_like_person_name(line) and len(nxt) <= 80 and classify_title(nxt)[0]:
                person = _mk_person(line, nxt, source_url, source_type, 0.55)
        if person and person.full_name.lower() not in seen:
            seen.add(person.full_name.lower())
            out.append(person)
            if len(out) >= limit:
                break
    return out


# --------------------------------------------------------------------------
# Merge
# --------------------------------------------------------------------------

def merge_people(groups: list[list[FoundPerson]]) -> list[FoundPerson]:
    """Deduplicate by normalised name, keeping the highest-confidence record
    and filling in a missing title/linkedin from lower-confidence duplicates."""
    best: dict[str, FoundPerson] = {}
    for group in groups:
        for p in group:
            key = re.sub(r"[^a-z]", "", p.full_name.lower())
            if not key:
                continue
            cur = best.get(key)
            if cur is None:
                best[key] = p
                continue
            if p.confidence > cur.confidence:
                p.job_title = p.job_title or cur.job_title
                p.seniority = p.seniority or cur.seniority
                p.is_decision_maker = p.is_decision_maker or cur.is_decision_maker
                p.linkedin_url = p.linkedin_url or cur.linkedin_url
                best[key] = p
            else:
                cur.job_title = cur.job_title or p.job_title
                cur.seniority = cur.seniority or p.seniority
                cur.is_decision_maker = cur.is_decision_maker or p.is_decision_maker
                cur.linkedin_url = cur.linkedin_url or p.linkedin_url
    ordered = sorted(best.values(),
                     key=lambda x: (0 if x.is_decision_maker else 1, -x.confidence))
    return ordered

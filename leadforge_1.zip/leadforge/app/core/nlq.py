"""Natural-language search parsing.

Turns strings like:
    "HVAC companies in Pennsylvania"
    "Roofing companies with 10-100 employees in Pennsylvania"
    "Trucking companies in Texas with $1M-$25M estimated revenue"
    "dental practices within 25 miles of 19103 founded after 2010"
into a SearchCriteria, and explains in plain English what it understood so the
user can confirm or correct it.
"""
from __future__ import annotations

import re

from ..schemas import SearchCriteria
from .normalize import parse_money
from .taxonomy import (
    US_STATES,
    find_industry,
    load_industries,
    normalize_country,
    normalize_state,
)

_NUM = r"\d[\d,]*(?:\.\d+)?"
_MONEY = rf"\$?\s*{_NUM}\s*(?:k|m|mm|b|bn|thousand|million|billion)?"

EMPLOYEE_RANGE_RE = re.compile(
    rf"\b({_NUM})\s*(?:-|–|—|to|through)\s*({_NUM})\s*"
    r"(?:\+)?\s*(?:employees?|staff|people|headcount|workers?|fte)\b", re.I)
EMPLOYEE_MIN_RE = re.compile(
    rf"\b(?:more than|over|at least|minimum(?: of)?|>=?|\+)\s*({_NUM})\s*"
    r"(?:employees?|staff|people|headcount|workers?)\b", re.I)
EMPLOYEE_MAX_RE = re.compile(
    rf"\b(?:fewer than|less than|under|up to|at most|maximum(?: of)?|<=?)\s*({_NUM})\s*"
    r"(?:employees?|staff|people|headcount|workers?)\b", re.I)
EMPLOYEE_PLUS_RE = re.compile(
    rf"\b({_NUM})\s*\+\s*(?:employees?|staff|people|headcount|workers?)\b", re.I)
EMPLOYEE_EXACT_RE = re.compile(
    rf"\b(?:with|having)?\s*({_NUM})\s*(?:employees?|staff|people|headcount|workers?)\b", re.I)

REVENUE_RANGE_RE = re.compile(
    rf"({_MONEY})\s*(?:-|–|—|to|through)\s*({_MONEY})\s*"
    r"(?:in\s+)?(?:estimated\s+|annual\s+|yearly\s+)?(?:revenue|sales|turnover|income)?", re.I)
REVENUE_MIN_RE = re.compile(
    rf"\b(?:more than|over|above|at least|minimum(?: of)?|>=?)\s*({_MONEY})\s*"
    r"(?:in\s+)?(?:estimated\s+|annual\s+)?(?:revenue|sales|turnover)\b", re.I)
REVENUE_MAX_RE = re.compile(
    rf"\b(?:less than|under|below|up to|at most|maximum(?: of)?|<=?)\s*({_MONEY})\s*"
    r"(?:in\s+)?(?:estimated\s+|annual\s+)?(?:revenue|sales|turnover)\b", re.I)

RADIUS_RE = re.compile(
    r"\bwithin\s+(\d{1,4})\s*(?:mi|mile|miles|km|kilometers?)\s*(?:of|from|around)?\b", re.I)
ZIP_RE = re.compile(r"\b(\d{5})(?:-\d{4})?\b")
NAICS_RE = re.compile(r"\bnaics\s*(?:code)?\s*[:#]?\s*(\d{2,6})\b", re.I)
SIC_RE = re.compile(r"\bsic\s*(?:code)?\s*[:#]?\s*(\d{2,4})\b", re.I)

FOUNDED_AFTER_RE = re.compile(
    r"\b(?:founded|established|est\.?|started|in business)\s*(?:after|since|from|>|>=)\s*"
    r"(1[89]\d{2}|20[0-2]\d)\b", re.I)
FOUNDED_BEFORE_RE = re.compile(
    r"\b(?:founded|established|est\.?|started)\s*(?:before|prior to|<|<=)\s*"
    r"(1[89]\d{2}|20[0-2]\d)\b", re.I)
FOUNDED_RANGE_RE = re.compile(
    r"\b(?:founded|established)\s*(?:between)?\s*(1[89]\d{2}|20[0-2]\d)\s*"
    r"(?:-|–|to|and)\s*(1[89]\d{2}|20[0-2]\d)\b", re.I)

LOCATIONS_RE = re.compile(
    rf"\b(?:with\s+)?({_NUM})\s*(?:\+|or more)?\s*locations?\b", re.I)
FRANCHISE_RE = re.compile(r"\b(franchise[sd]?|franchising)\b", re.I)
INDEPENDENT_RE = re.compile(r"\b(independent(?:ly owned)?|non-?franchise|family[- ]owned)\b", re.I)

COUNTRY_RE = re.compile(
    r"\bin\s+(united states|usa|us|canada|united kingdom|uk|australia|ireland|"
    r"new zealand|germany)\b", re.I)

# "10,000 businesses" and "10000 HVAC businesses" alike: allow a few words between.
TARGET_RE = re.compile(
    rf"\b({_NUM})\s+(?:[A-Za-z&'\-]+\s+){{0,3}}(?:businesses|companies|firms|leads|"
    r"results|records|contractors|shops|practices)\b", re.I)
TARGET_PREFIX_RE = re.compile(
    rf"\b(?:top|first|up\s+to|about|around|target(?:ing)?|limit(?:\s+to)?|max(?:imum)?)\s+({_NUM})\b",
    re.I)

# Location phrases: "in Pennsylvania", "in Philadelphia, PA", "near Austin TX"
CITY_STATE_RE = re.compile(
    r"\b(?:in|near|around|throughout|across)\s+"
    r"([A-Z][A-Za-z.'\-]+(?:\s+[A-Z][A-Za-z.'\-]+){0,3})\s*(?:,\s*|\s+)([A-Z]{2})\b")

STOPWORDS = {
    "companies", "company", "business", "businesses", "firms", "firm", "shops",
    "contractors", "contractor", "services", "service", "providers", "provider",
    "agencies", "agency", "practices", "practice", "leads", "with", "and", "the",
    "in", "near", "around", "find", "get", "list", "of", "me", "all", "that",
    "have", "has", "a", "an", "for", "from", "to", "any", "show", "search",
    "top", "first", "best", "new", "local", "small", "medium", "large", "about",
    "around", "within", "miles", "mile", "employees", "employee", "revenue",
    "estimated", "annual", "founded", "established", "locations", "location",
    "please", "give", "want", "need", "looking", "target", "targeting", "limit",
    "maximum", "max", "records", "results", "list",
}


def parse_query(text: str, default_target: int = 500) -> tuple[SearchCriteria, str, list[str], int]:
    """Return (criteria, human interpretation, unparsed terms, target_count)."""
    original = text or ""
    working = " " + original.strip() + " "
    consumed: list[tuple[int, int]] = []
    parts: list[str] = []

    def take(match: re.Match | None) -> re.Match | None:
        if match:
            consumed.append((match.start(), match.end()))
        return match

    criteria = SearchCriteria()
    target = default_target

    # ---- result target ----
    m = take(TARGET_PREFIX_RE.search(working)) or take(TARGET_RE.search(working))
    if m:
        try:
            target = max(1, min(200_000, int(float(m.group(1).replace(",", "")))))
        except ValueError:
            pass

    # ---- codes ----
    m = take(NAICS_RE.search(working))
    if m:
        criteria.naics = m.group(1)
        parts.append(f"NAICS {criteria.naics}")
    m = take(SIC_RE.search(working))
    if m:
        criteria.sic = m.group(1)
        parts.append(f"SIC {criteria.sic}")

    # ---- employees ----
    m = take(EMPLOYEE_RANGE_RE.search(working))
    if m:
        criteria.employee_min = _int(m.group(1))
        criteria.employee_max = _int(m.group(2))
        parts.append(f"{criteria.employee_min}–{criteria.employee_max} employees")
    else:
        m = take(EMPLOYEE_PLUS_RE.search(working)) or take(EMPLOYEE_MIN_RE.search(working))
        if m:
            criteria.employee_min = _int(m.group(1))
            parts.append(f"{criteria.employee_min}+ employees")
        m2 = take(EMPLOYEE_MAX_RE.search(working))
        if m2:
            criteria.employee_max = _int(m2.group(1))
            parts.append(f"up to {criteria.employee_max} employees")
        if criteria.employee_min is None and criteria.employee_max is None:
            m3 = take(EMPLOYEE_EXACT_RE.search(working))
            if m3:
                n = _int(m3.group(1))
                criteria.employee_min = criteria.employee_max = n
                parts.append(f"{n} employees")

    # ---- revenue ----
    rev_context = re.search(r"(revenue|sales|turnover|arr|income)", working, re.I)
    if rev_context:
        window = working[max(0, rev_context.start() - 90): rev_context.end() + 40]
        offset = max(0, rev_context.start() - 90)
        m = REVENUE_RANGE_RE.search(window)
        if m:
            lo, hi = parse_money(_clean_money(m.group(1))), parse_money(_clean_money(m.group(2)))
            if lo and hi:
                criteria.revenue_min, criteria.revenue_max = lo, hi
                consumed.append((offset + m.start(), rev_context.end()))
                parts.append(f"revenue {_fmt_money(lo)}–{_fmt_money(hi)}")
        if criteria.revenue_min is None:
            m = REVENUE_MIN_RE.search(working)
            if m:
                criteria.revenue_min = parse_money(_clean_money(m.group(1)))
                take(m)
                parts.append(f"revenue over {_fmt_money(criteria.revenue_min)}")
            m = REVENUE_MAX_RE.search(working)
            if m:
                criteria.revenue_max = parse_money(_clean_money(m.group(1)))
                take(m)
                parts.append(f"revenue under {_fmt_money(criteria.revenue_max)}")

    # ---- founded ----
    m = take(FOUNDED_RANGE_RE.search(working))
    if m:
        criteria.founded_year_min, criteria.founded_year_max = int(m.group(1)), int(m.group(2))
        parts.append(f"founded {m.group(1)}–{m.group(2)}")
    else:
        m = take(FOUNDED_AFTER_RE.search(working))
        if m:
            criteria.founded_year_min = int(m.group(1))
            parts.append(f"founded {m.group(1)} or later")
        m = take(FOUNDED_BEFORE_RE.search(working))
        if m:
            criteria.founded_year_max = int(m.group(1))
            parts.append(f"founded before {m.group(1)}")

    # ---- locations count / franchise ----
    m = LOCATIONS_RE.search(working)
    if m and not re.search(r"\bin\s+\d", m.group(0)):
        criteria.locations_min = _int(m.group(1))
        take(m)
        parts.append(f"{criteria.locations_min}+ locations")
    if take(FRANCHISE_RE.search(working)):
        criteria.franchise_status = "franchise"
        parts.append("franchises")
    elif take(INDEPENDENT_RE.search(working)):
        criteria.franchise_status = "independent"
        parts.append("independent businesses")

    # ---- radius ----
    m = take(RADIUS_RE.search(working))
    if m:
        criteria.radius_miles = float(m.group(1))
        parts.append(f"within {int(criteria.radius_miles)} miles")

    # ---- country ----
    m = take(COUNTRY_RE.search(working))
    if m:
        criteria.country = normalize_country(m.group(1))

    # ---- ZIP ----
    for zm in ZIP_RE.finditer(working):
        if _overlaps(zm.start(), zm.end(), consumed):
            continue
        criteria.postal_code = zm.group(1)
        consumed.append((zm.start(), zm.end()))
        parts.append(f"ZIP {criteria.postal_code}")
        break

    # ---- city, state ----
    m = CITY_STATE_RE.search(working)
    if m and normalize_state(m.group(2)):
        criteria.city = m.group(1).strip()
        criteria.state = normalize_state(m.group(2))
        consumed.append((m.start(), m.end()))
        parts.append(f"{criteria.city}, {criteria.state}")

    # ---- bare state name / abbreviation ----
    if not criteria.state:
        for abbr, full in US_STATES.items():
            pattern = re.compile(rf"\b(?:in|near|across|throughout)\s+({re.escape(full)})\b", re.I)
            sm = pattern.search(working)
            if sm:
                criteria.state = abbr
                consumed.append((sm.start(1), sm.end(1)))
                parts.append(full)
                break
        else:
            sm = re.search(r"\b(?:in|near|across)\s+([A-Z]{2})\b", working)
            if sm and normalize_state(sm.group(1)):
                criteria.state = normalize_state(sm.group(1))
                consumed.append((sm.start(1), sm.end(1)))
                parts.append(US_STATES[criteria.state])

    # ---- bare city ----
    if not criteria.city and (criteria.state or criteria.postal_code is None):
        cm = re.search(r"\b(?:in|near|around)\s+([A-Z][A-Za-z.'\-]+(?:\s+[A-Z][A-Za-z.'\-]+){0,2})\b",
                       working)
        if cm and not _overlaps(cm.start(1), cm.end(1), consumed):
            candidate = cm.group(1).strip()
            if normalize_state(candidate):
                criteria.state = normalize_state(candidate)
                parts.append(US_STATES[criteria.state])
            elif candidate.lower() not in STOPWORDS:
                criteria.city = candidate
                parts.append(candidate)
            consumed.append((cm.start(1), cm.end(1)))

    # ---- industry ----
    residual = _residual(working, consumed)
    industry = find_industry(residual) or find_industry(original)
    if industry:
        criteria.industry = industry.key
        criteria.sub_industry = industry.sub_industry
        criteria.naics = criteria.naics or industry.naics
        criteria.sic = criteria.sic or industry.sic
        parts.insert(0, industry.name)
        for kw in industry.keywords + [industry.name.lower(), industry.key.replace("_", " ")]:
            residual = re.sub(rf"\b{re.escape(kw)}\b", " ", residual, flags=re.I)

    # ---- leftover keywords ----
    leftovers = [w for w in re.split(r"[^A-Za-z0-9&'\-]+", residual)
                 if w and w.lower() not in STOPWORDS and len(w) > 2
                 and not w.isdigit()]
    seen: set[str] = set()
    keywords = []
    for w in leftovers:
        lw = w.lower()
        if lw in seen:
            continue
        seen.add(lw)
        keywords.append(w)
    criteria.keywords = keywords[:8]
    if not industry and keywords:
        parts.insert(0, " ".join(keywords[:4]))

    if criteria.postal_code and not criteria.radius_miles:
        criteria.radius_miles = criteria.radius_miles or 25.0

    interpretation = _build_interpretation(criteria, parts, target)
    unparsed = [w for w in keywords if not industry][:8]
    return criteria, interpretation, unparsed, target


def _build_interpretation(c: SearchCriteria, parts: list[str], target: int) -> str:
    industries = {i.key: i for i in load_industries()}
    what = industries[c.industry].name if c.industry in industries else (
        " ".join(c.keywords[:4]) or "businesses")
    where_bits = [b for b in (c.city, c.postal_code,
                              US_STATES.get(c.state or "", c.state)) if b]
    where = ", ".join(where_bits) or c.country
    radius_label = f"within {int(c.radius_miles)} miles" if c.radius_miles else None
    if radius_label and (c.postal_code or c.city):
        where_phrase = f"{radius_label} of {where}"
    else:
        where_phrase = f"in {where}"

    drop = {what, where, radius_label, *where_bits}
    if c.postal_code:
        drop.add(f"ZIP {c.postal_code}")
    if c.city and c.state:
        drop.add(f"{c.city}, {c.state}")
    filters = [p for p in parts if p and p not in drop]
    tail = f", filtered to {', '.join(dict.fromkeys(filters))}" if filters else ""
    return (f"Searching for up to {target:,} {what} businesses {where_phrase}{tail}. "
            f"A lead counts as qualified only with both a live website and a "
            f"real business email.")


def _residual(text: str, consumed: list[tuple[int, int]]) -> str:
    if not consumed:
        return text
    chars = list(text)
    for start, end in consumed:
        for i in range(max(0, start), min(len(chars), end)):
            chars[i] = " "
    return "".join(chars)


def _overlaps(start: int, end: int, spans: list[tuple[int, int]]) -> bool:
    return any(not (end <= s or start >= e) for s, e in spans)


def _int(value: str) -> int | None:
    try:
        return int(float(value.replace(",", "")))
    except (TypeError, ValueError):
        return None


def _clean_money(value: str) -> str:
    return re.sub(r"[\s$]", "", value or "")


def _fmt_money(value: float | None) -> str:
    if value is None:
        return "?"
    if value >= 1e9:
        return f"${value / 1e9:.9g}B".replace(".0B", "B")
    if value >= 1e6:
        return f"${value / 1e6:.9g}M".replace(".0M", "M")
    if value >= 1e3:
        return f"${value / 1e3:.9g}K".replace(".0K", "K")
    return f"${value:,.0f}"

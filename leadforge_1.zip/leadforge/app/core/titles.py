"""Job-title parsing: seniority and decision-maker classification (Tier 1)."""
from __future__ import annotations

import re

# Ordered most-senior first; first match wins.
TITLE_RULES: list[tuple[str, str, bool, list[str]]] = [
    # (seniority, canonical_label, is_decision_maker, patterns)
    ("owner", "Owner", True, [
        r"\bowner\b", r"\bco[- ]?owner\b", r"\bproprietor\b", r"\bprincipal\b",
        r"\bfounder\b", r"\bco[- ]?founder\b", r"\bmanaging member\b",
        r"\bmanaging partner\b", r"\bmanaging director\b", r"\bmanaging principal\b",
        r"\bpartner\b", r"\bsole proprietor\b",
    ]),
    ("c_level", "CEO", True, [
        r"\bchief executive officer\b", r"\bc\.?e\.?o\.?\b",
    ]),
    ("c_level", "President", True, [
        r"\bpresident\b(?!.*\bvice\b)", r"\bpres\.\b",
    ]),
    ("c_level", "COO", True, [
        r"\bchief operating officer\b", r"\bc\.?o\.?o\.?\b",
    ]),
    ("c_level", "CFO", True, [
        r"\bchief financial officer\b", r"\bc\.?f\.?o\.?\b", r"\bcontroller\b",
    ]),
    ("c_level", "CTO", True, [
        r"\bchief technology officer\b", r"\bchief technical officer\b", r"\bc\.?t\.?o\.?\b",
    ]),
    ("c_level", "CMO", True, [
        r"\bchief marketing officer\b", r"\bc\.?m\.?o\.?\b",
    ]),
    ("c_level", "Chief Officer", True, [
        r"\bchief\s+\w+\s+officer\b", r"\bc[a-z]o\b(?= officer)",
    ]),
    ("c_level", "General Manager", True, [
        r"\bgeneral manager\b", r"\bgm\b",
    ]),
    ("vp", "Vice President", True, [
        r"\bvice president\b", r"\bv\.?p\.?\b", r"\bevp\b", r"\bsvp\b",
    ]),
    ("director", "Director", False, [
        r"\bdirector\b", r"\bhead of\b",
    ]),
    ("manager", "Manager", False, [
        r"\bmanager\b", r"\bsupervisor\b", r"\bforeman\b", r"\blead\b",
    ]),
    ("staff", "Staff", False, [
        r"\bspecialist\b", r"\bcoordinator\b", r"\btechnician\b", r"\brepresentative\b",
        r"\bassociate\b", r"\bassistant\b", r"\banalyst\b", r"\bengineer\b",
        r"\badministrator\b", r"\bestimator\b", r"\bconsultant\b", r"\bagent\b",
        r"\battorney\b", r"\bdentist\b", r"\bdoctor\b", r"\bd\.?d\.?s\.?\b",
    ]),
]

_COMPILED = [
    (sen, label, dm, [re.compile(p, re.I) for p in pats])
    for sen, label, dm, pats in TITLE_RULES
]

# Words that indicate the string is not a job title at all.
_NON_TITLE = re.compile(
    r"\b(read more|learn more|contact us|our team|about us|home|privacy|terms|"
    r"copyright|all rights reserved|menu|search|login|sign in)\b", re.I
)


def classify_title(title: str | None) -> tuple[str | None, str | None, bool]:
    """Return (seniority, canonical_label, is_decision_maker)."""
    if not title:
        return None, None, False
    t = title.strip()
    if not t or len(t) > 120 or _NON_TITLE.search(t):
        return None, None, False
    for seniority, label, is_dm, patterns in _COMPILED:
        for pat in patterns:
            if pat.search(t):
                return seniority, label, is_dm
    return None, None, False


def is_decision_maker_title(title: str | None) -> bool:
    return classify_title(title)[2]


def looks_like_title(text: str | None) -> bool:
    return classify_title(text)[0] is not None

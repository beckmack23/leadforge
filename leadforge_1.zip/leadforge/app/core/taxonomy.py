"""Industry taxonomy + US geography lookups."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache

from ..config import DATA_DIR


@dataclass
class Industry:
    key: str
    name: str
    sub_industry: str
    naics: str
    sic: str
    keywords: list[str] = field(default_factory=list)
    osm: list[str] = field(default_factory=list)


@lru_cache
def load_industries() -> list[Industry]:
    raw = json.loads((DATA_DIR / "industries.json").read_text())
    return [Industry(**{k: v for k, v in item.items() if k in Industry.__annotations__})
            for item in raw["industries"]]


@lru_cache
def industry_by_key() -> dict[str, Industry]:
    return {i.key: i for i in load_industries()}


def find_industry(text: str | None) -> Industry | None:
    """Best-effort industry match from free text (longest keyword wins)."""
    if not text:
        return None
    t = " " + text.lower().strip() + " "
    best: tuple[int, Industry] | None = None
    for ind in load_industries():
        if ind.key.replace("_", " ") in t or ind.name.lower() in t:
            score = len(ind.name)
            if best is None or score > best[0]:
                best = (score, ind)
        for kw in ind.keywords:
            if f" {kw} " in t or t.strip() == kw:
                score = len(kw)
                if best is None or score > best[0]:
                    best = (score, ind)
    return best[1] if best else None


def industry_choices() -> list[dict]:
    return [
        {"key": i.key, "name": i.name, "sub_industry": i.sub_industry,
         "naics": i.naics, "sic": i.sic}
        for i in sorted(load_industries(), key=lambda x: x.name)
    ]


# --------------------------------------------------------------------------
# US geography
# --------------------------------------------------------------------------

US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas",
    "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware",
    "DC": "District of Columbia", "FL": "Florida", "GA": "Georgia", "HI": "Hawaii",
    "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa",
    "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine",
    "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota",
    "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska",
    "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico",
    "NY": "New York", "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio",
    "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island",
    "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas",
    "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington",
    "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
    "PR": "Puerto Rico", "VI": "U.S. Virgin Islands", "GU": "Guam",
}

STATE_NAME_TO_ABBR = {v.lower(): k for k, v in US_STATES.items()}


def normalize_state(value: str | None) -> str | None:
    """'pennsylvania' | 'PA' | 'Pa.' -> 'PA'"""
    if not value:
        return None
    v = value.strip().strip(".").upper()
    if v in US_STATES:
        return v
    return STATE_NAME_TO_ABBR.get(value.strip().lower())


def state_full_name(abbr: str | None) -> str | None:
    if not abbr:
        return None
    return US_STATES.get(abbr.upper())


COUNTRY_ALIASES = {
    "us": "US", "usa": "US", "united states": "US", "united states of america": "US",
    "ca": "CA", "canada": "CA", "uk": "GB", "united kingdom": "GB", "gb": "GB",
    "au": "AU", "australia": "AU", "ie": "IE", "ireland": "IE",
    "nz": "NZ", "new zealand": "NZ", "de": "DE", "germany": "DE",
}


def normalize_country(value: str | None) -> str:
    if not value:
        return "US"
    return COUNTRY_ALIASES.get(value.strip().lower(), value.strip().upper()[:2])

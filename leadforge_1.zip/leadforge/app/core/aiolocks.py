"""Loop-scoped asyncio primitives.

A module-level ``asyncio.Lock()`` binds itself to the first event loop that
awaits it and then raises "is bound to a different event loop" for any other -
which bites whenever the process runs more than one loop (a test suite, an
embedded worker, a server reload). These helpers hand out one primitive per
running loop instead, so module-level singletons stay safe.
"""
from __future__ import annotations

import asyncio
import weakref

_locks: "weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, dict[str, asyncio.Lock]]" = (
    weakref.WeakKeyDictionary()
)
_semaphores: "weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, dict[str, asyncio.Semaphore]]" = (
    weakref.WeakKeyDictionary()
)


def lock(name: str) -> asyncio.Lock:
    """Return the lock called ``name`` for the currently running event loop."""
    loop = asyncio.get_running_loop()
    bucket = _locks.get(loop)
    if bucket is None:
        bucket = {}
        _locks[loop] = bucket
    existing = bucket.get(name)
    if existing is None:
        existing = asyncio.Lock()
        bucket[name] = existing
    return existing


def semaphore(name: str, value: int) -> asyncio.Semaphore:
    """Return the semaphore called ``name`` for the currently running loop."""
    loop = asyncio.get_running_loop()
    bucket = _semaphores.get(loop)
    if bucket is None:
        bucket = {}
        _semaphores[loop] = bucket
    existing = bucket.get(name)
    if existing is None:
        existing = asyncio.Semaphore(value)
        bucket[name] = existing
    return existing

"""Polite async HTTP client.

Guarantees:
  * honours robots.txt for every crawl target (configurable, on by default)
  * per-host concurrency cap + minimum delay between requests to the same host
  * global concurrency cap
  * bounded response size, retries with backoff on transient failures
  * never follows a 401/403/paywall/CAPTCHA into a workaround - it just stops
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import httpx

from ..config import settings

log = logging.getLogger(__name__)

# Status codes that mean "you are being told not to do this". We stop, we do
# not retry aggressively, and we never attempt to work around them.
BLOCKED_STATUSES = {401, 402, 403, 407, 451}

CAPTCHA_MARKERS = (
    "captcha", "recaptcha", "hcaptcha", "cf-challenge", "are you a robot",
    "checking your browser", "verify you are human", "cf_chl_opt",
)


@dataclass
class FetchResult:
    url: str
    final_url: str
    status: int | None
    text: str | None
    content_type: str | None
    ok: bool
    reason: str = ""
    elapsed_ms: int = 0
    headers: dict = field(default_factory=dict)

    @property
    def is_html(self) -> bool:
        return bool(self.content_type and "html" in self.content_type.lower())


class HostThrottle:
    """One semaphore + last-hit clock per host."""

    def __init__(self) -> None:
        self._sems: dict[str, asyncio.Semaphore] = {}
        self._last: dict[str, float] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._guard = asyncio.Lock()

    async def _entry(self, host: str) -> tuple[asyncio.Semaphore, asyncio.Lock]:
        async with self._guard:
            if host not in self._sems:
                self._sems[host] = asyncio.Semaphore(settings.per_host_max_concurrency)
                self._locks[host] = asyncio.Lock()
            return self._sems[host], self._locks[host]

    async def acquire(self, host: str) -> asyncio.Semaphore:
        sem, lock = await self._entry(host)
        await sem.acquire()
        async with lock:
            last = self._last.get(host, 0.0)
            wait = settings.per_host_delay_seconds - (time.monotonic() - last)
            if wait > 0:
                await asyncio.sleep(wait + random.uniform(0, 0.25))
            self._last[host] = time.monotonic()
        return sem


class RobotsCache:
    def __init__(self) -> None:
        self._cache: dict[str, RobotFileParser | None] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._guard = asyncio.Lock()

    async def _lock_for(self, origin: str) -> asyncio.Lock:
        async with self._guard:
            self._locks.setdefault(origin, asyncio.Lock())
            return self._locks[origin]

    async def allowed(self, client: httpx.AsyncClient, url: str, ua: str) -> bool:
        if not settings.respect_robots:
            return True
        p = urlparse(url)
        origin = f"{p.scheme}://{p.netloc}"
        if origin not in self._cache:
            lock = await self._lock_for(origin)
            async with lock:
                if origin not in self._cache:
                    self._cache[origin] = await self._load(client, origin, ua)
        rp = self._cache[origin]
        if rp is None:
            return True  # no robots.txt or unreadable -> permitted by convention
        try:
            return rp.can_fetch(ua, url)
        except Exception:
            return True

    async def _load(self, client: httpx.AsyncClient, origin: str, ua: str):
        robots_url = urljoin(origin + "/", "robots.txt")
        try:
            r = await client.get(robots_url, timeout=10.0,
                                 headers={"User-Agent": ua}, follow_redirects=True)
        except Exception:
            return None
        if r.status_code != 200 or not r.text:
            return None
        rp = RobotFileParser()
        try:
            rp.parse(r.text.splitlines())
        except Exception:
            return None
        return rp

    def crawl_delay(self, url: str, ua: str) -> float | None:
        p = urlparse(url)
        rp = self._cache.get(f"{p.scheme}://{p.netloc}")
        if rp is None:
            return None
        try:
            d = rp.crawl_delay(ua)
            return float(d) if d else None
        except Exception:
            return None


class PoliteClient:
    """Shared crawler client. One instance per process (see get_client())."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self.throttle = HostThrottle()
        self.robots = RobotsCache()
        self._global_sem = asyncio.Semaphore(settings.global_max_concurrency)
        self.stats = {"requests": 0, "blocked_by_robots": 0, "errors": 0, "bytes": 0}

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(
                follow_redirects=True,
                timeout=httpx.Timeout(settings.http_timeout_seconds),
                limits=httpx.Limits(max_connections=settings.global_max_concurrency * 2,
                                    max_keepalive_connections=40),
                headers={
                    "User-Agent": settings.effective_user_agent,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.9",
                },
            )

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @property
    def raw(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("PoliteClient not started")
        return self._client

    # ---------------- crawling ----------------

    async def fetch(self, url: str, *, method: str = "GET",
                    check_robots: bool = True, max_bytes: int | None = None,
                    headers: dict | None = None,
                    max_retries: int | None = None,
                    timeout: float | None = None) -> FetchResult:
        await self.start()
        started = time.monotonic()
        retries = settings.max_retries if max_retries is None else max_retries
        ua = settings.effective_user_agent
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return FetchResult(url, url, None, None, None, False, "invalid_url")

        if check_robots and not await self.robots.allowed(self.raw, url, ua):
            self.stats["blocked_by_robots"] += 1
            return FetchResult(url, url, None, None, None, False, "robots_disallowed")

        max_bytes = max_bytes or settings.max_html_bytes
        host = parsed.netloc
        delay = self.robots.crawl_delay(url, ua)

        async with self._global_sem:
            sem = await self.throttle.acquire(host)
            try:
                if delay and delay > settings.per_host_delay_seconds:
                    await asyncio.sleep(min(delay, 10.0))
                last_exc = ""
                for attempt in range(retries + 1):
                    try:
                        req_headers = dict(headers or {})
                        async with self.raw.stream(method, url, headers=req_headers,
                                                   timeout=timeout or settings.http_timeout_seconds
                                                   ) as resp:
                            status = resp.status_code
                            ctype = resp.headers.get("content-type", "")
                            if status in BLOCKED_STATUSES:
                                await resp.aclose()
                                return FetchResult(url, str(resp.url), status, None, ctype,
                                                   False, "access_denied",
                                                   int((time.monotonic() - started) * 1000))
                            if status == 429 or 500 <= status < 600:
                                await resp.aclose()
                                if attempt < retries:
                                    await asyncio.sleep(2 ** attempt + random.uniform(0, 1))
                                    continue
                                return FetchResult(url, str(resp.url), status, None, ctype,
                                                   False, f"http_{status}",
                                                   int((time.monotonic() - started) * 1000))
                            if status >= 400:
                                await resp.aclose()
                                return FetchResult(url, str(resp.url), status, None, ctype,
                                                   False, f"http_{status}",
                                                   int((time.monotonic() - started) * 1000))

                            chunks: list[bytes] = []
                            total = 0
                            async for chunk in resp.aiter_bytes():
                                chunks.append(chunk)
                                total += len(chunk)
                                if total > max_bytes:
                                    break
                            body = b"".join(chunks)
                            self.stats["requests"] += 1
                            self.stats["bytes"] += total
                            try:
                                text = body.decode(resp.encoding or "utf-8", errors="replace")
                            except (LookupError, TypeError):
                                text = body.decode("utf-8", errors="replace")

                            low = text[:4000].lower()
                            if any(m in low for m in CAPTCHA_MARKERS):
                                # A challenge page. We stop here by design.
                                return FetchResult(url, str(resp.url), status, None, ctype,
                                                   False, "challenge_page",
                                                   int((time.monotonic() - started) * 1000))

                            return FetchResult(
                                url, str(resp.url), status, text, ctype, True, "",
                                int((time.monotonic() - started) * 1000),
                                dict(resp.headers),
                            )
                    except httpx.ConnectError as exc:
                        # Refused connection / DNS failure: not transient in the
                        # way a timeout is, and retrying just multiplies the wait
                        # when probing https on a host that only serves http.
                        last_exc = type(exc).__name__
                        break
                    except (httpx.TimeoutException, httpx.TransportError) as exc:
                        last_exc = type(exc).__name__
                        if attempt < retries:
                            await asyncio.sleep(1.5 ** attempt + random.uniform(0, 0.5))
                            continue
                    except Exception as exc:  # noqa: BLE001
                        last_exc = f"{type(exc).__name__}: {exc}"[:200]
                        break
                self.stats["errors"] += 1
                return FetchResult(url, url, None, None, None, False, last_exc or "failed",
                                   int((time.monotonic() - started) * 1000))
            finally:
                sem.release()

    async def head_or_get(self, url: str) -> FetchResult:
        """Cheap liveness probe used by website validation."""
        res = await self.fetch(url, method="GET", max_bytes=200_000)
        return res

    async def get_json(self, url: str, *, params: dict | None = None,
                       headers: dict | None = None, method: str = "GET",
                       json_body: Any = None, timeout: float | None = None) -> tuple[int, Any]:
        """API calls (not crawling): no robots check, no host delay."""
        await self.start()
        try:
            resp = await self.raw.request(
                method, url, params=params, headers=headers, json=json_body,
                timeout=timeout or settings.http_timeout_seconds,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("api call failed %s: %s", url, exc)
            return 0, {"error": str(exc)}
        try:
            return resp.status_code, resp.json()
        except Exception:
            return resp.status_code, {"raw": resp.text[:2000]}


_client: PoliteClient | None = None


def get_client() -> PoliteClient:
    global _client
    if _client is None:
        _client = PoliteClient()
    return _client


async def shutdown_client() -> None:
    global _client
    if _client is not None:
        await _client.close()
        _client = None

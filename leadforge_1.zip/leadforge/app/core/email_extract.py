"""Email discovery from public web pages.

Hard rule enforced here: **nothing in this module ever constructs an address.**
Every address returned was literally present on a page (as text, in a mailto:
link, or in structured data), or written for humans in an obfuscated-but-explicit
form such as "john (at) example (dot) com". There is no pattern generation,
no "first.last@domain" guessing, no permutation testing.
"""
from __future__ import annotations

import html
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse

from bs4 import BeautifulSoup

from ..config import DATA_DIR
from .normalize import extract_domain, name_tokens, registrable_domain

# --------------------------------------------------------------------------
# Reference lists
# --------------------------------------------------------------------------

def _load_list(filename: str) -> set[str]:
    path: Path = DATA_DIR / filename
    if not path.exists():
        return set()
    out = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip().lower()
        if line and not line.startswith("#"):
            out.add(line)
    return out


ROLE_ACCOUNTS = _load_list("role_accounts.txt")
DISPOSABLE_DOMAINS = _load_list("disposable_domains.txt")
FREE_PROVIDERS = _load_list("free_providers.txt")

# --------------------------------------------------------------------------
# Patterns
# --------------------------------------------------------------------------

EMAIL_RE = re.compile(
    r"(?<![A-Za-z0-9._%+\-])"
    r"([A-Za-z0-9](?:[A-Za-z0-9._%+\-]{0,62}[A-Za-z0-9])?)"
    r"@"
    r"((?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,24})"
    r"(?![A-Za-z0-9\-])"
)

# Human-readable obfuscation written *for people to read*, e.g.
#   "john (at) acme (dot) com" / "john [at] acme [dot] com" / "john AT acme DOT com"
#
# The separator must be explicitly marked. A bare lowercase "at" is NOT accepted:
# ordinary prose is full of it, and "Email us at office.bayside (at) gmail (dot)
# com" would otherwise parse as "us@office.bayside". Uppercase AT/DOT is accepted
# because writing it that way is itself the obfuscation convention.
_AT = (r"(?:\s*(?:\(\s*at\s*\)|\[\s*at\s*\]|\{\s*at\s*\}|&#40;\s*at\s*&#41;"
       r"|_at_|-at-|&#64;|@)\s*|(?-i:\s+AT\s+))")
_DOT = (r"(?:\s*(?:\(\s*dot\s*\)|\[\s*dot\s*\]|\{\s*dot\s*\}|&#40;\s*dot\s*&#41;"
        r"|_dot_|-dot-|\.)\s*|(?-i:\s+DOT\s+))")

OBFUSCATED_RE = re.compile(
    r"([A-Za-z0-9._%+\-]{1,64}?)"
    + _AT +
    r"((?:[A-Za-z0-9\-]{1,63}" + _DOT + r"){1,3}[A-Za-z]{2,24})",
    re.I,
)

# Addresses that are never real business contacts.
JUNK_LOCALPARTS = {
    "example", "test", "your", "youremail", "email", "name", "firstname",
    "lastname", "user", "username", "someone", "somebody", "yourname",
    "domain", "company", "yourcompany", "mail", "e-mail", "sentry", "wix",
    "u003e", "x", "a", "b", "core", "js", "font", "image", "img", "svg",
    "react", "vue", "angular", "node", "npm", "babel", "webpack", "types",
}

JUNK_DOMAINS = {
    "example.com", "example.org", "example.net", "domain.com", "yourdomain.com",
    "email.com", "test.com", "sentry.io", "sentry-cdn.com", "wixpress.com",
    "wix.com", "squarespace.com", "godaddy.com", "w3.org", "schema.org",
    "jquery.com", "googleapis.com", "gstatic.com", "cloudflare.com",
    "cloudflareinsights.com", "npmjs.com", "unpkg.com", "jsdelivr.net",
    "bootstrapcdn.com", "fontawesome.com", "typekit.net", "adobe.com",
    "placeholder.com", "yoursite.com", "mysite.com", "site.com", "company.com",
    "acme.com", "abc.com", "domain.tld", "localhost", "email.tld",
}

# Extensions that show up when a filename gets caught by the email regex
FILE_EXT_TAIL = re.compile(
    r"\.(png|jpe?g|gif|svg|webp|ico|css|js|json|xml|woff2?|ttf|eot|mp4|webm|pdf)$", re.I
)

# Sentinel local-parts injected by tracking pixels / hashed identifiers
HEXISH_RE = re.compile(r"^[0-9a-f]{16,}$", re.I)

# --------------------------------------------------------------------------
# Page classification
# --------------------------------------------------------------------------

PAGE_PATTERNS: list[tuple[str, tuple[str, ...]]] = [
    ("contact", ("contact", "contact-us", "contactus", "get-in-touch", "reach-us",
                 "reach-out", "connect", "inquiry", "enquiries", "request-quote",
                 "free-estimate", "get-a-quote", "schedule")),
    ("about", ("about", "about-us", "aboutus", "who-we-are", "our-story",
               "company", "our-company", "history", "mission")),
    ("team", ("team", "our-team", "meet-the-team", "staff", "our-staff",
              "people", "our-people", "employees", "crew", "technicians",
              "attorneys", "doctors", "agents", "providers", "professionals")),
    ("leadership", ("leadership", "management", "executive", "executives",
                    "board", "founders", "owners", "ownership", "principals",
                    "partners", "meet-the-owner", "our-founder")),
    ("locations", ("location", "locations", "our-locations", "branches",
                   "offices", "service-area", "service-areas", "areas-we-serve",
                   "coverage")),
    ("careers", ("career", "careers", "jobs", "job-openings", "employment",
                 "join-our-team", "join-us", "work-with-us", "now-hiring",
                 "hiring", "open-positions", "opportunities")),
    ("news", ("news", "blog", "press", "press-releases", "newsroom", "media",
              "updates", "announcements", "articles", "insights")),
    ("services", ("service", "services", "what-we-do", "solutions", "products",
                  "capabilities", "industries", "expertise")),
]

# Order pages are crawled in: highest email yield first.
PAGE_PRIORITY = ["contact", "about", "team", "leadership", "locations",
                 "careers", "news", "services"]

_SKIP_URL_RE = re.compile(
    r"\.(pdf|jpe?g|png|gif|svg|webp|zip|docx?|xlsx?|pptx?|mp4|mp3|avi|dmg|exe)$"
    r"|/wp-(admin|login|json)|/cart|/checkout|/my-account|/login|/signin|/register"
    r"|/privacy|/terms|/sitemap|/feed|/rss|/tag/|/category/|/author/|/wp-content/"
    r"|/cdn-cgi/|#",
    re.I,
)


def classify_page(url: str, link_text: str = "") -> str | None:
    """Return one of PAGE_PRIORITY, or None if the link is not interesting."""
    try:
        path = urlparse(url).path.lower()
    except ValueError:
        return None
    haystack_path = re.sub(r"[^a-z0-9]+", "-", path).strip("-")
    haystack_text = re.sub(r"[^a-z0-9]+", "-", (link_text or "").lower()).strip("-")
    for kind, keys in PAGE_PATTERNS:
        for k in keys:
            if re.search(rf"(^|-|/){re.escape(k)}(-|/|$)", haystack_path):
                return kind
            if haystack_text and re.fullmatch(rf"(our-|meet-the-)?{re.escape(k)}s?", haystack_text):
                return kind
    return None


def should_skip_url(url: str) -> bool:
    return bool(_SKIP_URL_RE.search(url))


# --------------------------------------------------------------------------
# Extraction
# --------------------------------------------------------------------------

@dataclass
class FoundEmail:
    address: str
    local_part: str
    domain: str
    method: str          # mailto_link | page_text | deobfuscated_text | structured_data
    source_url: str
    context: str = ""    # surrounding text, used for name/title association
    confidence: float = 0.6


@dataclass
class PageExtract:
    url: str
    page_kind: str
    title: str = ""
    text: str = ""
    emails: list[FoundEmail] = field(default_factory=list)
    phones: list[str] = field(default_factory=list)
    links: list[tuple[str, str]] = field(default_factory=list)  # (abs_url, link_text)
    social: dict[str, str] = field(default_factory=dict)
    jsonld: list[dict] = field(default_factory=list)
    meta_description: str = ""
    # Parsed DOM, kept only while the crawler is working on this page so that
    # people-extraction can use structural cues. Dropped before storage.
    soup: object | None = field(default=None, repr=False, compare=False)


def _clean_candidate(local: str, domain: str) -> tuple[str, str] | None:
    local = local.strip(" .,;:<>()[]{}\"'").lower()
    domain = domain.strip(" .,;:<>()[]{}\"'").lower().rstrip(".")
    if not local or not domain:
        return None
    if FILE_EXT_TAIL.search(domain) or FILE_EXT_TAIL.search(local + "." + domain):
        return None
    if "." not in domain or len(domain) > 253:
        return None
    tld = domain.rsplit(".", 1)[-1]
    if len(tld) < 2 or not tld.isalpha():
        return None
    if len(local) > 64:
        return None
    if local in JUNK_LOCALPARTS or HEXISH_RE.match(local):
        return None
    reg = registrable_domain(domain)
    if reg in JUNK_DOMAINS or domain in JUNK_DOMAINS:
        return None
    # "2x@image" style artefacts
    if re.fullmatch(r"\d+x?", local):
        return None
    return local, domain


def _context_around(text: str, index: int, width: int = 160) -> str:
    start = max(0, index - width)
    end = min(len(text), index + width)
    return re.sub(r"\s+", " ", text[start:end]).strip()


def extract_emails_from_text(text: str, source_url: str, method: str = "page_text",
                             confidence: float = 0.6) -> list[FoundEmail]:
    out: list[FoundEmail] = []
    seen: set[str] = set()
    for m in EMAIL_RE.finditer(text):
        cleaned = _clean_candidate(m.group(1), m.group(2))
        if not cleaned:
            continue
        local, domain = cleaned
        addr = f"{local}@{domain}"  # reassembly-of-parsed-address
        if addr in seen:
            continue
        seen.add(addr)
        out.append(FoundEmail(addr, local, domain, method, source_url,
                              _context_around(text, m.start()), confidence))
    return out


def extract_obfuscated_emails(text: str, source_url: str) -> list[FoundEmail]:
    """Only handles obfuscation written for a human reader to retype."""
    out: list[FoundEmail] = []
    seen: set[str] = set()
    for m in OBFUSCATED_RE.finditer(text):
        local = m.group(1)
        domain_raw = m.group(2)
        domain = re.sub(_DOT, ".", domain_raw, flags=re.I)
        domain = re.sub(r"\s+", "", domain).strip(".")
        domain = re.sub(r"\.{2,}", ".", domain)
        cleaned = _clean_candidate(local, domain)
        if not cleaned:
            continue
        loc, dom = cleaned
        addr = f"{loc}@{dom}"  # reassembly-of-parsed-address
        if addr in seen or "." not in dom:
            continue
        seen.add(addr)
        out.append(FoundEmail(addr, loc, dom, "deobfuscated_text", source_url,
                              _context_around(text, m.start()), 0.55))
    return out


_SOCIAL_HOSTS = {
    "linkedin": ("linkedin.com",),
    "facebook": ("facebook.com", "fb.com", "fb.me"),
    "instagram": ("instagram.com",),
    "twitter": ("twitter.com", "x.com"),
    "youtube": ("youtube.com", "youtu.be"),
}


def parse_page(html_text: str, url: str, page_kind: str = "other") -> PageExtract:
    """Parse one fetched page into everything the pipeline needs from it."""
    soup = BeautifulSoup(html_text, "lxml")

    for tag in soup(["script", "style", "noscript", "template", "svg"]):
        # Keep JSON-LD scripts before dropping the rest.
        if tag.name == "script" and (tag.get("type") or "").lower() == "application/ld+json":
            continue
        tag.decompose()

    page = PageExtract(url=url, page_kind=page_kind)
    page.title = (soup.title.get_text(strip=True) if soup.title else "")[:300]

    md = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
    if md and md.get("content"):
        page.meta_description = md["content"].strip()[:1000]
    if not page.meta_description:
        ogd = soup.find("meta", attrs={"property": "og:description"})
        if ogd and ogd.get("content"):
            page.meta_description = ogd["content"].strip()[:1000]

    # ---- JSON-LD structured data ----
    for script in soup.find_all("script", attrs={"type": re.compile("ld\\+json", re.I)}):
        raw = script.string or script.get_text() or ""
        raw = raw.strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except Exception:
            continue
        items = data if isinstance(data, list) else [data]
        for item in items:
            if isinstance(item, dict):
                page.jsonld.append(item)
                if "@graph" in item and isinstance(item["@graph"], list):
                    page.jsonld.extend([g for g in item["@graph"] if isinstance(g, dict)])
    for script in soup.find_all("script"):
        script.decompose()

    text = soup.get_text(separator=" ")
    text = html.unescape(text)
    text = re.sub(r"[ \t\xa0]+", " ", text)
    page.text = re.sub(r"\n{3,}", "\n\n", text).strip()

    # ---- mailto: links (highest confidence, an explicit publication) ----
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.lower().startswith("mailto:"):
            raw = unquote(href[7:].split("?")[0]).strip()
            for piece in re.split(r"[,;]", raw):
                m = EMAIL_RE.search(piece)
                if not m:
                    continue
                cleaned = _clean_candidate(m.group(1), m.group(2))
                if not cleaned:
                    continue
                local, domain = cleaned
                addr = f"{local}@{domain}"  # reassembly-of-parsed-address
                if addr in seen:
                    continue
                seen.add(addr)
                ctx = a.get_text(" ", strip=True)
                parent = a.find_parent(["li", "p", "div", "td", "article", "section"])
                if parent:
                    ctx = parent.get_text(" ", strip=True)[:400]
                page.emails.append(FoundEmail(addr, local, domain, "mailto_link",
                                              url, ctx, 0.9))
        else:
            abs_url = urljoin(url, href)
            if abs_url.startswith(("http://", "https://")):
                page.links.append((abs_url, a.get_text(" ", strip=True)[:120]))

    # ---- plain text + structured data ----
    for fe in extract_emails_from_text(page.text, url):
        if fe.address not in seen:
            seen.add(fe.address)
            page.emails.append(fe)
    for fe in extract_obfuscated_emails(page.text, url):
        if fe.address not in seen:
            seen.add(fe.address)
            page.emails.append(fe)
    for item in page.jsonld:
        for value in _walk_jsonld_emails(item):
            m = EMAIL_RE.search(value)
            if not m:
                continue
            cleaned = _clean_candidate(m.group(1), m.group(2))
            if not cleaned:
                continue
            local, domain = cleaned
            addr = f"{local}@{domain}"  # reassembly-of-parsed-address
            if addr not in seen:
                seen.add(addr)
                page.emails.append(FoundEmail(addr, local, domain, "structured_data",
                                              url, "", 0.85))

    # ---- phones ----
    page.phones = _extract_phones(soup, page.text)

    page.soup = soup

    # ---- social profiles ----
    for abs_url, _ in page.links:
        d = extract_domain(abs_url) or ""
        for key, hosts in _SOCIAL_HOSTS.items():
            if key in page.social:
                continue
            if any(d == h or d.endswith("." + h) for h in hosts):
                if key == "linkedin" and "/company/" not in abs_url and "/in/" not in abs_url:
                    continue
                page.social[key] = abs_url.split("?")[0]

    return page


def _walk_jsonld_emails(node, depth: int = 0):
    if depth > 6:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            if k.lower() in {"email", "e-mail", "emailaddress"} and isinstance(v, str):
                yield v
            else:
                yield from _walk_jsonld_emails(v, depth + 1)
    elif isinstance(node, list):
        for v in node:
            yield from _walk_jsonld_emails(v, depth + 1)


_PHONE_RE = re.compile(
    r"(?:\+?1[\s.\-]?)?\(?\b([2-9]\d{2})\)?[\s.\-]?(\d{3})[\s.\-]?(\d{4})\b"
)


def _extract_phones(soup: BeautifulSoup, text: str) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        if a["href"].lower().startswith("tel:"):
            raw = unquote(a["href"][4:])
            digits = re.sub(r"\D", "", raw)
            if 10 <= len(digits) <= 15 and digits not in seen:
                seen.add(digits)
                out.append(raw.strip())
    for m in _PHONE_RE.finditer(text[:60000]):
        digits = "".join(m.groups())
        if digits in seen:
            continue
        # reject obvious non-phones (dates, prices, zip runs)
        if digits.startswith(("000", "111", "123456")):
            continue
        seen.add(digits)
        out.append(m.group(0).strip())
        if len(out) >= 12:
            break
    return out


# --------------------------------------------------------------------------
# Classification
# --------------------------------------------------------------------------

def is_role_account(local_part: str) -> bool:
    lp = local_part.lower()
    if lp in ROLE_ACCOUNTS:
        return True
    base = re.split(r"[._\-+]", lp)[0]
    return base in ROLE_ACCOUNTS and len(re.split(r"[._\-+]", lp)) <= 2


def is_disposable_domain(domain: str) -> bool:
    d = (domain or "").lower()
    return d in DISPOSABLE_DOMAINS or (registrable_domain(d) or "") in DISPOSABLE_DOMAINS


def is_free_provider(domain: str) -> bool:
    d = (domain or "").lower()
    return d in FREE_PROVIDERS or (registrable_domain(d) or "") in FREE_PROVIDERS


def local_part_matches_person(local_part: str, full_name: str) -> bool:
    """Does 'jsmith' / 'john.smith' / 'john' plausibly denote this person?

    Used only to LABEL an already-discovered address, never to build one.
    """
    tokens = name_tokens(full_name)
    if not tokens:
        return False
    first = tokens[0]
    last = tokens[-1] if len(tokens) > 1 else ""
    lp = re.sub(r"[^a-z0-9]", "", local_part.lower())
    if not lp:
        return False
    candidates = {first}
    if last:
        candidates |= {
            last,
            first + last,
            last + first,
            first[0] + last,
            first + last[0],
            last + first[0],
            first[0] + "." + last,
        }
    candidates = {re.sub(r"[^a-z0-9]", "", c) for c in candidates if len(c) >= 3}
    if lp in candidates:
        return True
    # 'john.smith2'
    if re.sub(r"\d+$", "", lp) in candidates:
        return True

    # Local parts often carry a company or role suffix: 'rachel.kim.acme',
    # 'jsmith.hvac', 'acme.rachel.kim'. Match on SEGMENT boundaries only, so
    # 'rachel.kim.acme' matches Rachel Kim but 'rachelkimball' does not - a
    # substring match would mis-attribute someone else's address to a person.
    segments = [s for s in re.split(r"[._\-+]", local_part.lower()) if s]
    if len(segments) > 1:
        for start in range(len(segments)):
            for end in range(start + 1, len(segments) + 1):
                run = re.sub(r"[^a-z0-9]", "", "".join(segments[start:end]))
                run = re.sub(r"\d+$", "", run)
                if run and run in candidates:
                    return True
    return False


def classify_email_type(local_part: str, matched_contact_is_dm: bool | None,
                        matched_contact: bool) -> str:
    """Tier 1 decision_maker > Tier 2 employee > Tier 3 general_business."""
    if matched_contact and matched_contact_is_dm:
        return "decision_maker"
    if matched_contact:
        return "employee"
    if is_role_account(local_part):
        return "general_business"
    # A personal-looking address we could not tie to a named person:
    # still a real business email, but only Tier 3 confidence about who owns it.
    return "general_business"

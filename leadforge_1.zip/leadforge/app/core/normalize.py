"""Normalisation helpers used for deduplication, matching and range bucketing."""
from __future__ import annotations

import hashlib
import re
from urllib.parse import urlparse, urlunparse

# --------------------------------------------------------------------------
# Company names
# --------------------------------------------------------------------------

_LEGAL_SUFFIXES = {
    "inc", "incorporated", "llc", "l.l.c", "llp", "lp", "ltd", "limited", "co",
    "company", "corp", "corporation", "plc", "pllc", "pc", "pa", "gmbh", "sa",
    "nv", "bv", "ag", "srl", "spa", "oy", "ab", "as", "aps", "kk", "sarl",
    "the", "and", "&",
}

_NAME_CLEAN_RE = re.compile(r"[^a-z0-9 ]+")
_WS_RE = re.compile(r"\s+")


def normalize_company_name(name: str | None) -> str:
    """Lowercase, strip punctuation and legal suffixes. Used as a dedupe key."""
    if not name:
        return ""
    s = name.lower().replace("&", " and ")
    # Collapse dotted acronyms first so "L.L.C." matches "LLC".
    s = re.sub(r"\b(?:[a-z]\.){2,}", lambda m: m.group(0).replace(".", ""), s)
    s = _NAME_CLEAN_RE.sub(" ", s)
    tokens = [t for t in _WS_RE.split(s) if t]
    while tokens and tokens[-1] in _LEGAL_SUFFIXES:
        tokens.pop()
    while tokens and tokens[0] in _LEGAL_SUFFIXES:
        tokens.pop(0)
    tokens = [t for t in tokens if t not in {"the", "and"}]
    return " ".join(tokens)


# --------------------------------------------------------------------------
# URLs / domains
# --------------------------------------------------------------------------

_BAD_HOST_SUFFIXES = (
    "facebook.com", "fb.com", "instagram.com", "twitter.com", "x.com",
    "linkedin.com", "youtube.com", "yelp.com", "google.com", "goo.gl",
    "tiktok.com", "pinterest.com", "nextdoor.com", "angi.com", "angieslist.com",
    "homeadvisor.com", "thumbtack.com", "bbb.org", "mapquest.com", "yellowpages.com",
    "manta.com", "bizapedia.com", "wa.me", "t.me", "sites.google.com",
)

# Common multi-part public suffixes we must not truncate incorrectly.
_MULTI_TLDS = {
    "co.uk", "org.uk", "ac.uk", "gov.uk", "co.nz", "co.za", "com.au", "net.au",
    "org.au", "co.jp", "com.br", "com.mx", "co.in", "com.sg", "com.hk",
}


def normalize_url(url: str | None) -> str | None:
    """Return a canonical absolute https-ish URL, or None if unusable."""
    if not url:
        return None
    url = url.strip()
    if not url or url.lower() in {"n/a", "none", "-"}:
        return None
    if url.startswith("//"):
        url = "https:" + url
    if not re.match(r"^https?://", url, re.I):
        if "." not in url.split("/")[0]:
            return None
        url = "http://" + url
    try:
        p = urlparse(url)
    except ValueError:
        return None
    if not p.netloc:
        return None
    netloc = p.netloc.lower().split("@")[-1]
    if netloc.endswith(":80"):
        netloc = netloc[:-3]
    if netloc.endswith(":443"):
        netloc = netloc[:-4]
    path = p.path or "/"
    return urlunparse((p.scheme.lower(), netloc, path, "", p.query, ""))


def extract_domain(url: str | None) -> str | None:
    """Registrable-ish domain (strips www, keeps two-part public suffixes)."""
    if not url:
        return None
    if "@" in url and "://" not in url:  # looks like an email
        url = url.split("@", 1)[1]
    normalized = normalize_url(url)
    if not normalized:
        return None
    netloc = urlparse(normalized).netloc.lower().lstrip(".")
    host, _, port = netloc.partition(":")
    # An IP literal has no domain name, so host:port IS the identity. Dropping
    # the port would make http://127.0.0.1:8451 and :8452 the same "domain" and
    # the dedupe step would merge two unrelated sites into one.
    if _IPV4_RE.match(host):
        return netloc
    if host.startswith("www."):
        host = host[4:]
    if len(host.split(".")) < 2:
        return None
    # Keep subdomains: shop.example.co.uk stays distinct from example.co.uk.
    # Collapsing to the registrable domain is registrable_domain()'s job.
    return host


_IPV4_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")


def registrable_domain(host: str | None) -> str | None:
    """Collapse a hostname to its registrable domain (drops subdomains)."""
    if not host:
        return None
    netloc = host.lower().lstrip(".")
    host, _, _port = netloc.partition(":")
    # An IP literal has no registrable domain; returning "0.1" for "127.0.0.1"
    # would silently corrupt domain comparisons. Keep the port for the same
    # reason extract_domain does.
    if _IPV4_RE.match(host):
        return netloc
    if host.startswith("www."):
        host = host[4:]
    parts = host.split(".")
    if len(parts) < 2:
        return None
    last_two = ".".join(parts[-2:])
    if last_two in _MULTI_TLDS and len(parts) >= 3:
        return ".".join(parts[-3:])
    return last_two


def is_social_or_directory(url: str | None) -> bool:
    d = extract_domain(url)
    if not d:
        return False
    return any(d == b or d.endswith("." + b) for b in _BAD_HOST_SUFFIXES)


# --------------------------------------------------------------------------
# Phones
# --------------------------------------------------------------------------

def normalize_phone(phone: str | None, default_country: str = "US") -> str | None:
    """E.164-ish. Only handles NANP confidently; otherwise keeps digits."""
    if not phone:
        return None
    digits = re.sub(r"[^\d+]", "", phone)
    if digits.startswith("+"):
        rest = re.sub(r"\D", "", digits[1:])
        return "+" + rest if len(rest) >= 8 else None
    digits = re.sub(r"\D", "", digits)
    if not digits:
        return None
    if default_country == "US":
        if len(digits) == 10:
            return "+1" + digits
        if len(digits) == 11 and digits.startswith("1"):
            return "+" + digits
    if len(digits) >= 8:
        return "+" + digits
    return None


def format_phone_display(e164: str | None) -> str | None:
    if not e164:
        return None
    if e164.startswith("+1") and len(e164) == 12:
        d = e164[2:]
        return f"({d[0:3]}) {d[3:6]}-{d[6:]}"
    return e164


# --------------------------------------------------------------------------
# Addresses
# --------------------------------------------------------------------------

_STREET_ABBR = {
    "street": "st", "avenue": "ave", "boulevard": "blvd", "road": "rd",
    "drive": "dr", "lane": "ln", "court": "ct", "place": "pl", "square": "sq",
    "highway": "hwy", "parkway": "pkwy", "circle": "cir", "terrace": "ter",
    "suite": "ste", "north": "n", "south": "s", "east": "e", "west": "w",
    "northeast": "ne", "northwest": "nw", "southeast": "se", "southwest": "sw",
}


def normalize_address(address: str | None) -> str:
    if not address:
        return ""
    s = address.lower()
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    tokens = [_STREET_ABBR.get(t, t) for t in _WS_RE.split(s) if t]
    return " ".join(tokens)


def address_fingerprint(address: str | None, city: str | None,
                        postal_code: str | None) -> str | None:
    """Stable hash for address-based dedupe. Needs a street line to be meaningful."""
    norm = normalize_address(address)
    if not norm or not re.search(r"\d", norm):
        return None
    parts = [norm, (city or "").lower().strip(), (postal_code or "").strip()[:5]]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:32]


# --------------------------------------------------------------------------
# People names
# --------------------------------------------------------------------------

_NAME_SUFFIXES = {"jr", "sr", "ii", "iii", "iv", "phd", "md", "cpa", "pe", "esq", "mba", "dds"}
_NAME_PREFIXES = {"mr", "mrs", "ms", "dr", "miss", "prof"}


def split_person_name(full_name: str) -> tuple[str | None, str | None]:
    tokens = [t.strip(".,") for t in full_name.split() if t.strip(".,")]
    tokens = [t for t in tokens if t.lower().strip(".") not in _NAME_PREFIXES]
    tokens = [t for t in tokens if t.lower().strip(".") not in _NAME_SUFFIXES]
    if not tokens:
        return None, None
    if len(tokens) == 1:
        return tokens[0], None
    return tokens[0], tokens[-1]


def name_tokens(full_name: str | None) -> list[str]:
    if not full_name:
        return []
    return [t.lower() for t in re.split(r"[^A-Za-z]+", full_name) if len(t) > 1]


# --------------------------------------------------------------------------
# Ranges
# --------------------------------------------------------------------------

EMPLOYEE_BUCKETS = [
    (1, 1, "1"), (2, 10, "2-10"), (11, 50, "11-50"), (51, 200, "51-200"),
    (201, 500, "201-500"), (501, 1000, "501-1000"), (1001, 5000, "1001-5000"),
    (5001, 10000, "5001-10000"), (10001, 10**9, "10001+"),
]

REVENUE_BUCKETS = [
    (0, 500_000, "<$500K"),
    (500_000, 1_000_000, "$500K-$1M"),
    (1_000_000, 5_000_000, "$1M-$5M"),
    (5_000_000, 10_000_000, "$5M-$10M"),
    (10_000_000, 25_000_000, "$10M-$25M"),
    (25_000_000, 50_000_000, "$25M-$50M"),
    (50_000_000, 100_000_000, "$50M-$100M"),
    (100_000_000, 500_000_000, "$100M-$500M"),
    (500_000_000, 1_000_000_000, "$500M-$1B"),
    (1_000_000_000, 10**15, "$1B+"),
]


def employee_range(count: int | None) -> str | None:
    if count is None:
        return None
    for lo, hi, label in EMPLOYEE_BUCKETS:
        if lo <= count <= hi:
            return label
    return None


def revenue_range(amount: float | None) -> str | None:
    if amount is None:
        return None
    for lo, hi, label in REVENUE_BUCKETS:
        if lo <= amount < hi:
            return label
    return None


def parse_money(text: str) -> float | None:
    """'$1.5M' -> 1500000.0 ; '250k' -> 250000.0 ; '2 billion' -> 2e9"""
    if not text:
        return None
    t = text.lower().replace(",", "").replace("$", "").strip()
    m = re.match(r"^([\d.]+)\s*(k|m|mm|b|bn|thousand|million|billion)?$", t)
    if not m:
        return None
    try:
        val = float(m.group(1))
    except ValueError:
        return None
    unit = m.group(2)
    mult = {
        None: 1, "k": 1e3, "thousand": 1e3, "m": 1e6, "mm": 1e6, "million": 1e6,
        "b": 1e9, "bn": 1e9, "billion": 1e9,
    }[unit]
    return val * mult


def sha_key(*parts: str) -> str:
    return hashlib.sha256("|".join(p or "" for p in parts).encode()).hexdigest()

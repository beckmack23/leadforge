"""Provider response cache + call ledger.

Purpose: never pay twice for the same company, and keep an auditable record of
every provider call so cost per qualified lead is measurable.
"""
from __future__ import annotations

import hashlib
import json
import logging
from datetime import timedelta
from typing import Any

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import settings
from ..models import ProviderCache, ProviderCall, ensure_utc, utcnow

log = logging.getLogger(__name__)


def make_key(*parts: Any) -> str:
    blob = json.dumps([p for p in parts], sort_keys=True, default=str)
    return hashlib.sha256(blob.encode()).hexdigest()


async def cache_get(session: AsyncSession, provider: str, operation: str,
                    key: str) -> Any | None:
    stmt = select(ProviderCache).where(
        ProviderCache.provider == provider,
        ProviderCache.operation == operation,
        ProviderCache.key_hash == key,
    )
    row = (await session.execute(stmt)).scalar_one_or_none()
    if row is None:
        return None
    expires_at = ensure_utc(row.expires_at)
    if expires_at is not None and expires_at < utcnow():
        await session.delete(row)
        await session.flush()
        return None
    return row.payload


async def cache_set(session: AsyncSession, provider: str, operation: str,
                    key: str, payload: Any, ttl_days: int | None = None) -> None:
    ttl = ttl_days if ttl_days is not None else settings.cache_ttl_days
    expires = utcnow() + timedelta(days=ttl) if ttl else None
    stmt = select(ProviderCache).where(
        ProviderCache.provider == provider,
        ProviderCache.operation == operation,
        ProviderCache.key_hash == key,
    )
    existing = (await session.execute(stmt)).scalar_one_or_none()
    if existing:
        existing.payload = payload
        existing.created_at = utcnow()
        existing.expires_at = expires
    else:
        session.add(ProviderCache(provider=provider, operation=operation, key_hash=key,
                                  payload=payload, expires_at=expires))
    await session.flush()


async def record_call(session: AsyncSession, provider: str, operation: str, *,
                      job_id: int | None = None, company_id: int | None = None,
                      cache_hit: bool = False, cost_units: float = 0.0,
                      success: bool = True) -> None:
    session.add(ProviderCall(
        provider=provider, operation=operation, job_id=job_id, company_id=company_id,
        cache_hit=cache_hit, cost_units=cost_units, success=success,
    ))
    await session.flush()


async def job_paid_spend(session: AsyncSession, job_id: int) -> float:
    from sqlalchemy import func
    stmt = select(func.coalesce(func.sum(ProviderCall.cost_units), 0.0)).where(
        ProviderCall.job_id == job_id, ProviderCall.cache_hit.is_(False)
    )
    return float((await session.execute(stmt)).scalar_one())


async def purge_expired(session: AsyncSession) -> int:
    res = await session.execute(
        delete(ProviderCache).where(
            ProviderCache.expires_at.is_not(None), ProviderCache.expires_at < utcnow()
        )
    )
    return res.rowcount or 0

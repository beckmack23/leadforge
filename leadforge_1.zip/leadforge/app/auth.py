"""Password protection for hosted deployments.

A lead database on a public URL is worth protecting: it holds contact data, and
its export endpoints will hand the whole thing to anyone who asks. So:

* When ``AUTH_PASSWORD`` is set, every request must authenticate.
* When the server is bound to anything other than loopback, a password is
  mandatory — the app refuses to start without one (see
  ``Settings.startup_error``), so it cannot be deployed publicly wide open.
* Running locally on 127.0.0.1 with no password stays frictionless.

HTTP Basic is used deliberately: the browser handles the prompt and then sends
credentials with every request, including the `fetch` calls the single-page UI
makes and the file downloads it triggers. No login form or session store needed.
"""
from __future__ import annotations

import base64
import hmac
import logging
import secrets

from fastapi import Request
from fastapi.responses import JSONResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware

from .config import settings

log = logging.getLogger(__name__)

# Reachable without credentials: the health probe the host uses to decide
# whether the container is alive. It deliberately exposes no lead data.
PUBLIC_PATHS = {"/api/health"}

WWW_AUTH = {"WWW-Authenticate": 'Basic realm="LeadForge", charset="UTF-8"'}


def _constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def check_credentials(username: str, password: str) -> bool:
    """Compare both fields in constant time to avoid leaking them by timing."""
    expected_user = settings.auth_username or "admin"
    expected_pass = settings.auth_password or ""
    if not expected_pass:
        return False
    user_ok = _constant_time_equals(username, expected_user)
    pass_ok = _constant_time_equals(password, expected_pass)
    return user_ok and pass_ok


def _parse_basic(header: str) -> tuple[str, str] | None:
    if not header or not header.lower().startswith("basic "):
        return None
    try:
        raw = base64.b64decode(header[6:].strip(), validate=True)
        decoded = raw.decode("utf-8")
    except Exception:
        return None
    username, sep, password = decoded.partition(":")
    if not sep:
        return None
    return username, password


class BasicAuthMiddleware(BaseHTTPMiddleware):
    """Gate every request behind HTTP Basic when auth is required."""

    async def dispatch(self, request: Request, call_next):
        if not settings.require_auth:
            return await call_next(request)

        if request.url.path in PUBLIC_PATHS:
            return await call_next(request)

        # A misconfiguration must fail closed, never open.
        if not settings.auth_configured:
            return JSONResponse(
                {"detail": "Server is misconfigured: authentication is required "
                           "but no password is set."},
                status_code=500,
            )

        creds = _parse_basic(request.headers.get("Authorization", ""))
        if creds is None or not check_credentials(*creds):
            if creds is not None:
                # Slow down credential stuffing a little without blocking the loop.
                import asyncio
                await asyncio.sleep(secrets.randbelow(400) / 1000 + 0.1)
                log.warning("failed login attempt from %s",
                            request.client.host if request.client else "unknown")
            return Response(status_code=401, headers=WWW_AUTH,
                            content="Authentication required.",
                            media_type="text/plain")

        return await call_next(request)

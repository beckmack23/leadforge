"""Central configuration.

Everything is environment-driven so the same codebase runs with zero API keys
(free/public sources only) or with any combination of commercial providers.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"), env_file_encoding="utf-8", extra="ignore"
    )

    # ---------- core ----------
    app_name: str = "LeadForge"
    host: str = "127.0.0.1"
    port: int = 8000
    database_url: str = f"sqlite+aiosqlite:///{BASE_DIR / 'leadforge.db'}"
    log_level: str = "INFO"

    # ---------- access control ----------
    # Set these to password-protect the app. Required whenever the server is
    # reachable from outside this machine (see require_auth / auth_configured):
    # a hosted lead database with no password is open to anyone who finds the URL.
    auth_username: str = "admin"
    auth_password: Optional[str] = None
    # Extra browser origins allowed to call the API (comma-separated).
    allowed_origins: str = ""

    # Identify yourself honestly to the sites you fetch.
    user_agent: str = (
        "LeadForgeBot/1.0 (B2B lead research; contact: set CONTACT_EMAIL in .env)"
    )
    contact_email: str = ""

    # ---------- crawl politeness ----------
    respect_robots: bool = True
    per_host_delay_seconds: float = 1.5
    per_host_max_concurrency: int = 2
    global_max_concurrency: int = 24
    http_timeout_seconds: float = 20.0
    max_retries: int = 2
    max_pages_per_site: int = 12
    max_html_bytes: int = 3_000_000

    # ---------- pipeline ----------
    worker_concurrency: int = 12
    cache_ttl_days: int = 30
    discovery_page_size: int = 200

    # ---------- email verification (free tier) ----------
    # SMTP RCPT probing is disabled by default: most cloud/residential networks
    # block outbound port 25, and some mail hosts treat probes as abuse.
    # Without it, the best free status is "valid" (syntax + MX), never "verified".
    smtp_probe_enabled: bool = False
    smtp_probe_timeout: float = 8.0
    smtp_probe_from: str = "verify@example.com"
    smtp_probe_helo: str = "example.com"

    # ---------- provider API keys (all optional) ----------
    google_places_api_key: Optional[str] = None
    yelp_api_key: Optional[str] = None
    serpapi_api_key: Optional[str] = None
    brave_search_api_key: Optional[str] = None

    hunter_api_key: Optional[str] = None
    snov_client_id: Optional[str] = None
    snov_client_secret: Optional[str] = None
    apollo_api_key: Optional[str] = None

    zerobounce_api_key: Optional[str] = None
    neverbounce_api_key: Optional[str] = None
    millionverifier_api_key: Optional[str] = None

    clearbit_api_key: Optional[str] = None
    peopledatalabs_api_key: Optional[str] = None

    # ---------- cost control ----------
    # Max paid provider "credits" a single job may spend. 0 = unlimited.
    job_paid_call_budget: int = 0
    # Skip paid enrichment for leads that already have a decision-maker email.
    skip_paid_when_qualified: bool = True

    # ---------- free discovery ----------
    overpass_url: str = "https://overpass-api.de/api/interpreter"
    nominatim_url: str = "https://nominatim.openstreetmap.org/search"

    @property
    def effective_user_agent(self) -> str:
        if self.contact_email:
            return f"LeadForgeBot/1.0 (B2B lead research; contact: {self.contact_email})"
        return self.user_agent

    # ---------- deployment helpers ----------

    @property
    def effective_database_url(self) -> str:
        """Normalise whatever the host handed us into a SQLAlchemy async URL.

        Railway/Heroku/Render supply ``postgresql://`` (or the legacy
        ``postgres://``), which SQLAlchemy would route to the *synchronous*
        psycopg driver and fail on inside an async engine. Rewrite to asyncpg.
        """
        url = (self.database_url or "").strip()
        if url.startswith("postgres://"):
            url = "postgresql://" + url[len("postgres://"):]
        if url.startswith("postgresql://"):
            url = "postgresql+asyncpg://" + url[len("postgresql://"):]
        if url.startswith("sqlite://") and "+aiosqlite" not in url:
            url = "sqlite+aiosqlite://" + url[len("sqlite://"):]
        # asyncpg does not understand libpq's ?sslmode= parameter.
        if url.startswith("postgresql+asyncpg://") and "sslmode=" in url:
            base, _, query = url.partition("?")
            kept = [p for p in query.split("&") if p and not p.startswith("sslmode=")]
            url = base + ("?" + "&".join(kept) if kept else "")
        return url

    @property
    def is_postgres(self) -> bool:
        return self.effective_database_url.startswith("postgresql")

    @property
    def is_publicly_bound(self) -> bool:
        """True when the server listens on more than this machine's loopback."""
        return self.host not in ("127.0.0.1", "localhost", "::1")

    @property
    def auth_configured(self) -> bool:
        return bool(self.auth_password)

    @property
    def require_auth(self) -> bool:
        """Enforce auth whenever a password is set, or whenever we're exposed."""
        return self.auth_configured or self.is_publicly_bound

    def cors_origins(self) -> list[str]:
        origins = [f"http://{h}:{self.port}" for h in ("127.0.0.1", "localhost")]
        for extra in (self.allowed_origins or "").split(","):
            extra = extra.strip().rstrip("/")
            if extra:
                origins.append(extra)
        return origins

    def startup_error(self) -> str | None:
        """Refuse to start in a configuration that would expose data publicly."""
        if self.is_publicly_bound and not self.auth_configured:
            return (
                "Refusing to start: the server is bound to "
                f"{self.host}, which is reachable from outside this machine, but "
                "AUTH_PASSWORD is not set. Anyone with the URL could read and "
                "export your lead database.\n\n"
                "Fix: set AUTH_PASSWORD (and optionally AUTH_USERNAME) in the "
                "environment. To run without a password, bind to localhost "
                "instead with HOST=127.0.0.1."
            )
        if self.auth_configured and len(self.auth_password or "") < 8:
            return ("Refusing to start: AUTH_PASSWORD must be at least 8 "
                    "characters.")
        return None


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

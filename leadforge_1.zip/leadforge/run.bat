@echo off
REM LeadForge launcher for Windows. Double-click this file, or run it from
REM PowerShell / Command Prompt with:  run.bat
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo   LeadForge
echo   ---------
echo.

REM ---- locate Python -------------------------------------------------------
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY (
  where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo   [X] Python was not found.
  echo.
  echo   Install Python 3.11 or newer from https://www.python.org/downloads/
  echo   IMPORTANT: tick "Add python.exe to PATH" in the installer.
  echo   Then close this window, open a new one, and run this file again.
  echo.
  pause
  exit /b 1
)

REM ---- check the version is new enough ------------------------------------
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 (
  echo   [X] Python 3.11 or newer is required. Found:
  %PY% --version
  echo.
  echo   Install a newer version from https://www.python.org/downloads/
  echo.
  pause
  exit /b 1
)

REM ---- create the virtual environment on first run ------------------------
if not exist ".venv\Scripts\python.exe" (
  echo   Creating virtual environment ^(first run only^)...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo   [X] Could not create the virtual environment.
    pause
    exit /b 1
  )
)

set "VPY=.venv\Scripts\python.exe"

REM ---- install dependencies once ------------------------------------------
if not exist ".venv\.deps-installed" (
  echo   Installing dependencies ^(first run only, takes a minute^)...
  "%VPY%" -m pip install --quiet --upgrade pip
  "%VPY%" -m pip install --quiet -r requirements.txt
  if errorlevel 1 (
    echo   [X] Dependency installation failed. Scroll up for the error.
    pause
    exit /b 1
  )
  echo installed > ".venv\.deps-installed"
)

REM ---- create .env on first run -------------------------------------------
if not exist ".env" (
  copy /y ".env.example" ".env" >nul
  echo   Created .env ^(all API keys optional^)
)

REM demo.bat calls us with --setup-only just to build the venv.
if "%~1"=="--setup-only" (
  echo   Setup complete.
  exit /b 0
)

echo.
echo   Starting LeadForge...
echo.
echo     Open your browser to:  http://127.0.0.1:8000
echo     API docs:              http://127.0.0.1:8000/docs
echo.
echo     Press Ctrl+C in this window to stop the server.
echo.

"%VPY%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 %*

echo.
echo   Server stopped.
pause

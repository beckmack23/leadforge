# Deploy LeadForge as a hosted app

The goal: a URL like `https://leadforge-production.up.railway.app` that you open
from any browser — laptop, phone, anywhere — with nothing installed.

Two stages: put the code on GitHub, then point Railway at it. Budget about
fifteen minutes for the first time.

---

## Before you start

You need:

- A **GitHub** account
- A **Railway** account — sign up at [railway.app](https://railway.app) with your
  GitHub account, which also saves you a step later
- A **password you choose** for the app. Write it down now. Make it at least 8
  characters; a phrase like `copper-lantern-4471` is fine.

> **Why a password is mandatory.** Once the app has a public URL, anyone who
> finds it could browse and export your entire lead database. LeadForge will
> **refuse to start** on a public address without one — that's deliberate, not a
> bug. If you see "Refusing to start", it means you skipped Step 6.

---

## Stage 1 — Put the code on GitHub

### Step 1: Create the repository

1. Go to [github.com/new](https://github.com/new)
2. Repository name: `leadforge`
3. Set it to **Private** (this is your lead tooling)
4. Do **not** tick "Add a README" — the project already has one
5. Click **Create repository**

Leave that page open; you'll need the commands it shows.

### Step 2: Upload the code

**The easy way (no command line):**

1. On your new empty repo page, click **uploading an existing file**
2. Unzip `leadforge.zip` on your computer
3. Open the `leadforge` folder, select **everything inside it**, and drag it into
   the browser window
4. Wait for the uploads to finish, then click **Commit changes**

> One catch: GitHub's drag-and-drop skips folders starting with a dot, so the
> `.github` folder (the automated tests) won't upload this way. That's fine —
> the app deploys and runs correctly without it. Use the Git method below if you
> want the tests running on every push.

**The Git way** (if you have Git installed):

```bash
cd leadforge
git init
git add -A
git commit -m "LeadForge"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/leadforge.git
git push -u origin main
```

---

## Stage 2 — Deploy on Railway

### Step 3: Create the project

1. Go to [railway.app/new](https://railway.app/new)
2. Click **Deploy from GitHub repo**
3. Authorise Railway to see your repositories if it asks
4. Pick your **leadforge** repo

Railway finds the `Dockerfile` and starts building. **The first build will fail
to stay up — that's expected.** It has no password yet, so the app refuses to
start. Steps 4–6 fix that.

### Step 4: Add storage so your leads survive

Without this, your database is wiped every time the app restarts or you deploy a
change.

1. Click your service, then the **Variables**/**Settings** area → find **Volumes**
2. Click **Add Volume**
3. Set the mount path to exactly:

   ```
   /data
   ```

That's where the app already expects to keep its database.

### Step 5: Give it a public URL

1. Service → **Settings** → **Networking**
2. Click **Generate Domain**
3. Copy the URL it gives you — that's your app's address

### Step 6: Set the password (required)

1. Service → **Variables** → **New Variable**
2. Add these:

   | Variable | Value |
   |---|---|
   | `AUTH_PASSWORD` | the password you chose |
   | `AUTH_USERNAME` | `admin` (or any username you like) |
   | `CONTACT_EMAIL` | your email address |

`CONTACT_EMAIL` goes into the crawler's User-Agent so site owners can identify
the traffic. It's good practice and costs nothing.

Railway redeploys automatically when you save. Wait for the deployment to go
green.

### Step 7: Open it

Visit your URL. Your browser asks for the username and password — enter the ones
from Step 6. The app loads.

**You're done.** Bookmark it. It works from your phone too.

---

## Check it's actually locked down

Worth thirty seconds. Open your URL in a **private/incognito window**:

- You should get a **login prompt** and no access without the password.
- Adding `/api/leads` to the URL should also demand the password.

If either loads your data without asking, stop and check that `AUTH_PASSWORD` is
really set in Railway's Variables.

---

## What it costs

Railway charges for usage, not a flat fee. A small always-on service like this
typically lands around **$5/month**, and their starter credit covers early use.

Two things to know:

- **The crawler is the expensive part**, not the app. Idle costs almost nothing;
  a 10,000-business run costs some CPU time for a few hours.
- If you'd rather it not run 24/7, Railway can sleep the service when idle
  (Settings → **Serverless**/sleep). It wakes on the next request. Note that a
  sleeping service also **pauses any running search**, so don't enable it while
  a big job is in flight.

---

## Making it faster and better

### Speed up big searches

By default the app crawls politely: one site at a time per host, 1.5 seconds
between requests. For large jobs, add these Variables:

| Variable | Suggested | Effect |
|---|---|---|
| `WORKER_CONCURRENCY` | `16` | Companies enriched in parallel |
| `PER_HOST_DELAY_SECONDS` | `1.0` | Don't go below ~0.5 — that's rude and gets you blocked |

On Railway's smallest instance keep `WORKER_CONCURRENCY` at `8` or lower, or the
container can run out of memory.

### Get many more businesses

Discovery runs on OpenStreetMap by default, which covers trades and storefronts
well but office-based businesses thinly. Adding a Google Places key is the single
biggest improvement:

1. Get a key from the [Google Cloud Console](https://console.cloud.google.com/)
   (enable **Places API (New)**)
2. Add it in Railway as `GOOGLE_PLACES_API_KEY`

Every other provider works the same way — add the key, restart, done. No code
changes. The **Providers** tab in the app shows what's active and what each
missing key would add.

### Prove emails, don't just validate them

Without a verification key, emails top out at status `valid` (syntax + mail
server confirmed) and never reach `verified`, because mailbox existence genuinely
hasn't been proven. Add `ZEROBOUNCE_API_KEY`, `NEVERBOUNCE_API_KEY` or
`MILLIONVERIFIER_API_KEY` to close that gap.

*(Don't bother with `SMTP_PROBE_ENABLED` on Railway — cloud providers block the
outbound port it needs.)*

### Move to Postgres

The default SQLite database on a volume comfortably handles the 10k–100k lead
range. Past that, or if you want automatic backups:

1. In your Railway project: **New** → **Database** → **PostgreSQL**
2. In your LeadForge service's Variables, add:

   | Variable | Value |
   |---|---|
   | `DATABASE_URL` | `${{Postgres.DATABASE_URL}}` |

That `${{...}}` is Railway's reference syntax — type it exactly. The app detects
Postgres and switches drivers automatically.

**Your existing leads won't move across.** Export them to CSV first if you want
to keep them, then re-import after the switch.

---

## Updating the app later

Push a change to GitHub and Railway redeploys automatically. Your leads are safe
in the `/data` volume across deploys.

---

## Troubleshooting

**"Refusing to start" in the deploy logs**
`AUTH_PASSWORD` isn't set, or is shorter than 8 characters. Go back to Step 6.

**The deployment is red / keeps restarting**
Open the service → **Deployments** → click the failed one → read the logs. The
app prints a plain-English reason on startup failures.

**My leads vanished after a deploy**
The `/data` volume wasn't added (Step 4). Add it — future data will persist.

**Searches find very few businesses**
Expected on OpenStreetMap alone for office-based industries. See *Get many more
businesses* above.

**A search is stuck at 0**
Check the **Jobs** tab. Discovery uses OpenStreetMap's free API, which is
volunteer-run and sometimes rate-limits; the job reports the error rather than
failing silently. Re-run it.

**Everything is slow**
That's mostly deliberate politeness, not the server. See *Speed up big searches*.

---

## Other hosts

Nothing here is Railway-specific — it's a standard Dockerfile. Render, Fly.io and
Google Cloud Run all work. The requirements are the same everywhere:

- Set `AUTH_PASSWORD`
- Mount persistent storage at `/data`, or point `DATABASE_URL` at a Postgres
- Let the platform supply `PORT` (the app already reads it)

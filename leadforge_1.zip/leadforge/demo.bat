@echo off
REM Offline demo: serves four fictional business websites locally, runs the full
REM enrichment pipeline against them, then starts the UI with results loaded.
REM Nothing touches the public internet for discovery.
setlocal
cd /d "%~dp0"

echo.
echo   LeadForge - offline demo
echo   ------------------------
echo.

if not exist ".venv\Scripts\python.exe" (
  echo   Setting up first. This runs run.bat's install step...
  call "%~dp0run.bat" --setup-only
)

if not exist ".venv\Scripts\python.exe" (
  echo   [X] Setup did not complete. Run run.bat first and fix any errors.
  pause
  exit /b 1
)

echo   Seeding demo data and starting the server...
echo.
echo     Open your browser to:  http://127.0.0.1:8000
echo     Then click the "Lead Database" tab.
echo.
echo     You should see 3 qualified leads out of 4 companies - the fourth has a
echo     live website but publishes no email address, so it correctly does not
echo     qualify.
echo.

".venv\Scripts\python.exe" scripts\demo.py

pause

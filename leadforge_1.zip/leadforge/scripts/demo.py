#!/usr/bin/env python3
"""Offline demo: serve four fictional business websites locally and enrich them.

Run this to see the whole pipeline work without any API keys and without
touching the public internet for discovery:

    python scripts/demo.py                # seed the demo, then start the UI
    python scripts/demo.py --seed-only    # just populate the database

The four sites are served on 127.0.0.2-5 and are entirely fictional. They
exercise every branch that matters:

  Acme Mechanical   website + owner's address published in a mailto: link
                    -> QUALIFIED, Tier 1 decision-maker email
  Bayside Plumbing  website + address written for humans as "office (at) ..."
                    -> QUALIFIED, Tier 3 general business email
  Cobalt Roofing    live website, no address published anywhere
                    -> NOT QUALIFIED (this is the point of the rule)
  Delmar Electric   website + address only inside JSON-LD structured data
                    -> QUALIFIED, Tier 3 general business email

Nothing here is invented by the pipeline: every address it stores is one that
literally appears on the page it crawled.
"""
from __future__ import annotations

import argparse
import asyncio
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

PORT = 8451

# Consumer mailbox domains are used deliberately: they resolve, so the built-in
# verifier can do a real MX check, and a small contractor publishing one is
# entirely realistic. LeadForge flags them as consumer domains in the UI.
BUSINESSES = [
    ("127.0.0.2", "Acme Mechanical", "HVAC",
     '<p>Owner direct: <a href="mailto:rachel.kim.acme@gmail.com">rachel.kim.acme@gmail.com</a></p>'
     '<p>General enquiries: <a href="mailto:info.acmemech@gmail.com">info.acmemech@gmail.com</a></p>', "", ""),
    ("127.0.0.3", "Bayside Plumbing", "Plumbing",
     '<p>Email us at office.bayside (at) gmail (dot) com</p>', "", ""),
    ("127.0.0.4", "Cobalt Roofing", "Roofing",
     '<p>Please use the contact form below. We do not publish an email address.</p>', "", ""),
    ("127.0.0.5", "Delmar Electric", "Electrical",
     '<p>Reach the office by phone during business hours.</p>',
     '<script type="application/ld+json">{"@type":"Electrician","name":"Delmar Electric",'
     '"email":"contact.delmarelectric@gmail.com"}</script>', ""),
]


def pages_for(name: str, contact_body: str, extra_head: str, extra_body: str) -> dict:
    slug = name.lower().replace(" ", "-")
    return {
        "/robots.txt": ("text/plain", "User-agent: *\nDisallow: /admin/\n"),
        "/": ("text/html", f"""<html><head><title>{name}</title>
<meta name="description" content="{name} is a family-owned commercial contractor serving Delaware since 2004.">
<script type="application/ld+json">{{"@context":"https://schema.org","@type":"LocalBusiness",
"name":"{name}","foundingDate":"2004",
"address":{{"@type":"PostalAddress","streetAddress":"88 Industrial Way",
"addressLocality":"Wilmington","addressRegion":"DE","postalCode":"19801"}},
"sameAs":["https://www.linkedin.com/company/{slug}","https://www.facebook.com/{slug}"]}}</script>
{extra_head}</head><body>
<nav><a href="/contact">Contact</a><a href="/about">About Us</a><a href="/team">Our Team</a>
     <a href="/careers">Careers</a><a href="/news">News</a><a href="/admin/x">Admin</a></nav>
<h1>{name}</h1><p>Call (302) 555-0142 for 24/7 service.</p>{extra_body}</body></html>"""),
        "/contact": ("text/html", f"<html><head><title>Contact</title></head><body>"
                                  f"<h1>Contact Us</h1><p>Phone: (302) 555-0142</p>"
                                  f"{contact_body}</body></html>"),
        "/about": ("text/html", "<html><head><title>About</title></head><body><p>Established 2004. "
                                "Today we are a team of 28 employees working across 2 locations "
                                "in Delaware and southeastern Pennsylvania.</p></body></html>"),
        "/team": ("text/html", """<html><head><title>Our Team</title></head><body>
<div class="team-member"><h3>Rachel Kim</h3><p>Owner &amp; President</p>
  <a href="https://www.linkedin.com/in/rachelkim">LinkedIn</a></div>
<div class="team-member"><h3>Tom Alvarez</h3><p>Operations Manager</p></div>
<div class="team-member"><h3>Priya Nair</h3><p>Chief Financial Officer</p></div>
</body></html>"""),
        "/careers": ("text/html", """<html><head><title>Careers</title></head><body>
<h1>Now Hiring</h1><p>We are hiring! Join our growing team. Apply today.</p>
<ul><li>Lead Technician - Full-time - Salary and benefits package</li>
    <li>Apprentice - Full-time - Apply now</li></ul></body></html>"""),
        "/news": ("text/html", """<html><head><title>News</title></head><body>
<p>We are expanding into the Lehigh Valley: our new location opens this spring,
and we have invested in a new fleet of 12 service trucks.</p></body></html>"""),
        "/admin/x": ("text/html", "<html><body>never-crawled@example.invalid</body></html>"),
    }


def make_handler(pages):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            path = self.path.split("?")[0]
            if path not in pages:
                self.send_error(404)
                return
            ctype, body = pages[path]
            data = body.encode()
            self.send_response(200)
            self.send_header("Content-Type", f"{ctype}; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *a):
            pass
    return H


# Filled in by start_sites(): business name -> the URL it is actually served on.
SITE_URLS: dict[str, str] = {}


def start_sites() -> list:
    """Serve each business on its own host so the pipeline sees distinct domains.

    Linux treats all of 127.0.0.0/8 as loopback, so each business gets its own
    address. Windows and macOS may refuse anything but 127.0.0.1, so we fall
    back to one distinct port per business, which is just as distinct to the
    deduplication step.
    """
    servers: list = []
    use_distinct_ips = True
    try:
        probe = HTTPServer(("127.0.0.2", 0), make_handler({}))
        probe.server_close()
    except OSError:
        use_distinct_ips = False

    for index, (ip, name, _industry, contact, head, body) in enumerate(BUSINESSES):
        handler = make_handler(pages_for(name, contact, head, body))
        if use_distinct_ips:
            host, port = ip, PORT
        else:
            host, port = "127.0.0.1", PORT + index
        try:
            srv = HTTPServer((host, port), handler)
        except OSError as exc:
            print(f"  ! could not serve {name} on {host}:{port} ({exc})")
            continue
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        servers.append(srv)
        SITE_URLS[name] = f"http://{host}:{port}/"

    if use_distinct_ips:
        print(f"→ demo websites serving on 127.0.0.2-5:{PORT}")
    else:
        print(f"→ demo websites serving on 127.0.0.1:{PORT}-{PORT + len(BUSINESSES) - 1}")
    return servers


async def seed() -> None:
    from app.core.http import get_client, shutdown_client
    from app.db import init_db, session_scope
    from app.models import Company, Job, JobStatus
    from app.pipeline.orchestrator import JobRunner
    from app.providers.base import DiscoveredBusiness
    from app.schemas import SearchCriteria

    await init_db()
    await get_client().start()

    criteria = SearchCriteria(industry="hvac", state="DE", country="US")
    async with session_scope() as s:
        job = Job(name="Demo: Delaware contractors",
                  query=criteria.model_dump(mode="json"),
                  raw_query_text="demo", target_count=len(BUSINESSES),
                  status=JobStatus.QUEUED.value, stats={})
        s.add(job)
        await s.flush()
        job_id = job.id

    runner = JobRunner(job_id)
    discovered = [
        DiscoveredBusiness(name=name, website=SITE_URLS[name],
                           city="Wilmington", state="DE", industry=industry,
                           provider="demo_fixture", source_url=SITE_URLS[name])
        for _ip, name, industry, *_ in BUSINESSES
        if name in SITE_URLS
    ]
    if not discovered:
        print("! no demo websites could be started; nothing to enrich")
        return
    ids = await runner._persist_discovered(discovered, criteria)
    print(f"→ discovered {len(ids)} businesses, enriching…")
    await runner._enrich_all(ids)
    await runner._finish(JobStatus.COMPLETED)

    async with session_scope(write=False) as s:
        from sqlalchemy import select
        rows = (await s.execute(select(Company).order_by(Company.lead_score.desc()))).scalars().all()
        print(f"\n{'SCORE':>5}  {'QUAL':4}  {'COMPANY':<20} {'EMAIL':<34} {'TYPE':<16} STATUS")
        print("-" * 100)
        for c in rows:
            e = c.best_email
            print(f"{c.lead_score:>5}  {'YES' if c.is_qualified else 'no ':4}  {c.name:<20} "
                  f"{(e.address if e else '—'):<34} {(e.email_type if e else '—'):<16} "
                  f"{(e.status if e else '—')}")
        qualified = sum(1 for c in rows if c.is_qualified)
        print(f"\nQualified leads: {qualified}/{len(rows)}  "
              f"(qualified = valid website + business email)")
    await shutdown_client()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed-only", action="store_true",
                    help="populate the database and exit without starting the server")
    args = ap.parse_args()

    start_sites()
    asyncio.run(seed())

    if args.seed_only:
        print("\n→ done. Start the app with ./run.sh and open the Lead Database tab.")
        return

    import uvicorn
    from app.config import settings
    print(f"\n→ starting LeadForge on http://{settings.host}:{settings.port}")
    uvicorn.run("app.main:app", host=settings.host, port=settings.port)


if __name__ == "__main__":
    main()

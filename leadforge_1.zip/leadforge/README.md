# LeadForge

A B2B lead discovery and enrichment platform. It finds businesses by industry and
location, confirms they have a real website, discovers a **real** business email
address, and then enriches them as deeply as the public record allows.

```
QUALIFIED LEAD = VALID WEBSITE + BUSINESS EMAIL
```

Everything else — owner name, phone, revenue, headcount, signals — is enrichment.
A lead is never disqualified for missing it, and is never counted as qualified
without both of the two mandatory fields.

---

## The one rule that matters

| Website | Email | Owner | Phone | Revenue | Result |
|---------|-------|-------|-------|---------|---------------|
| ✓ | ✓ | ✓ | ✓ | ✓ | **QUALIFIED** |
| ✓ | ✓ | ✗ | ✓ | ✗ | **QUALIFIED** |
| ✓ | ✓ | ✗ | ✗ | ✗ | **QUALIFIED** |
| ✓ | ✗ | ✓ | ✓ | ✓ | NOT QUALIFIED |
| ✗ | ✓ | ✓ | ✓ | ✓ | NOT QUALIFIED |

Unqualified companies are kept and visible (uncheck *Qualified only*), they just
aren't counted as leads and can never outscore a qualified one.

---

## Emails are never fabricated

This is the central design constraint, enforced in code rather than by convention.

**Every stored address was literally present somewhere.** There is no pattern
generation, no `first.last@domain` guessing, no permutation testing. Each address
records exactly how it was obtained:

| `discovery_method` | Meaning |
|---|---|
| `mailto_link` | An `href="mailto:…"` on a public page |
| `page_text` | Plain text on a public page |
| `deobfuscated_text` | Written for humans as `name (at) domain (dot) com` |
| `structured_data` | A JSON-LD / microdata `email` property |
| `directory_listing` | Published in the discovery source's own record |
| `provider:<name>` | Returned by a commercial provider **with a source** |
| `user_import` | Supplied by you in a CSV/JSON import |

Commercial adapters are gated too: Hunter results are dropped unless Hunter
reports a public source (or verifies the address); Apollo results are dropped
unless `email_status == "verified"`. Hunter's pure-guessing `email-finder`
endpoint is deliberately not used.

If no address can be found, `email` is `NULL` and the company simply is not a
lead. Three tests enforce this, including a static guard
(`test_no_module_generates_email_addresses`) that fails the build if any source
line joins a local-part to a domain without an explicit audit marker.

### Email tiers

| Tier | `email_type` | Examples |
|---|---|---|
| 1 | `decision_maker` | Owner, Founder, CEO, President, Managing Partner/Member, CFO |
| 2 | `employee` | A named employee's business address |
| 3 | `general_business` | `info@`, `contact@`, `office@`, `sales@`, `hello@` |

A Tier 3 address is a perfectly valid lead — website + email are the only
requirements.

### Email validation

Every address carries a status, the provider that determined it, the date, the
source it came from, and a confidence score.

`verified` · `valid` · `risky` · `catch_all` · `invalid` · `unknown`

Risky and catch-all addresses are **not discarded** — they're stored, flagged and
filterable.

> **Honesty note:** with no commercial verifier configured and SMTP probing off
> (the default), the highest status reachable is `valid` (syntax + MX confirmed),
> never `verified` — because mailbox existence genuinely hasn't been proven. The
> app says so on the Providers tab and in the API's `capabilities` block. Add a
> ZeroBounce/NeverBounce/MillionVerifier key, or enable `SMTP_PROBE_ENABLED` on a
> network with outbound port 25, to reach `verified`.

---

## Run it hosted (a URL, nothing installed)

Deploy to Railway (or any Docker host) and get a private URL you can open from
any device. **[Follow DEPLOY.md](DEPLOY.md)** — about fifteen minutes.

A hosted instance is password-protected and refuses to start without one, so it
can never go live wide open. See [Security](#security) below.

---

## Or run it locally

Requires **Python 3.11 or newer**. No API keys — it runs on free/public sources
out of the box.

**Windows** — double-click **`run.bat`** (or run it from PowerShell).

**macOS / Linux**:

```bash
./run.sh
```

Either way the first run creates a virtual environment, installs dependencies
and writes a `.env`; it takes a minute or two, then a few seconds afterwards.

Then open **http://127.0.0.1:8000**. API docs at `/docs`.

### See it work offline first

**Windows:** double-click **`demo.bat`** · **macOS / Linux:** `python scripts/demo.py`

This serves four fictional business websites locally, runs the full pipeline
against them, and starts the UI with the results loaded. It exercises every
branch: a decision-maker email, a human-obfuscated address, a JSON-LD address,
and one live site that publishes no address at all — which correctly does *not*
qualify. Expect **3 qualified leads out of 4 companies**.

---

## Searching

Type it in plain English:

- `HVAC companies in Pennsylvania`
- `Roofing companies with 10-100 employees in Pennsylvania`
- `Trucking companies in Texas with $1M-$25M estimated revenue`
- `dental practices within 25 miles of 19103 founded after 2010`
- `10,000 HVAC businesses in Pennsylvania`

The parser shows you exactly what it understood before you run anything, and
fills the structured form so you can correct it.

Full criteria: industry, sub-industry, keywords, NAICS, SIC, city, state, ZIP,
country, radius, employee count, estimated revenue, founded year, number of
locations, franchise status.

---

## The pipeline

| Step | What happens |
|---|---|
| 1 · Discovery | Find businesses matching the criteria |
| 2 · Website validation | Confirm a live site (parked/dead/redirect detection) |
| 3 · Deduplication | By domain → LinkedIn → phone → address+name → name+city |
| 4 · Website scraping | Home, About, Contact, Team, Leadership, Locations, Services, Careers, News |
| 5 · Email discovery | Tier 1 → Tier 2 → Tier 3, from the site's own pages |
| 6 · Email validation | Syntax, MX, disposable/role/free detection, optional SMTP probe |
| 7 · Contact enrichment | Owner / Founder / CEO / President / Managing Partner / CFO … |
| 8 · Firmographics | Employees, revenue, founded, locations, industry, NAICS, SIC |
| 9 · Business signals | Hiring, expansion, new location, acquisition, new construction, equipment, large projects, funding, franchise expansion — each with a source URL and the sentence that triggered it |
| 10 · Lead score | 0–100 |

### Lead score

| Component | Max | Basis |
|---|---|---|
| Email | 40 | Tier + verification status |
| Contact | 20 | Named decision maker, title, LinkedIn |
| Firmographics | 20 | Employees, revenue, codes, founded, locations |
| Reachability | 10 | Phone, address, social |
| Signals | 10 | Observed growth/hiring/expansion |

Qualified leads are rescaled into 30–100 and unqualified into 0–25, so
qualification always dominates enrichment while ordering is preserved inside
each band.

---

## Source tracking

Every non-obvious field records where it came from — source type, URL, provider,
confidence, and whether it's an **estimate**. The lead drawer shows it inline
under each value; XLSX exports include a dedicated `Sources` sheet.

```
Company:         ABC HVAC LLC
Website:         abchvac.com          ← website_homepage · https://abchvac.com/
Email:           john@abchvac.com     ← website_contact_page · https://abchvac.com/contact
Email Type:      Decision Maker
Email Status:    Valid (local_mx, 2026-09-08)
Owner:           John Smith           ← website_team_page · https://abchvac.com/team
Employee Count:  42                   ← website_about_page (estimate)
```

Modelled estimates are never presented as confirmed facts.

---

## Data sources

Free sources work immediately. Every commercial adapter activates automatically
when you add its key to `.env` — no code changes.

| Kind | Provider | Cost tier | Needs |
|---|---|---|---|
| Discovery | **OpenStreetMap (Overpass)** | free | — |
| Discovery | **CSV / JSON import** | free | — |
| Discovery | Google Places (New) | cheap | `GOOGLE_PLACES_API_KEY` |
| Discovery | Yelp Fusion | cheap | `YELP_API_KEY` |
| Email finding | **Website crawling** | free | — |
| Email finding | Hunter.io | paid | `HUNTER_API_KEY` |
| Email finding | Snov.io | paid | `SNOV_CLIENT_ID` + `SNOV_CLIENT_SECRET` |
| Email finding | Apollo.io | premium | `APOLLO_API_KEY` |
| Verification | **Built-in MX/SMTP** | free | — |
| Verification | ZeroBounce | paid | `ZEROBOUNCE_API_KEY` |
| Verification | NeverBounce | paid | `NEVERBOUNCE_API_KEY` |
| Verification | MillionVerifier | paid | `MILLIONVERIFIER_API_KEY` |
| Enrichment | **Website scraping** | free | — |
| Enrichment | Clearbit | paid | `CLEARBIT_API_KEY` |
| Enrichment | People Data Labs | premium | `PEOPLEDATALABS_API_KEY` |

The **Providers** tab shows which are live and what each missing key would buy
you. Adding `GOOGLE_PLACES_API_KEY` is the single biggest coverage upgrade —
OpenStreetMap has good coverage of physical/local businesses but thinner coverage
of office-based ones.

---

## Cost optimisation

```
Discover → Find website → Deduplicate → Scrape → Find email
→ Validate → Enrich contact → Enrich company → Score
```

- Providers are always tried in cost order; free sources are exhausted first.
- A paid email finder is called **only** when crawling found nothing usable.
- A paid verifier is called **only** for the single best address on an otherwise
  qualified lead.
- Paid enrichment is skipped for companies that will never qualify.
- Every provider response is cached by domain (`CACHE_TTL_DAYS`, default 30), so
  the same company is never enriched twice.
- `JOB_PAID_CALL_BUDGET` caps credits per job.
- Every call is logged to `provider_calls` with cost units and cache-hit status.

---

## Bulk search

Jobs run asynchronously with a bounded worker pool. Progress reports exactly the
metrics that matter:

```
Businesses Found:        10,000
Websites Found:           9,214
Emails Found:             7,846
Verified/Valid Emails:    6,931
Qualified Leads:          7,402
Decision Makers Found:    4,892
```

These are recomputed from the data, not from a running tally, so they're correct
even after a restart. Jobs can be cancelled and re-run; re-running is idempotent
and hits the cache.

---

## Export

CSV, XLSX, and JSON — all respecting the filters currently applied.

**"Outbound Leads" preset:** First Name, Last Name, Company, Website, Email,
Email Status, Phone, Industry, Employees, Revenue, City, State, LinkedIn, Lead
Score.

**Full record:** every field, plus a `Sources` sheet (XLSX) or per-lead
`sources` / `emails` / `contacts` / `signals` arrays (JSON).

---

## Security

Relevant the moment the app has a URL rather than living on your laptop.

- **Password protection.** Set `AUTH_PASSWORD` and every request needs it —
  including the API and the export endpoints that would otherwise hand over the
  whole database. HTTP Basic, so the browser handles it and the single-page UI
  needs no login screen.
- **Fail-closed by design.** The app **refuses to start** if it is bound to
  anything other than localhost without a password set, and rejects passwords
  under 8 characters. You cannot deploy it publicly wide open by forgetting a
  setting.
- **Only `/api/health` is public**, so the host can probe liveness. It returns
  `{"ok", "database"}` and nothing else — no provider list, no configuration, no
  counts. Everything else, `/` included, is behind auth.
- Credentials are compared in constant time, failed attempts are logged and
  delayed slightly, and database passwords are redacted from logs.

41 of the tests cover exactly these properties.

---

## Crawling conduct

- `robots.txt` is fetched, cached and honoured for every target, including
  `Crawl-delay`.
- Per-host concurrency cap and minimum delay between requests; global cap too.
- A descriptive User-Agent (set `CONTACT_EMAIL` in `.env` — please do).
- **CAPTCHAs, logins, paywalls and access controls are never bypassed.** A `401`,
  `402`, `403`, `407`, `451` or a challenge page stops the crawl of that URL and
  is recorded as `crawl_blocked`. There is no workaround path in the code.
- Only pages the site publishes and links to are visited; response size, page
  count per site and retries are all bounded.

You remain responsible for using the output in line with applicable law
(GDPR/CAN-SPAM/CASL and equivalents) and each site's terms.

---

## Configuration

Copy `.env.example` to `.env`. Everything is optional. Useful knobs:

| Variable | Default | Purpose |
|---|---|---|
| `CONTACT_EMAIL` | — | Goes in your User-Agent. Set it. |
| `RESPECT_ROBOTS` | `true` | Leave it on |
| `PER_HOST_DELAY_SECONDS` | `1.5` | Politeness |
| `WORKER_CONCURRENCY` | `12` | Companies enriched in parallel |
| `MAX_PAGES_PER_SITE` | `12` | Crawl budget per company |
| `CACHE_TTL_DAYS` | `30` | Provider cache lifetime |
| `SMTP_PROBE_ENABLED` | `false` | Needs outbound port 25 |
| `JOB_PAID_CALL_BUDGET` | `0` (unlimited) | Credit cap per job |
| `SKIP_PAID_WHEN_QUALIFIED` | `true` | Don't pay for what you already have |

---

## API

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/meta` | Industries, providers, capabilities |
| `POST` | `/api/parse` | Natural language → search criteria |
| `POST` | `/api/jobs` | Start a search |
| `GET` | `/api/jobs/{id}/progress` | Live metrics |
| `POST` | `/api/jobs/{id}/cancel` | Cancel |
| `POST` | `/api/import` | Enrich your own CSV/JSON list |
| `GET` | `/api/leads` | Filter, sort, paginate |
| `GET` | `/api/leads/{id}` | Full record with sources |
| `GET` | `/api/leads/{id}/score` | Score breakdown |
| `POST` | `/api/export` | CSV / XLSX / JSON |
| `GET` | `/api/stats` | Database totals |
| `GET` | `/api/diagnostics` | Crawler stats, running jobs, capabilities |
| `GET` | `/api/health` | Liveness probe (the only unauthenticated endpoint) |

Interactive docs at `/docs`.

---

## Tests

```bash
python -m pytest -q          # 155 tests
```

Coverage includes the qualification matrix from the spec, scoring bounds, email
tiering and validation-status logic, dedupe keys, NL parsing, the anti-fabrication
static guard, and a **full-stack integration test** that serves four real
websites on distinct loopback addresses and drives the actual HTTP API through
import → job → progress metrics → filters → lead detail → all three exports.

---

## Architecture

```
app/
  main.py               FastAPI app
  auth.py               Password protection for hosted deployments
  config.py             Env-driven settings, DB URL + deploy safety checks
  models.py             SQLAlchemy models
  db.py                 Async engine, WAL, write serialisation
  schemas.py            Pydantic request/response models
  core/
    http.py             Polite client: robots, rate limits, bounded reads
    email_extract.py    Email discovery + tiering  ← the anti-fabrication core
    people_extract.py   Names and titles from About/Team/Leadership pages
    nlq.py              Natural-language query parsing
    normalize.py        Domain/phone/name/address normalisation
    taxonomy.py         45-industry taxonomy with NAICS/SIC
    titles.py           Seniority + decision-maker classification
    cache.py            Provider cache and call ledger
  providers/
    base.py, registry.py         Interfaces + cost-ordered selection
    discovery/  email_finder/  email_verify/  enrichment/
  pipeline/
    orchestrator.py     The 10 steps
    crawler.py          Site crawl → SiteProfile
    dedupe.py  scoring.py  signals.py  manager.py
  export/exporters.py   CSV / XLSX / JSON
  static/               Single-page UI (no build step)
Dockerfile              Production image (no apt packages needed)
railway.json            Railway build/healthcheck config
DEPLOY.md               Step-by-step hosting guide
data/                   Industry taxonomy, role/disposable/free-provider lists
scripts/demo.py         Offline end-to-end demo
tests/                  155 tests
```

Storage is SQLite in WAL mode, sized for the 10k–100k lead range on one machine.
To scale past that, point `DATABASE_URL` at Postgres — the ORM layer is portable
and the write-serialisation lock becomes unnecessary.

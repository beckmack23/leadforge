#!/usr/bin/env bash
# LeadForge launcher: sets up a venv on first run, then starts the server.
set -euo pipefail
cd "$(dirname "$0")"

PY=${PYTHON:-python3}
VENV=.venv

if [ ! -d "$VENV" ]; then
  echo "→ creating virtual environment"
  "$PY" -m venv "$VENV"
fi

# shellcheck disable=SC1091
source "$VENV/bin/activate"

if [ ! -f "$VENV/.deps-installed" ] || [ requirements.txt -nt "$VENV/.deps-installed" ]; then
  echo "→ installing dependencies"
  pip install --quiet --upgrade pip
  pip install --quiet -r requirements.txt
  touch "$VENV/.deps-installed"
fi

if [ ! -f .env ]; then
  echo "→ creating .env from .env.example (all keys optional)"
  cp .env.example .env
fi

HOST=$(grep -E '^HOST=' .env 2>/dev/null | cut -d= -f2 || true)
PORT=$(grep -E '^PORT=' .env 2>/dev/null | cut -d= -f2 || true)
HOST=${HOST:-127.0.0.1}
PORT=${PORT:-8000}

echo
echo "  LeadForge → http://${HOST}:${PORT}"
echo "  API docs  → http://${HOST}:${PORT}/docs"
echo
exec uvicorn app.main:app --host "$HOST" --port "$PORT" "$@"
